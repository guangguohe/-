"""HiveWing · 蜂群僚机

分层：Queen(调度) -> Squad(侦察/军师/起稿/打磨/质检) -> 工蜂(并行变体/事实抽取)
模式：手动粘贴消息 -> 出草稿 -> 复制发送（不接任何聊天平台）
模型：DeepSeek 云端 / Ollama 本地 / Mock 离线
隐私：默认只在本机处理，每条发送都要人工确认
"""

__version__ = "1.2.0"
__app_name__ = "HiveWing"
