"""适配器注册表与发送路由（本版本仅手动模式）。"""
from __future__ import annotations

from ..util import log
from .base import Adapter
from .manual import ManualAdapter

LOG = log("adapters")

# 本版本只保留手动通道：粘贴消息、复制草稿，自己粘到任意聊天窗口。
ROUTES = {
    "manual": ["manual"],
}


class AdapterManager:
    def __init__(self, hub, cfg):
        self.hub = hub
        self.cfg = cfg
        self.adapters: dict[str, Adapter] = {
            a.name: a for a in (ManualAdapter(hub, cfg),)
        }

    async def start_enabled(self) -> None:
        for name, adapter in self.adapters.items():
            if adapter.enabled():
                try:
                    await adapter.start()
                    LOG.info("适配器 %s 已启动", name)
                except Exception as exc:  # noqa: BLE001
                    adapter.error = str(exc)[:200]
                    LOG.warning("适配器 %s 启动失败：%s", name, exc)

    async def stop_all(self) -> None:
        for adapter in self.adapters.values():
            try:
                await adapter.stop()
            except Exception:  # noqa: BLE001
                pass

    def get(self, name: str) -> Adapter | None:
        return self.adapters.get(name)

    def statuses(self) -> list[dict]:
        return [a.status() for a in self.adapters.values()]

    async def start(self, name: str) -> dict:
        adapter = self.get(name)
        if not adapter:
            return {"ok": False, "detail": f"没有适配器 {name}"}
        self.cfg.set(f"adapters.{name}.enabled", True)
        await adapter.start()
        return {"ok": True, "status": adapter.status()}

    async def stop(self, name: str) -> dict:
        adapter = self.get(name)
        if not adapter:
            return {"ok": False, "detail": f"没有适配器 {name}"}
        self.cfg.set(f"adapters.{name}.enabled", False)
        await adapter.stop()
        return {"ok": True, "status": adapter.status()}

    async def send(self, contact, text: str) -> dict:
        adapter = self.adapters.get("manual")
        if not adapter:
            return {"ok": False, "mode": "none", "detail": "没有可用的发送通道"}
        result = await adapter.send(contact, text)
        if result.get("ok"):
            result["adapter"] = "manual"
        return result
