"""FastAPI 服务：REST + WebSocket + PWA 静态页。"""
from __future__ import annotations

import asyncio
import json
import secrets
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .. import __version__, privacy
from ..adapters.registry import AdapterManager
from ..config import Config, deep_merge
from ..db import Store
from ..llm.router import LLMRouter
from ..models import STAGES, Contact, Message
from ..skills.loader import SkillLibrary
from ..swarm.queen import Queen
from ..util import iso, load_json, local_ip, log, new_id, now, setup_logging
from .hub import Hub, contact_dict, draft_dict, msg_dict, variant_dict

LOG = log("server")
STATIC = Path(__file__).parent / "static"


class Runtime:
    cfg: Config
    store: Store
    skills: SkillLibrary
    router: LLMRouter
    queen: Queen
    adapters: AdapterManager
    hub: Hub


RT = Runtime()


# ---------------------------------------------------------------- 请求体
class ContactIn(BaseModel):
    name: str = ""
    platform: str = "manual"
    uid: str = ""
    stage: str = "陌生"
    notes: str = ""


class ContactPatch(BaseModel):
    name: str | None = None
    stage: str | None = None
    notes: str | None = None
    tags: list[str] | None = None


class MessageIn(BaseModel):
    contact_id: str = ""
    platform: str = "manual"
    uid: str = ""
    name: str = ""
    text: str
    direction: str = "in"


class ComposeIn(BaseModel):
    formation: str = "auto"
    trigger: str = "manual"
    sync: bool = False


class DraftAction(BaseModel):
    index: int = 0
    text: str | None = None
    override: bool = False
    confirm: bool = False


class SayIn(BaseModel):
    text: str
    confirm: bool = False


class ConsentIn(BaseModel):
    scope: list[str] = Field(default_factory=list)


class PurgeIn(BaseModel):
    what: str = "messages"


class SkillImportIn(BaseModel):
    url: str


class DemoIn(BaseModel):
    force: bool = False


# ---------------------------------------------------------------- 生命周期
@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging()
    cfg = Config()
    cfg.ensure_file()
    store = Store(cfg.db_path)
    skills = SkillLibrary(cfg.get("skills.dirs"), cfg.get("skills.active")).load()
    router = LLMRouter(cfg)
    router.on_call = lambda info: privacy.audit(store, "model_call", info)
    queen = Queen(cfg, store, skills, router)
    adapters = AdapterManager(None, cfg)  # type: ignore[arg-type]
    hub = Hub(cfg, store, queen, adapters)
    adapters.hub = hub
    for adapter in adapters.adapters.values():
        adapter.hub = hub
    queen.emit = hub.broadcast
    days = int(cfg.get("privacy.retain_days", 0) or 0)
    if days > 0:
        removed = store.purge_older_than(days)
        if removed:
            LOG.info("按 %s 天保留策略清理了 %s 条旧消息", days, removed)
    await adapters.start_enabled()
    RT.cfg, RT.store, RT.skills, RT.router = cfg, store, skills, router
    RT.queen, RT.adapters, RT.hub = queen, adapters, hub
    if cfg.get("safety.seed_demo", True) and store.stats()["contacts"] == 0:
        seed_demo(store)
    LOG.info("HiveWing %s 就绪：%s", __version__, cfg.db_path)
    try:
        yield
    finally:
        await adapters.stop_all()
        await router.close()
        store.close()


app = FastAPI(title="HiveWing 蜂群僚机", version=__version__, lifespan=lifespan)


# ---------------------------------------------------------------- 鉴权
def _token_of(request: Request) -> str:
    return (
        request.headers.get("x-hive-token")
        or request.query_params.get("token")
        or request.cookies.get("hive_token")
        or ""
    )


async def auth(request: Request) -> None:
    token = _token_of(request)
    if not token or not secrets.compare_digest(str(token), RT.cfg.token):
        raise HTTPException(status_code=401, detail="token 无效，请从启动日志里带 ?token= 打开")


# ---------------------------------------------------------------- 页面
@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    token = _token_of(request)
    html = (STATIC / "index.html").read_text("utf-8")
    boot = {
        "token": token if token and secrets.compare_digest(token, RT.cfg.token) else "",
        "version": __version__,
        "clientId": new_id("cl_"),
    }
    html = html.replace("<!--HIVE_BOOT-->", f"<script>window.__HIVE_BOOT__={json.dumps(boot, ensure_ascii=False)}</script>")
    resp = HTMLResponse(html)
    if boot["token"]:
        resp.set_cookie("hive_token", boot["token"], max_age=60 * 60 * 24 * 30, httponly=True, samesite="lax")
    return resp


@app.get("/manifest.webmanifest")
async def manifest():
    return JSONResponse({
        "name": "蜂群僚机",
        "short_name": "蜂群",
        "start_url": "/",
        "display": "standalone",
        "background_color": "#0f0d0b",
        "theme_color": "#f0a63c",
        "icons": [{
            "src": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxOTIgMTkyIj48cmVjdCB3aWR0aD0iMTkyIiBoZWlnaHQ9IjE5MiIgcng9IjQyIiBmaWxsPSIjMGYwZDBiIi8+PHBhdGggZD0iTTk2IDMwbDQwIDIzdjQ2bC00MCAyMy00MC0yM1Y1M3oiIGZpbGw9IiNmMGE2M2MiLz48L3N2Zz4=",
            "sizes": "192x192",
            "type": "image/svg+xml",
        }],
    })


@app.get("/sw.js", response_class=PlainTextResponse)
async def service_worker():
    return PlainTextResponse("/* no service worker */", media_type="application/javascript")


# ---------------------------------------------------------------- 状态
@app.get("/api/health")
async def health():
    return {"ok": True, "version": __version__, "ts": iso()}


@app.get("/api/bootstrap")
async def bootstrap(_: None = Depends(auth)):
    snap = RT.hub.snapshot()
    cfg = RT.cfg
    lan = str(cfg.get("server.public_base") or f"http://{local_ip()}:{cfg.get('server.port')}")
    return {
        "version": __version__,
        **snap,
        "skills": RT.skills.stats(),
        "config": public_config(cfg),
        "pairing": {
            "url": f"{lan}/?token={cfg.token}",
            "lan": lan,
            "token": cfg.token,
            "port": cfg.get("server.port"),
        },
        "stages": STAGES,
        "privacy": privacy_payload(),
    }


def privacy_payload() -> dict:
    provider = RT.router.provider_name("draft")
    return {
        **privacy.state(RT.cfg),
        "items": privacy.SCOPE_ITEMS,
        "data_flow": privacy.describe(provider, RT.cfg),
        "db_bytes": RT.store.db_bytes(),
        "stats": RT.store.stats(),
        "events": RT.store.events(40),
    }


# ---------------------------------------------------------------- 隐私
@app.get("/api/privacy")
async def get_privacy(_: None = Depends(auth)):
    return privacy_payload()


@app.post("/api/privacy/consent")
async def post_consent(body: ConsentIn, _: None = Depends(auth)):
    result = privacy.grant(RT.cfg, body.scope)
    if not result.get("ok"):
        raise HTTPException(400, result.get("detail", "授权失败"))
    privacy.audit(RT.store, "consent", {"scope": body.scope})
    payload = privacy_payload()
    await RT.hub.broadcast({"type": "privacy", "privacy": payload, "config": public_config(RT.cfg)})
    return {"ok": True, "privacy": payload}


@app.post("/api/privacy/revoke")
async def post_revoke(_: None = Depends(auth)):
    result = privacy.revoke(RT.cfg)
    privacy.audit(RT.store, "revoke", {})
    payload = privacy_payload()
    await RT.hub.broadcast({"type": "privacy", "privacy": payload,
                            "adapters": RT.adapters.statuses()})
    return {"ok": True, "privacy": payload, **result}


@app.post("/api/privacy/purge")
async def post_purge(body: PurgeIn, _: None = Depends(auth)):
    done = RT.store.purge("all" if body.what == "all" else "messages")
    privacy.audit(RT.store, "purge", {"what": body.what, "removed": done})
    await RT.hub.broadcast({"type": "state", **RT.hub.snapshot()})
    return {"ok": True, "removed": done, "stats": RT.store.stats()}


@app.get("/api/state")
async def state(_: None = Depends(auth)):
    return RT.hub.snapshot()


# ---------------------------------------------------------------- 联系人
@app.get("/api/contacts")
async def list_contacts(_: None = Depends(auth)):
    return {"contacts": [contact_dict(c, RT.store) for c in RT.store.list_contacts()]}


@app.post("/api/contacts")
async def create_contact(body: ContactIn, _: None = Depends(auth)):
    name = body.name.strip() or body.uid.strip() or "新联系人"
    c = Contact(id=new_id("c_"), name=name, platform=body.platform or "manual",
                platform_uid=body.uid.strip(), stage=body.stage if body.stage in STAGES else "陌生",
                notes=body.notes)
    RT.store.upsert_contact(c)
    await RT.hub.broadcast({"type": "contact.updated", "contact": contact_dict(c, RT.store)})
    return {"contact": contact_dict(c, RT.store)}


@app.patch("/api/contacts/{cid}")
async def patch_contact(cid: str, body: ContactPatch, _: None = Depends(auth)):
    c = RT.store.get_contact(cid)
    if not c:
        raise HTTPException(404, "会话不存在")
    if body.name is not None:
        c.name = body.name.strip() or c.name
    if body.stage is not None and body.stage in STAGES:
        c.stage = body.stage
    if body.notes is not None:
        c.notes = body.notes
    if body.tags is not None:
        c.tags = body.tags
    RT.store.upsert_contact(c)
    await RT.hub.broadcast({"type": "contact.updated", "contact": contact_dict(c, RT.store)})
    return {"contact": contact_dict(c, RT.store)}


@app.delete("/api/contacts/{cid}")
async def delete_contact(cid: str, _: None = Depends(auth)):
    RT.store.delete_contact(cid)
    await RT.hub.broadcast({"type": "contact.deleted", "contact_id": cid})
    return {"ok": True}


@app.get("/api/contacts/{cid}")
async def get_contact(cid: str, limit: int = 60, _: None = Depends(auth)):
    c = RT.store.get_contact(cid)
    if not c:
        raise HTTPException(404, "会话不存在")
    messages = RT.store.list_messages(cid, limit=limit)
    drafts = RT.store.list_drafts(cid, 6)
    return {
        "contact": contact_dict(c, RT.store),
        "messages": [msg_dict(m) for m in messages],
        "drafts": [draft_dict(d) for d in drafts],
        "facts": RT.store.list_facts(cid),
        "runs": RT.store.recent_runs(cid, 5),
    }


@app.post("/api/messages")
async def post_message(body: MessageIn, _: None = Depends(auth)):
    if not body.text.strip():
        raise HTTPException(400, "消息为空")
    if body.contact_id:
        c = RT.store.get_contact(body.contact_id)
        if not c:
            raise HTTPException(404, "会话不存在")
        msg = await RT.hub.ingest(platform=c.platform, uid=c.platform_uid, name=c.name,
                                  text=body.text, direction=body.direction, auto=True)
        return {"message": msg_dict(msg) if msg else None, "contact": contact_dict(c, RT.store)}
    msg = await RT.hub.ingest(
        platform=body.platform or "manual", uid=body.uid, name=body.name,
        text=body.text, direction=body.direction, auto=True,
    )
    if not msg:
        return {"message": None}
    c = RT.store.get_contact(msg.contact_id)
    return {"message": msg_dict(msg), "contact": contact_dict(c, RT.store) if c else None}


# ---------------------------------------------------------------- 蜂群
@app.post("/api/contacts/{cid}/compose")
async def compose(cid: str, body: ComposeIn, _: None = Depends(auth)):
    c = RT.store.get_contact(cid)
    if not c:
        raise HTTPException(404, "会话不存在")
    run_id = new_id("r_")
    if body.sync:
        result = await RT.hub.run_compose(c, trigger=body.trigger, formation=body.formation, run_id=run_id)
        return result.to_dict()
    asyncio.create_task(RT.hub.run_compose(c, trigger=body.trigger, formation=body.formation, run_id=run_id))
    return {"run_id": run_id, "status": "running"}


@app.get("/api/runs/{run_id}")
async def get_run(run_id: str, _: None = Depends(auth)):
    result = RT.hub.runs.get(run_id)
    if result is not None:
        return result.to_dict()
    row = RT.store.get_run(run_id)
    if row:
        return {"run_id": run_id, "status": "finished", "stored": row}
    return {"run_id": run_id, "status": "unknown"}


@app.post("/api/contacts/{cid}/say")
async def say(cid: str, body: SayIn, _: None = Depends(auth)):
    c = RT.store.get_contact(cid)
    if not c:
        raise HTTPException(404, "会话不存在")
    _require_confirm(body.confirm)
    result = await RT.hub.deliver_text(c, body.text)
    if result.get("ok"):
        privacy.audit(RT.store, "send", {
            "contact": c.name, "platform": c.platform, "mode": result.get("mode"),
            "chars": len(body.text), "source": "composer",
        })
    return result


@app.post("/api/drafts/{did}/choose")
async def choose_draft(did: str, body: DraftAction, _: None = Depends(auth)):
    d = RT.store.get_draft(did)
    if not d:
        raise HTTPException(404, "草稿不存在")
    if not (0 <= body.index < len(d.variants)):
        raise HTTPException(400, "索引越界")
    RT.store.update_draft(did, chosen=body.index)
    return {"ok": True, "text": d.variants[body.index].text}


def _require_confirm(confirmed: bool) -> None:
    """「时刻确认」的硬闸门：没在界面上点过确认，一律不发。"""
    if bool(RT.cfg.get("privacy.strict_confirm", True)) and not confirmed:
        raise HTTPException(status_code=428, detail="这条要你在界面上确认过才能发")


@app.post("/api/drafts/{did}/send")
async def send_draft(did: str, body: DraftAction, _: None = Depends(auth)):
    d = RT.store.get_draft(did)
    if not d:
        raise HTTPException(404, "草稿不存在")
    _require_confirm(body.confirm)
    contact = RT.store.get_contact(d.contact_id)
    result = await RT.hub.deliver(d, index=body.index, text=body.text, override=body.override)
    if result.get("ok"):
        privacy.audit(RT.store, "send", {
            "contact": contact.name if contact else "",
            "platform": contact.platform if contact else "",
            "mode": result.get("mode"),
            "chars": len(body.text or (d.variants[body.index].text if d.variants else "")),
            "source": "draft",
            "draft_id": did,
            "override": body.override,
        })
    result["draft"] = RT.store.get_draft(did).to_dict() if RT.store.get_draft(did) else None
    return result


@app.post("/api/drafts/{did}/reject")
async def reject_draft(did: str, _: None = Depends(auth)):
    d = RT.store.get_draft(did)
    if not d:
        raise HTTPException(404, "草稿不存在")
    RT.hub.reject(d)
    return {"ok": True}


# ---------------------------------------------------------------- 设置
@app.get("/api/settings")
async def get_settings(_: None = Depends(auth)):
    return {"config": public_config(RT.cfg)}


@app.put("/api/settings")
async def put_settings(body: dict, _: None = Depends(auth)):
    current = RT.cfg.data
    patch = sanitize_settings(body, current)
    merged = deep_merge(current, patch)
    RT.cfg.data = merged
    RT.cfg.save()
    RT.skills.dirs = [RT.skills._resolve(d) for d in RT.cfg.get("skills.dirs", ["skills/packs"])]
    RT.skills.active = RT.cfg.get("skills.active", [])
    RT.skills.load()
    await RT.hub.broadcast({"type": "config.updated", "config": public_config(RT.cfg)})
    return {"ok": True, "config": public_config(RT.cfg)}


# ---------------------------------------------------------------- 技能
@app.get("/api/skills")
async def get_skills(_: None = Depends(auth)):
    return {**RT.skills.stats(), "briefs": RT.skills.briefs(1200)}


@app.post("/api/skills/reload")
async def reload_skills(_: None = Depends(auth)):
    RT.skills.load()
    return RT.skills.stats()


@app.post("/api/skills/import")
async def import_skill(body: SkillImportIn, _: None = Depends(auth)):
    try:
        result = await asyncio.to_thread(RT.skills.import_from_github, body.url)
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(400, f"导入失败：{exc}") from exc
    active = list(RT.cfg.get("skills.active", []))
    if result["pack"] not in active:
        active.append(result["pack"])
        RT.cfg.set("skills.active", active)
        RT.cfg.save()
        RT.skills.active = active
        RT.skills.load()
    return result


# ---------------------------------------------------------------- 适配器
@app.get("/api/adapters")
async def get_adapters(_: None = Depends(auth)):
    return {"adapters": RT.adapters.statuses()}


@app.post("/api/adapters/{name}/start")
async def start_adapter(name: str, _: None = Depends(auth)):
    result = await RT.adapters.start(name)
    await RT.hub.broadcast({"type": "adapters", "adapters": RT.adapters.statuses()})
    return result


@app.post("/api/adapters/{name}/stop")
async def stop_adapter(name: str, _: None = Depends(auth)):
    result = await RT.adapters.stop(name)
    await RT.hub.broadcast({"type": "adapters", "adapters": RT.adapters.statuses()})
    return result


# ---------------------------------------------------------------- 模型
@app.get("/api/llm/health")
async def llm_health(_: None = Depends(auth)):
    return await RT.router.health()


# ---------------------------------------------------------------- 演示数据
@app.post("/api/demo")
async def demo(body: DemoIn | None = None, _: None = Depends(auth)):
    if RT.store.stats()["contacts"] > 0 and not (body and body.force):
        return {"ok": False, "detail": "已经有会话了，加 force=true 再灌一份"}
    seed_demo(RT.store)
    await RT.hub.broadcast({"type": "state", **RT.hub.snapshot()})
    return {"ok": True, **RT.store.stats()}


# ---------------------------------------------------------------- WebSocket
@app.websocket("/ws")
async def ws_endpoint(ws: WebSocket):
    token = ws.query_params.get("token") or ws.cookies.get("hive_token") or ""
    if not token or not secrets.compare_digest(str(token), RT.cfg.token):
        await ws.close(code=4401)
        return
    await ws.accept()
    await RT.hub.connect(ws)
    try:
        while True:
            data = await ws.receive_json()
            kind = data.get("type")
            if kind == "ping":
                await ws.send_json({"type": "pong"})
            elif kind == "focus":
                RT.hub.set_active(str(data.get("contact_id") or ""))
                await RT.hub.broadcast({"type": "focus", "contact_id": RT.hub.active_contact_id})
            elif kind == "presence":
                info = RT.hub.clients.get(ws)
                if info and data.get("kind") in ("pc", "mobile"):
                    info.kind = data["kind"]
                    await RT.hub.broadcast_presence()
            elif kind == "compose":
                cid = str(data.get("contact_id") or "")
                c = RT.store.get_contact(cid)
                if c:
                    asyncio.create_task(RT.hub.run_compose(c, trigger="manual", formation=str(data.get("formation") or "auto")))
    except WebSocketDisconnect:
        pass
    except Exception as exc:  # noqa: BLE001
        LOG.debug("ws 异常：%s", exc)
    finally:
        await RT.hub.disconnect(ws)


app.mount("/static", StaticFiles(directory=str(STATIC)), name="static")


# ---------------------------------------------------------------- 工具
def public_config(cfg: Config) -> dict:
    data = json.loads(json.dumps(cfg.data, ensure_ascii=False))
    ds = data.get("llm", {}).get("providers", {}).get("deepseek", {})
    key = str(ds.pop("api_key", "") or "")
    ds["api_key_set"] = bool(key)
    ds["api_key_hint"] = (key[:3] + "***" + key[-2:]) if len(key) > 8 else ("***" if key else "")
    return data


ALLOWED_SETTINGS = {"persona", "goal", "safety", "llm", "adapters", "skills", "ui", "privacy"}

# 这些只能通过 /api/privacy/consent 改，不允许走通用设置接口
PRIVACY_LOCKED = {"consent_at", "consent_scope", "strict_confirm"}


def sanitize_settings(body: dict, current: dict) -> dict:
    patch: dict[str, Any] = {}
    for key, value in (body or {}).items():
        if key not in ALLOWED_SETTINGS or not isinstance(value, dict):
            continue
        patch[key] = value
    # 不允许通过设置接口改 token / db
    if "server" in (body or {}):
        LOG.info("忽略对 server 段的远程修改")
    # 授权相关字段只能走 consent 接口
    for locked in PRIVACY_LOCKED:
        (patch.get("privacy") or {}).pop(locked, None)
    # api_key 掩码保护
    ds_patch = ((patch.get("llm") or {}).get("providers") or {}).get("deepseek")
    if isinstance(ds_patch, dict):
        new_key = ds_patch.get("api_key")
        if new_key in (None, "", "***") or (isinstance(new_key, str) and new_key.endswith("***")):
            ds_patch.pop("api_key", None)
        ds_patch.pop("api_key_set", None)
        ds_patch.pop("api_key_hint", None)
    return patch


# ---------------------------------------------------------------- 演示数据
def seed_demo(store: Store) -> None:
    from ..models import Contact as C

    demos = [
        {
            "name": "小雅", "platform": "manual", "uid": "", "stage": "暧昧",
            "notes": "咖啡店认识的，做设计，加班多",
            "msgs": [
                ("in", "今天加班到现在，累死了", 5400),
                ("out", "这么晚 吃饭没", 5350),
                ("in", "没呢，懒得动", 5300),
                ("out", "那不行，先点个东西垫一下", 5200),
                ("in", "点了个麻辣烫 你吃了吗", 5100),
                ("out", "吃了 楼下那家面 一般", 5050),
                ("in", "哈哈哈你嘴真挑", 5000),
                ("in", "这周终于要忙完了", 900),
            ],
        },
        {
            "name": "阿念", "platform": "manual", "uid": "", "stage": "破冰",
            "notes": "朋友介绍的，话不多",
            "msgs": [
                ("in", "你好呀", 3000),
                ("out", "你好 听说你也玩摄影", 2900),
                ("in", "嗯 随便拍拍", 2800),
            ],
        },
        {
            "name": "小鹿", "platform": "manual", "uid": "", "stage": "陌生",
            "notes": "抖音同城刷到的",
            "msgs": [
                ("in", "你也在杭州啊", 1200),
            ],
        },
    ]
    for d in demos:
        c = C(id=new_id("c_"), name=d["name"], platform=d["platform"],
              platform_uid=d["uid"], stage=d["stage"], notes=d["notes"])
        store.upsert_contact(c)
        base = now()
        for direction, text, ago in d["msgs"]:
            store.add_message(Message(id=new_id("m_"), contact_id=c.id, direction=direction,
                                      text=text, ts=base - ago, platform=d["platform"],
                                      sender="her" if direction == "in" else "me"))
    LOG.info("已灌入演示会话")
