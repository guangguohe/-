# 接入指南

三种接法，从「零配置」到「原生协议」。建议先跑通手动模式，再一个个加。

---

## 0. 手动 / 剪贴板（永远可用）

**收**：界面「她刚发来」→ 粘贴。
**发**：草稿卡点「复制」→ 粘到聊天框。

这条路不依赖任何东西，也是所有平台的最终兜底。

---

## 1. 全局热键 · 剪贴板桥（Windows，推荐）

⚙ →「接入」→ 启动「剪贴板桥」。

之后在**任何**聊天窗口：

1. 选中/复制她那条消息
2. 按 `Ctrl+Alt+H`
3. 电脑右下角弹提示，当前选中的会话里出现 1 条新消息 + 3 条草稿

原理：`RegisterHotKey` 注册全局热键 → 线程消息循环 → 读剪贴板 → `Hub.ingest_from_bridge()` → 归到 `active_contact_id`。

注意：
- 热键被占用时适配器状态会报「注册失败」，改 `hivewing/adapters/bridge.py` 里的 `VK_H` 或修饰键即可。
- 没有选中会话时，会归到「剪贴板对象」这个会话。

---

## 2. 通用注入（Windows，微信/QQ/抖音 PC 端）

⚙ →「接入」→ 启动「通用注入」。

发送时：

1. 枚举窗口，按平台找 `微信 / WeChat / QQ / 抖音`
2. `ShowWindow + SetForegroundWindow` 前置（先按一下 ALT 骗过前台限制）
3. 写剪贴板 → `Ctrl+V`
4. **不自动回车**，你自己看一眼再发

找不到窗口时不会乱粘，返回「已复制」。这是有意的安全设计。

如果总是提示「窗口切换被系统拦了」：Windows 的前台窗口保护。手动把聊天窗口点一下再发送，或者直接用「复制」。

---

## 3. QQ · OneBot 11（NapCat）

适用：想真正收发 QQ 私聊。

### 装 NapCat

1. 下载 [NapCat](https://github.com/NapNeko/NapCatQQ)（需要 QQ NT 客户端）
2. 用一个**小号**登录
3. 打开 NapCat 的 WebUI（默认 `http://127.0.0.1:6099`）

### 配 OneBot

在 NapCat 配置里：

```jsonc
{
  "httpServers": [
    { "name": "hive", "host": "127.0.0.1", "port": 3000, "enable": true,
      "token": "你自己定一个", "messagePostFormat": "array" }
  ],
  "websocketClients": [
    { "name": "hive-ws", "url": "ws://127.0.0.1:8760/onebot/ws",
      "enable": true, "token": "你自己定一个", "messagePostFormat": "array" }
  ]
}
```

### 配蜂群

⚙ →「接入」：

- OneBot HTTP 地址：`http://127.0.0.1:3000`
- Access Token：跟上面一致
- 我的 QQ 号：填小号，用来忽略自己发的消息
- 启动 QQ

### 验证

给小号发一条私聊，界面左侧应出现新会话。点「发送」应该直接发出去（`mode: onebot`）。

### 常见问题

| 现象 | 原因 |
|---|---|
| 适配器报「连不上 OneBot」 | 端口不对 / NapCat 没开 HTTP 服务 |
| 收不到消息 | 反向 WS 没连上；看终端有没有 `OneBot 反向 WS 已连接` |
| 发送 401 | token 不一致 |
| 群消息没反应 | 设计如此，只处理私聊 |

---

## 4. 微信 · wxauto

适用：Windows + 已登录的 PC 微信。

```powershell
python -m pip install wxauto
```

1. 登录 PC 微信，**窗口不要最小化**
2. ⚙ →「接入」→ 启动微信
3. 适配器状态显示「已接管微信（你的昵称）」

收：轮询当前会话的新消息（`GetNextNewMessage`，兼容 4.x 的 `GetAllMessage`）。
发：`SendMsg(msg, who=<昵称>)`。

> **这台机器上的实际情况**：wxauto 装不上（PyPI 直连不通，清华镜像里 `from versions: none`，本地也没有 comtypes / uiautomation / pywin32 这些底座）。所以微信目前走的是**剪贴板桥 + 通用注入**：
> 1. 微信里选中她发来的消息 → `Ctrl+C` → 按 `Ctrl+Alt+H`，蜂群自动起稿；
> 2. 选中一条草稿 → 点「发送」→ 确认框 → 文字被粘进微信输入框，你自己按回车。
>
> 这条路径不碰微信协议、不注入进程，封号风险最低。等能装 wxauto 的机器（或换 WeChatFerry），把它打开就自动升级成直读直发。

注意：
- wxauto 走 UI 自动化，版本差异大。报错时先 `pip install -U wxauto`。
- 只适合单人会话；群聊请在配置里关掉。
- 微信更新后可能失效，等 wxauto 适配。
- 另一个选择是 WeChatFerry（需要特定微信版本），本项目没有内置。

---

## 4.5 微信 · 读屏（本机实验通道）

前提：Windows、微信 PC 端已登录、把那个聊天的窗口打开（不用最小化，脚本会自己把它提到前面）。

用法：主界面「她刚发来」→ 点「读微信屏幕」→ 识别结果填进输入框 → **把错别字改掉** → 收下并起稿。

原理：`PrintWindow` 截当前窗口 → 裁出右边聊天区放大 2.6 倍 → Windows 自带 OCR（zh-Hans）→
按每行左边缘的位置判断是她的还是我的（靠左=她）。

质量：大约九成。Windows 的这个中文模型会把「效果」拆成「氵攵果」、「解决」认成「氵决」，
所以识别结果一律只回填到输入框给你改，不直接喂给蜂群。

隐私：要 `read_chat` 授权才能用；结果只在内存里过一遍，写进审计（读了哪个会话、几行），不落库。

为什么不做数据库直读：4.1.15 的库是 SQLCipher，密钥在内存里还带一层 Weixin.dll 的掩码，
实测没取出来（详见 `hivewing/wechat/keys.py` 里的几条扫描路径，都试过了）。
为什么不做 UI 自动化：4.x 是 Qt 自绘，UIA 控件树里只有一个空 Pane，读不到气泡。

部署到线上时删掉：`hivewing/wechat/`、`tools/wechat_*.ps1`、`tests/test_wechat_ocr.py`。
`/api/wechat/screen` 的 import 是延迟的，模块不在就自动返回 501，不用改别的代码。

---

## 5. 抖音

**没有官方私聊 API。** 市面上的「抖音协议机器人」基本是盗号或封号，不要碰。

推荐组合：

- 收：复制她的消息 → `Ctrl+Alt+H`
- 发：通用注入到抖音 PC 端输入框

在 ⚙ 里启动「抖音」适配器，发送时就会优先找抖音窗口。

---

## 手机

同一 Wi-Fi，⚙ →「手机配对」扫码。手机是纯前端，所有能力都在电脑上执行，所以：

- 电脑关机 = 手机用不了
- 手机点的「发送」走的是电脑的适配器

想在外面用？把 8760 端口通过 `cloudflared tunnel` / `tailscale` 暴露出去，或者部署到一台常开的机器上（记得换 token）。

---

## 排查清单

```powershell
python -m hivewing doctor
```

1. 模型：DeepSeek 是否可用 / Ollama 是否在跑
2. 技能包：是不是两个都加载了
3. 数据库：能不能写
4. 适配器：哪个在跑

还是不行，看终端日志（`HIVEWING_LOG=DEBUG` 可以更详细）。
