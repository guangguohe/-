# 架构

## 一张图

```
┌──────────────── 手机浏览器 (PWA) ────────────────┐   ┌──────── 电脑浏览器 ────────┐
│  会话 / 草稿 / 批准 / 手写                      │   │  同一套 UI，三栏           │
└───────────────┬─────────────────────────────────┘   └──────────┬────────────────┘
                │  WebSocket /ws?token=                          │
                └──────────────────┬─────────────────────────────┘
                                   │
                         ┌─────────▼──────────┐
                         │        Hub         │  单一事实源
                         │ 广播 / 落库 / 触发 │
                         └───┬────────────┬───┘
                             │            │
              ┌──────────────▼──┐      ┌──▼─────────────────┐
              │   Queen 调度     │      │  AdapterManager     │
              │ 分诊 → DAG → 汇总│      │ 发送路由 + 生命周期 │
              └───┬──────────┬──┘      └──┬──────┬──────┬────┘
                  │          │            │      │      │
             LLM Router      │        OneBot  wxauto  Inject/Bridge
          fast/smart/deep    │         (QQ)   (微信)   (抖音/万能)
                  │          │
     ┌────────────▼───────┐  │
     │ DeepSeek / Ollama  │  │
     │ / Mock(离线规则)   │  │
     └────────────────────┘  │
                             │
                    ┌────────▼────────┐
                    │ SQLite + 技能包 │
                    └─────────────────┘
```

## 一次起稿的时序

```
UI                Hub              Queen                   LLM               Store
│ POST compose     │                 │                      │                  │
├─────────────────►│ run_compose     │                      │                  │
│                  ├────────────────►│ 分诊（规则，0 次调用）│                  │
│                  │                 ├─ 检索技能（本地）    │                  │
│                  │                 ├─ perceive ──────────►│                  │
│                  │                 ├─ scout ─────────────►│  (并行)          │
│                  │◄── trace 事件 ──┤                      │                  │
│◄─ WS trace ──────┤                 ├─ strategize ────────►│                  │
│                  │                 ├─ draft ×3 ──────────►│  并行            │
│                  │                 ├─ polish ×N ─────────►│  仅当 lint < 88  │
│                  │                 ├─ critic ────────────►│                  │
│                  │                 ├─ rank / 返工         │                  │
│                  │                 ├─ 事实入库 ───────────┼─────────────────►│
│                  │◄── draft.ready ─┤                      │                  │
│◄─ WS draft ──────┤                 │                      │                  │
│ POST send        │                 │                      │                  │
├─────────────────►│ adapter.send    │                      │                  │
│                  ├─ 成功：写 out 消息 + 信息素 +1          │                  │
```

## 分层

| 层 | 模块 | 职责 |
|---|---|---|
| L0 | `swarm/queen.py` `decide()` | 看这句话值不值得开大：小分队（1 稿）/ 标准（3 稿）/ 深潜（4 稿 + 返工） |
| L1 | `_perceive` `_scout` | 判意图情绪潜台词；抽事实话头雷区。并行，用 fast 档 |
| L2 | `_strategize` `_critic` | 定目标打法禁忌；五项打分 + 反模式。用 smart 档 |
| L3 | `_draft_many` `_polish_many` | 多角度并行起稿；确定性改写 + 模型打磨 |

`TraceEvent` 带 `level`，前端按层级缩进渲染成轨迹。

## 数据模型

```sql
contacts(id, name, platform, platform_uid, stage, notes, tags, avatar, created_at, updated_at)
messages(id, contact_id, direction, text, ts, platform, sender, external_id, meta)
drafts(id, contact_id, run_id, variants[Json], status, chosen, final_text, created_at)
runs(id, contact_id, trigger, formation, situation[Json], strategy[Json], usage[Json], duration_ms, error, created_at)
facts(id, contact_id, key, value, confidence, source, ts)
style_samples(id, text, ts)          -- 你自己发过的话，作为风格 few-shot
tactics(name, intent, tries, wins, last_ts)   -- 信息素
settings(key, value)                 -- 例如前端当前选中的会话
events(id, kind, payload, ts)        -- 审计
```

关系阶段：`陌生 → 破冰 → 熟悉 → 暧昧 → 邀约 → 确认`。阶段会影响军师蜂的推进幅度，也会影响反模式（早期叫「宝贝」直接判越界）。

## WebSocket 协议

服务端 → 客户端：

| type | 负载 | 用途 |
|---|---|---|
| `hello` | client, active_contact_id | 握手 |
| `presence` | clients[] | 哪台设备在线（电脑/手机） |
| `message.new` | contact_id, message, contact | 新消息（双向同步） |
| `run.start` | run_id, contact_id, trigger | 一轮开始 |
| `trace` | node, level, phase, ms, summary | 每一步 |
| `stage` | label | 当前阶段（显示在驾驶舱） |
| `draft.ready` | draft, situation, strategy, formation, usage | 出稿 |
| `draft.sent` / `draft.approved` | draft_id, text, mode | 发送结果 |
| `toast` | message, level | 提示 |
| `adapters` / `config.updated` / `state` | — | 状态同步 |

客户端 → 服务端：`ping`、`focus`（当前会话，剪贴板桥按它归档）、`presence`、`compose`。

## 发送路由

```
contact.platform → [首选, 兜底, 最后]
qq      → onebot → inject → manual
wechat  → wxauto → inject → manual
douyin  → douyin(inject) → manual
其他    → inject → manual
```

- `inject` 找不到聊天窗口时**绝不会**往随便哪个前台窗口粘贴，而是转成「复制」并明说。
- `manual` 永远成功，返回 `mode: "copy"`，前端把文本塞进剪贴板。
- 只有真正投递成功（非 copy）才写 `out` 消息、才给打法加胜场。

## 预算与降级

```
Budget(max_calls=18, max_seconds=75)
  ├─ 每次 LLM 调用前 check()
  ├─ 可选节点（polish/critic/返工）calls 不够就跳过
  └─ 全部失败 → 兜底稿（保证永远有东西可发）
```

模型降级链：`配置的 provider → offline_fallback(mock)`。
DeepSeek 没配 key 时，`provider_name()` 直接返回 mock，不浪费一次失败调用。

## 去 AI 味的实现

打磨蜂做两件事，顺序固定：

1. `tidy()`：等义替换 + 标点收敛，纯确定性。
2. 若 `lint(score) < 88` 且预算允许，让模型再改一版，改完重新 lint，**分数更高才采纳**。

所以这一层不可能把稿子改差，最坏情况是保持原样。

## 扩展点

- **加一个平台**：继承 `adapters/base.py:Adapter`，在 `registry.py` 注册，在 `ROUTES` 里排优先级。
- **加一个蜂**：写 `async def _mybee(...)`，在 `compose()` 里决定插在哪一层，用 `tracer.begin/end` 打点。
- **加一个技能包**：目录 + `SKILL.md`（`##` 分节），或 `python -m hivewing skill import`。
- **换模型**：实现 `Provider.chat()`，在 `LLMRouter.providers` 注册。

## 安全

- 默认只监听 `0.0.0.0` 但**所有业务接口都要 token**；token 首次启动随机生成。
- `/api/bootstrap` 返回的 api_key 已打码；设置接口拒绝写入掩码值。
- 前端不存 key，key 只在 `config.yaml` 和后端内存。
- 发送限速：默认每分钟 6 条。
