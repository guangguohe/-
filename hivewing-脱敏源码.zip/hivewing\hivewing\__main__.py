"""命令行入口：python -m hivewing <command>"""
from __future__ import annotations

import argparse
import asyncio
import sys
import threading
import time
import webbrowser

from . import __version__
from .config import Config
from .db import Store
from .util import ROOT, local_ip, setup_logging


def _port_in_use(port: int) -> bool:
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


def _looks_like_hivewing(port: int) -> bool:
    import json
    import urllib.request

    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/health", timeout=2) as r:
            return bool(json.loads(r.read().decode()).get("ok"))
    except Exception:  # noqa: BLE001
        return False


def cmd_serve(args) -> int:
    setup_logging()
    cfg = Config()
    cfg.ensure_file()
    host = args.host or str(cfg.get("server.host", "0.0.0.0"))
    port = int(args.port or cfg.get("server.port", 8760))
    cfg.set("server.host", host)
    cfg.set("server.port", port)
    if args.offline:
        cfg.set("llm.default_provider", "mock")
    cfg.set("server.public_base", f"http://{local_ip()}:{port}")
    cfg.save()
    local = f"http://127.0.0.1:{port}/?token={cfg.token}"
    lan = f"http://{local_ip()}:{port}/?token={cfg.token}"

    # 已经在跑就别再开一个（重复双击 start.bat 很常见）
    if _port_in_use(port):
        if _looks_like_hivewing(port):
            print(f"\n  蜂群僚机已经在 {port} 端口跑着了，不用再开一个。\n")
            print(f"  电脑：{local}")
            print(f"  手机：{lan}\n")
            print("  想重启：先关掉原来那个黑窗口，再运行本脚本。\n")
            if not args.no_open:
                webbrowser.open(local)
            return 0
        print(f"\n  端口 {port} 被别的程序占用了。\n")
        print("  换一个端口启动：python -m hivewing serve --port 8761\n")
        return 1

    provider = str(cfg.get("llm.default_provider", "deepseek"))
    if provider == "deepseek" and not cfg.get("llm.providers.deepseek.api_key"):
        provider = "mock（离线引擎：DeepSeek 未配 key，自动降级）"
    elif provider == "ollama":
        provider = f"ollama（{cfg.get('llm.providers.ollama.base_url')}）"

    banner = f"""
  ⬡  HiveWing 蜂群僚机 {__version__}
  ─────────────────────────────────────────────
  电脑打开   {local}
  手机打开   {lan}
  模型       {provider}
  数据库     {cfg.db_path}
  ─────────────────────────────────────────────
  手机和电脑连同一个 Wi-Fi；二维码在界面右上角 ⚙ →「手机配对」
  停止：Ctrl+C
"""
    print(banner)
    if not args.no_open:
        threading.Thread(target=lambda: (time.sleep(1.6), webbrowser.open(local)), daemon=True).start()

    import uvicorn

    from .server.app import app

    uvicorn.run(app, host=host, port=port, log_level="warning", access_log=False)
    return 0


def cmd_doctor(args) -> int:
    from .config import Config
    from .db import Store
    from .llm.router import LLMRouter
    from .skills.loader import SkillLibrary

    cfg = Config()
    print(f"HiveWing {__version__} 自检\n")
    ok = "✅"
    bad = "❌"

    try:
        store = Store(cfg.db_path)
        print(f"{ok} 数据库         {cfg.db_path} {store.stats()}")
        store.close()
    except Exception as exc:  # noqa: BLE001
        print(f"{bad} 数据库         {exc}")

    lib = SkillLibrary(cfg.get("skills.dirs"), cfg.get("skills.active")).load()
    stats = lib.stats()
    print(f"{ok} 技能包         {len(stats['packs'])} 个 / {stats['sections']} 节 / {stats['chars']} 字")
    for p in stats["packs"]:
        print(f"                 · {p['slug']}：{p['sections']} 节")

    async def health():
        router = LLMRouter(cfg)
        try:
            return await router.health()
        finally:
            await router.close()

    h = asyncio.run(health())
    for name in ("deepseek", "ollama", "mock"):
        info = h.get(name) or {}
        mark = ok if info.get("ok") else ("⚪" if name != "mock" else bad)
        print(f"{mark} {name:<14} {info.get('detail', '')}")
    print(f"\n当前生效模型：{h.get('active')}")

    print("\n发送通道：")
    for name in ("manual", "inject", "onebot", "wxauto", "douyin", "bridge"):
        enabled = cfg.get(f"adapters.{name}.enabled")
        print(f"  · {name:<8} {'已启用' if enabled else '未启用'}")

    if sys.platform == "win32":
        print("\n提示：微信需要 pip install wxauto；QQ 需要 NapCat；抖音用 Ctrl+Alt+H 剪贴板桥。")
    return 0


def cmd_compose(args) -> int:
    from .context import build_context
    from .llm.router import LLMRouter
    from .skills.loader import SkillLibrary
    from .swarm.queen import Queen

    setup_logging()
    cfg = Config()
    if args.offline:
        cfg.set("llm.default_provider", "mock")
    store = Store(cfg.db_path)
    skills = SkillLibrary(cfg.get("skills.dirs"), cfg.get("skills.active")).load()
    contact = store.find_contact("manual", args.contact) or store.ensure_contact(args.contact or "临时会话", "manual", args.contact or "")
    if args.text:
        from .models import Message
        from .util import new_id, now

        store.add_message(Message(id=new_id("m_"), contact_id=contact.id, direction="in",
                                  text=args.text, ts=now(), platform="manual", sender="her"))
    ctx = build_context(cfg, store, contact)
    if not ctx.incoming:
        print("没有可回复的消息，用 --text 给一句她的话")
        return 1

    async def run():
        router = LLMRouter(cfg)
        q = Queen(cfg, store, skills, router)
        result = await q.compose(contact, trigger="manual", formation=args.formation)
        print(f"\n她：{ctx.incoming}")
        print(f"局势：{result.situation.get('intent')} · {result.situation.get('signal')}")
        print(f"打法：{result.strategy.get('goal')}")
        print(f"队形：{result.formation} · {result.duration_ms}ms · {result.usage.get('calls')} 次模型调用\n")
        for v in result.drafts.variants:
            flag = "⛔" if v.blocked else "  "
            print(f"{flag} [{v.score:5.1f}] {v.angle}｜{v.text}")
            if v.why:
                print(f"        {v.why}")
            for issue in (v.issues or [])[:2]:
                print(f"        · {issue}")
        await router.close()

    asyncio.run(run())
    store.close()
    return 0


def cmd_skill(args) -> int:
    from .skills.loader import SkillLibrary

    cfg = Config()
    lib = SkillLibrary(cfg.get("skills.dirs"), cfg.get("skills.active")).load()
    if args.action == "list":
        for p in lib.list_packs():
            print(f"{p['slug']:<20} {p['sections']:>3} 节  {p['name']}")
        return 0
    if args.action == "import":
        if not args.url:
            print("用法：python -m hivewing skill import https://github.com/owner/repo")
            return 1
        result = lib.import_from_github(args.url)
        print(f"导入 {result['pack']}：{result['files']} 个文件 -> {result['path']}")
        active = list(cfg.get("skills.active", []))
        if result["pack"] not in active:
            active.append(result["pack"])
            cfg.set("skills.active", active)
            cfg.save()
        return 0
    if args.action == "reload":
        print(lib.load().stats())
        return 0
    return 1


def cmd_seed(args) -> int:
    from .db import Store
    from .server.app import seed_demo

    cfg = Config()
    store = Store(cfg.db_path)
    if store.stats()["contacts"] and not args.force:
        print("已经有会话了，加 --force 再灌")
        return 1
    seed_demo(store)
    print("演示数据已写入", store.stats())
    store.close()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="hivewing", description="HiveWing 蜂群僚机")
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="cmd")

    p = sub.add_parser("serve", help="启动服务（PC + 手机）")
    p.add_argument("--host", default=None)
    p.add_argument("--port", type=int, default=None)
    p.add_argument("--no-open", action="store_true")
    p.add_argument("--offline", action="store_true", help="强制用离线引擎")
    p.set_defaults(func=cmd_serve)

    p = sub.add_parser("doctor", help="环境自检")
    p.set_defaults(func=cmd_doctor)

    p = sub.add_parser("compose", help="命令行起稿")
    p.add_argument("--contact", default="")
    p.add_argument("--text", default="")
    p.add_argument("--formation", default="standard")
    p.add_argument("--offline", action="store_true")
    p.set_defaults(func=cmd_compose)

    p = sub.add_parser("skill", help="技能包管理")
    p.add_argument("action", choices=["list", "import", "reload"])
    p.add_argument("url", nargs="?")
    p.set_defaults(func=cmd_skill)

    p = sub.add_parser("seed", help="灌演示数据")
    p.add_argument("--force", action="store_true")
    p.set_defaults(func=cmd_seed)

    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 0
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
