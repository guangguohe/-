"""适配器基类：所有平台接入都实现这几个方法。"""
from __future__ import annotations

import asyncio
import time
from typing import Any

from ..util import log

LOG = log("adapter")


class Adapter:
    name = "base"
    platform = "manual"
    title = "基类"
    capabilities = {"recv": False, "send": False, "auto": False}
    note = ""

    def __init__(self, hub, cfg):
        self.hub = hub
        self.cfg = cfg
        self.running = False
        self.error = ""
        self.started_at = 0.0
        self.last_event = ""
        self._loop: asyncio.AbstractEventLoop | None = None

    # -------- 生命周期 --------
    async def start(self) -> None:
        self._loop = asyncio.get_running_loop()
        self.running = True
        self.error = ""
        self.started_at = time.time()

    async def stop(self) -> None:
        self.running = False

    # -------- 收发 --------
    async def send(self, contact, text: str) -> dict:
        return {"ok": False, "mode": "none", "detail": f"{self.title} 不支持发送"}

    # -------- 线程 -> 事件循环 --------
    def submit(self, coro) -> None:
        if self._loop and self._loop.is_running():
            asyncio.run_coroutine_threadsafe(coro, self._loop)
        else:
            LOG.warning("%s 没有可用事件循环，丢弃事件", self.name)

    def status(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "platform": self.platform,
            "title": self.title,
            "enabled": bool(self.cfg.get(f"adapters.{self.name}.enabled", False)),
            "running": self.running,
            "error": self.error,
            "detail": self.note,
            "capabilities": self.capabilities,
            "uptime": int(time.time() - self.started_at) if self.started_at else 0,
            "last_event": self.last_event,
        }

    # -------- 工具 --------
    def enabled(self) -> bool:
        return bool(self.cfg.get(f"adapters.{self.name}.enabled", False))
