"""剪贴板桥：全局热键，把任意聊天软件里复制的她的消息送进蜂群。

Ctrl+Alt+H  ->  读剪贴板 -> 归到「当前会话」-> 自动跑一轮蜂群
这是抖音、QQ、微信、甚至相亲 App 的通用入口，不需要任何协议。
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import threading

from ..util import log
from .base import Adapter
from .windows import IS_WINDOWS, MOD_ALT, MOD_CONTROL, VK_H, get_clipboard

LOG = log("bridge")
WM_HOTKEY = 0x0312
WM_QUIT = 0x0012


class ClipboardBridge(Adapter):
    name = "bridge"
    platform = "clipboard"
    title = "剪贴板桥（全局热键）"
    capabilities = {"recv": True, "send": False, "auto": True}
    note = "复制她的消息后按 Ctrl+Alt+H，自动归到当前会话并起稿"

    def __init__(self, hub, cfg):
        super().__init__(hub, cfg)
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._tid = 0
        self._user32 = None
        self._kernel32 = None

    async def start(self) -> None:
        await super().start()
        if not IS_WINDOWS:
            self.error = "仅支持 Windows"
            self.running = False
            return
        self._user32 = ctypes.WinDLL("user32", use_last_error=True)
        self._kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="clipboard-bridge", daemon=True)
        self._thread.start()

    async def stop(self) -> None:
        self.running = False
        self._stop.set()
        if self._tid and self._user32:
            self._user32.PostThreadMessageW(self._tid, WM_QUIT, 0, 0)

    def _run(self) -> None:
        user32 = self._user32
        kernel32 = self._kernel32
        self._tid = kernel32.GetCurrentThreadId()
        ok = user32.RegisterHotKey(None, 1, MOD_CONTROL | MOD_ALT, VK_H)
        if not ok:
            self.error = "热键 Ctrl+Alt+H 被占用，注册失败"
            self.running = False
            LOG.warning(self.error)
            return
        self.note = "热键 Ctrl+Alt+H 已注册：复制她的消息后按一下"
        msg = wt.MSG()
        try:
            while not self._stop.is_set():
                ret = user32.GetMessageW(ctypes.byref(msg), None, 0, 0)
                if ret <= 0:
                    break
                if msg.message == WM_HOTKEY:
                    self._on_hotkey()
        finally:
            user32.UnregisterHotKey(None, 1)

    def _on_hotkey(self) -> None:
        text = (get_clipboard() or "").strip()
        if not text:
            self.last_event = "hotkey:empty"
            self.submit(self.hub.toast("剪贴板是空的，先复制她那条消息"))
            return
        if len(text) > 1000:
            text = text[:1000]
        self.last_event = f"hotkey:{text[:16]}"
        self.submit(self.hub.ingest_from_bridge(text))

    async def send(self, contact, text: str) -> dict:
        return {"ok": False, "mode": "bridge", "detail": "剪贴板桥只负责收，不负责发"}
