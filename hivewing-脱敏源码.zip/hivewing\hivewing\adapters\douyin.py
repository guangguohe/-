"""抖音接入（实验性）。

抖音没有开放的私聊 API，也不建议用逆向协议（封号 + 不稳定）。这里的做法是：
- 收：复制她的消息 -> 全局热键 Ctrl+Alt+H（剪贴板桥）-> 进入蜂群
- 发：通用注入，把回复直接粘进抖音 PC 端输入框
"""
from __future__ import annotations

from .base import Adapter
from .inject import InjectAdapter


class DouyinAdapter(Adapter):
    name = "douyin"
    platform = "douyin"
    title = "抖音（剪贴板桥 + 注入）"
    capabilities = {"recv": False, "send": True, "auto": False}
    note = "无官方私聊 API。收消息用 Ctrl+Alt+H 剪贴板桥，发消息用通用注入到抖音 PC 端"

    def __init__(self, hub, cfg):
        super().__init__(hub, cfg)
        self._sender = InjectAdapter(hub, cfg)

    async def start(self) -> None:
        await super().start()
        await self._sender.start()

    async def stop(self) -> None:
        await super().stop()
        await self._sender.stop()

    async def send(self, contact, text: str) -> dict:
        result = await self._sender.send(contact, text)
        result["mode"] = "douyin-inject"
        if result.get("ok"):
            result["detail"] = "已粘进抖音输入框，检查后回车发送"
        return result
