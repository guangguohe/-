"""通用注入：把回复直接粘进微信/QQ/抖音的输入框。

原理：枚举窗口标题找到聊天软件主窗口 -> 前置 -> 剪贴板写入 -> Ctrl+V。
不依赖任何协议，也就不存在封号风险；代价是要求 PC 端聊天软件在场。
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import time

from ..util import log
from .base import Adapter
from .windows import IS_WINDOWS, get_clipboard, paste_text, set_clipboard

LOG = log("inject")

WINDOW_HINTS = {
    "qq": ["QQ", "qq"],
    "wechat": ["微信", "WeChat", "Weixin"],
    "douyin": ["抖音", "Douyin"],
}


def _user32():
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    proc = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)
    user32.EnumWindows.argtypes = [proc, wt.LPARAM]
    user32.EnumWindows.restype = wt.BOOL
    user32.IsWindowVisible.argtypes = [wt.HWND]
    user32.IsWindowVisible.restype = wt.BOOL
    user32.GetWindowTextLengthW.argtypes = [wt.HWND]
    user32.GetWindowTextLengthW.restype = ctypes.c_int
    user32.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
    user32.GetWindowTextW.restype = ctypes.c_int
    user32.ShowWindow.argtypes = [wt.HWND, ctypes.c_int]
    user32.ShowWindow.restype = wt.BOOL
    user32.SetForegroundWindow.argtypes = [wt.HWND]
    user32.SetForegroundWindow.restype = wt.BOOL
    user32.BringWindowToTop.argtypes = [wt.HWND]
    user32.GetForegroundWindow.restype = wt.HWND
    user32.keybd_event.argtypes = [wt.BYTE, wt.BYTE, wt.DWORD, ctypes.c_size_t]
    return user32


def find_window(keywords: list[str]) -> int:
    """按标题关键字找一个可见窗口。"""
    if not IS_WINDOWS:
        return 0
    user32 = _user32()
    found: list[int] = []
    proc_type = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)

    @proc_type
    def enum_proc(hwnd, _):
        if not user32.IsWindowVisible(hwnd):
            return True
        length = user32.GetWindowTextLengthW(hwnd)
        if length <= 0:
            return True
        buf = ctypes.create_unicode_buffer(length + 1)
        user32.GetWindowTextW(hwnd, buf, length + 1)
        title = buf.value
        if any(k.lower() in title.lower() for k in keywords):
            found.append(hwnd)
            return False
        return True

    user32.EnumWindows(enum_proc, 0)
    return found[0] if found else 0


def focus_window(hwnd: int) -> bool:
    if not IS_WINDOWS or not hwnd:
        return False
    user32 = _user32()
    user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    # 先用 ALT 骗过前台窗口限制，再 SetForegroundWindow（Windows 的经典做法）
    user32.keybd_event(0x12, 0, 0, 0)
    ok = bool(user32.SetForegroundWindow(hwnd))
    user32.keybd_event(0x12, 0, 2, 0)
    if not ok:
        user32.BringWindowToTop(hwnd)
        ok = user32.GetForegroundWindow() == hwnd
    time.sleep(0.12)
    return ok


class InjectAdapter(Adapter):
    name = "inject"
    platform = "universal"
    title = "通用注入（PC 聊天窗口）"
    capabilities = {"recv": False, "send": True, "auto": True}
    note = "把回复直接粘贴进微信/QQ/抖音的输入框；需要 PC 端聊天软件已打开"

    async def start(self) -> None:
        await super().start()
        if not IS_WINDOWS:
            self.error = "仅支持 Windows"
            self.running = False

    async def send(self, contact, text: str) -> dict:
        if not IS_WINDOWS:
            return {"ok": False, "mode": "inject", "detail": "仅支持 Windows"}
        hints = WINDOW_HINTS.get(contact.platform) or []
        hwnd = find_window(hints) if hints else 0
        if hints and not hwnd:
            # 聊天窗口不在，绝不往随便哪个窗口里粘
            set_clipboard(text)
            self.last_event = "copy:no-window"
            return {
                "ok": True,
                "mode": "copy",
                "detail": f"没找到{contact.platform}窗口，已复制到剪贴板，手动粘一下",
            }
        focused = focus_window(hwnd) if hwnd else False
        if hwnd and not focused:
            set_clipboard(text)
            self.last_event = "copy:no-focus"
            return {"ok": True, "mode": "copy", "detail": "窗口切换被系统拦了，已复制，手动粘一下"}
        if focused:
            time.sleep(0.15)
        result = paste_text(text, enter=False, restore=bool(self.cfg.get("adapters.inject.restore_clipboard", True)))
        result["mode"] = "inject"
        if hwnd:
            result["detail"] = result.get("detail", "") + "，检查后回车发送"
        self.last_event = "paste:window" if hwnd else "paste:focus"
        return result

    def copy_only(self, text: str) -> bool:
        return set_clipboard(text)
