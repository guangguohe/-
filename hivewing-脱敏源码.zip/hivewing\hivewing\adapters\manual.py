"""手动 / 剪贴板适配器：最稳的一条路，任何平台都能用。"""
from __future__ import annotations

from .base import Adapter


class ManualAdapter(Adapter):
    name = "manual"
    platform = "manual"
    title = "手动 / 剪贴板"
    capabilities = {"recv": False, "send": True, "auto": False}
    note = "在界面里粘贴她的消息，点「复制」后自己粘到聊天窗口"

    async def send(self, contact, text: str) -> dict:
        self.last_event = f"copy:{text[:20]}"
        return {"ok": True, "mode": "copy", "detail": "已标记发送，点复制按钮粘到聊天窗口"}
