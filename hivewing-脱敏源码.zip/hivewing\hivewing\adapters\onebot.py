"""QQ 接入：OneBot 11 协议（NapCat / Lagrange / LLOneBot 都兼容）。

发送：HTTP API  POST /send_private_msg
接收：反向 WebSocket，把连接指向  http://<本机>:8760/onebot/ws
"""
from __future__ import annotations

import re

import httpx

from ..util import log
from .base import Adapter

LOG = log("onebot")
CQ_RE = re.compile(r"\[CQ:[^\]]+\]")


def _text_of(message) -> str:
    if isinstance(message, str):
        return CQ_RE.sub("", message).strip()
    if isinstance(message, list):
        parts = []
        for seg in message:
            if isinstance(seg, dict) and seg.get("type") == "text":
                parts.append(str((seg.get("data") or {}).get("text", "")))
        return "".join(parts).strip()
    return str(message or "").strip()


class OneBotAdapter(Adapter):
    name = "onebot"
    platform = "qq"
    title = "QQ（OneBot 11）"
    capabilities = {"recv": True, "send": True, "auto": True}
    note = "NapCat 的 HTTP 上报 + 反向 WS 指向 /onebot/ws；私聊消息才会进来"

    def __init__(self, hub, cfg):
        super().__init__(hub, cfg)
        self._client: httpx.AsyncClient | None = None

    def _base(self) -> str:
        return str(self.cfg.get("adapters.onebot.api_base", "http://127.0.0.1:3000")).rstrip("/")

    def _headers(self) -> dict:
        token = str(self.cfg.get("adapters.onebot.access_token", "") or "")
        return {"Authorization": f"Bearer {token}"} if token else {}

    async def start(self) -> None:
        await super().start()
        self._client = httpx.AsyncClient(timeout=httpx.Timeout(20, connect=5), headers=self._headers())
        try:
            r = await self._client.post(f"{self._base()}/get_login_info", json={})
            data = r.json()
            nick = (data.get("data") or {}).get("nickname", "")
            self.note = f"已连接 {nick or self._base()}｜反向 WS: /onebot/ws"
        except Exception as exc:  # noqa: BLE001
            self.error = f"连不上 OneBot（{self._base()}）：{exc}"
            LOG.warning(self.error)

    async def stop(self) -> None:
        self.running = False
        if self._client:
            await self._client.aclose()
            self._client = None

    async def send(self, contact, text: str) -> dict:
        uid = (contact.platform_uid or "").strip()
        if not uid.isdigit():
            return {"ok": False, "mode": "onebot", "detail": f"QQ 号不合法：{uid!r}"}
        if not self._client:
            self._client = httpx.AsyncClient(timeout=20, headers=self._headers())
        try:
            r = await self._client.post(
                f"{self._base()}/send_private_msg",
                json={"user_id": int(uid), "message": text, "auto_escape": True},
            )
            data = r.json()
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "mode": "onebot", "detail": f"发送失败：{exc}"}
        if data.get("status") == "ok" or data.get("retcode") == 0:
            self.last_event = f"sent:{uid}"
            return {"ok": True, "mode": "onebot", "detail": f"已发送给 {contact.display}"}
        return {"ok": False, "mode": "onebot", "detail": f"OneBot 返回：{data}"}

    # 由 server 的 /onebot/ws 调用
    async def handle_event(self, payload: dict) -> None:
        if payload.get("post_type") != "message":
            return
        if payload.get("message_type") != "private":
            return
        self_id = str(self.cfg.get("adapters.onebot.self_id", "") or "")
        uid = str(payload.get("user_id", ""))
        if self_id and uid == self_id:
            return
        text = _text_of(payload.get("raw_message") or payload.get("message"))
        if not text:
            return
        sender = payload.get("sender") or {}
        name = str(sender.get("card") or sender.get("nickname") or uid)
        self.last_event = f"recv:{uid}"
        await self.hub.ingest(
            platform="qq",
            uid=uid,
            name=name,
            text=text,
            external_id=str(payload.get("message_id", "")),
            meta={"raw": "onebot"},
        )
