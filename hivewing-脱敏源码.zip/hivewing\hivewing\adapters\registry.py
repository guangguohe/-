"""适配器注册表与发送路由。"""
from __future__ import annotations

from .. import privacy
from ..util import log
from .base import Adapter
from .bridge import ClipboardBridge
from .douyin import DouyinAdapter
from .inject import InjectAdapter
from .manual import ManualAdapter
from .onebot import OneBotAdapter
from .wxauto_adapter import WxAutoAdapter

LOG = log("adapters")

# 会读取聊天内容的适配器：没做隐私授权一律不许启动
NEEDS_CONSENT = {"wxauto", "onebot", "douyin", "bridge"}

# 每个平台的首选发送顺序
ROUTES = {
    "qq": ["onebot", "inject", "manual"],
    "wechat": ["wxauto", "inject", "manual"],
    "douyin": ["douyin", "inject", "manual"],
    "clipboard": ["inject", "manual"],
    "universal": ["inject", "manual"],
    "manual": ["manual"],
}


class AdapterManager:
    def __init__(self, hub, cfg):
        self.hub = hub
        self.cfg = cfg
        self.adapters: dict[str, Adapter] = {
            a.name: a
            for a in (
                ManualAdapter(hub, cfg),
                InjectAdapter(hub, cfg),
                OneBotAdapter(hub, cfg),
                WxAutoAdapter(hub, cfg),
                DouyinAdapter(hub, cfg),
                ClipboardBridge(hub, cfg),
            )
        }

    async def start_enabled(self) -> None:
        for name, adapter in self.adapters.items():
            if adapter.enabled():
                try:
                    await adapter.start()
                    LOG.info("适配器 %s 已启动", name)
                except Exception as exc:  # noqa: BLE001
                    adapter.error = str(exc)[:200]
                    LOG.warning("适配器 %s 启动失败：%s", name, exc)

    async def stop_all(self) -> None:
        for adapter in self.adapters.values():
            try:
                await adapter.stop()
            except Exception:  # noqa: BLE001
                pass

    def get(self, name: str) -> Adapter | None:
        return self.adapters.get(name)

    def statuses(self) -> list[dict]:
        return [a.status() for a in self.adapters.values()]

    async def start(self, name: str) -> dict:
        adapter = self.get(name)
        if not adapter:
            return {"ok": False, "detail": f"没有适配器 {name}"}
        if name in NEEDS_CONSENT and not privacy.state(self.cfg)["granted"]:
            return {
                "ok": False,
                "need_consent": True,
                "detail": "这个通道会读你的聊天内容，得先完成隐私授权",
            }
        self.cfg.set(f"adapters.{name}.enabled", True)
        await adapter.start()
        return {"ok": True, "status": adapter.status()}

    async def stop(self, name: str) -> dict:
        adapter = self.get(name)
        if not adapter:
            return {"ok": False, "detail": f"没有适配器 {name}"}
        self.cfg.set(f"adapters.{name}.enabled", False)
        await adapter.stop()
        return {"ok": True, "status": adapter.status()}

    async def send(self, contact, text: str) -> dict:
        order = ROUTES.get(contact.platform, ["inject", "manual"])
        tried = []
        for name in order:
            adapter = self.adapters.get(name)
            if not adapter:
                continue
            if name != "manual" and not adapter.running:
                tried.append(f"{name}(未启动)")
                continue
            result = await adapter.send(contact, text)
            if result.get("ok"):
                result["adapter"] = name
                return result
            tried.append(f"{name}: {result.get('detail', '')}")
        return {"ok": False, "mode": "none", "detail": "；".join(tried) or "没有可用的发送通道"}
