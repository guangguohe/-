"""Windows 剪贴板 / 按键注入（纯 ctypes，无第三方依赖）。

用途：
- 「通用注入」发送：把文本写进剪贴板，再给前台窗口发 Ctrl+V。任何聊天软件都能用。
- 「剪贴板桥」接收：用户复制她的消息后按热键，直接进入蜂群。
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import sys
import time

CF_UNICODETEXT = 13
GMEM_MOVEABLE = 0x0002
VK_CONTROL = 0x11
VK_V = 0x56
VK_RETURN = 0x0D
VK_H = 0x48
KEYEVENTF_KEYUP = 0x0002
MOD_ALT = 0x0001
MOD_CONTROL = 0x0002
MOD_SHIFT = 0x0004
WM_HOTKEY = 0x0312

IS_WINDOWS = sys.platform == "win32"

if IS_WINDOWS:
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

    user32.OpenClipboard.argtypes = [wt.HWND]
    user32.OpenClipboard.restype = wt.BOOL
    user32.CloseClipboard.restype = wt.BOOL
    user32.EmptyClipboard.restype = wt.BOOL
    user32.SetClipboardData.argtypes = [wt.UINT, wt.HANDLE]
    user32.SetClipboardData.restype = wt.HANDLE
    user32.GetClipboardData.argtypes = [wt.UINT]
    user32.GetClipboardData.restype = wt.HANDLE
    user32.IsClipboardFormatAvailable.argtypes = [wt.UINT]
    user32.IsClipboardFormatAvailable.restype = wt.BOOL
    kernel32.GlobalAlloc.argtypes = [wt.UINT, ctypes.c_size_t]
    kernel32.GlobalAlloc.restype = wt.HGLOBAL
    kernel32.GlobalLock.argtypes = [wt.HGLOBAL]
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalUnlock.argtypes = [wt.HGLOBAL]
    kernel32.GlobalFree.argtypes = [wt.HGLOBAL]
    user32.GetForegroundWindow.restype = wt.HWND
    user32.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
    user32.keybd_event.argtypes = [wt.BYTE, wt.BYTE, wt.DWORD, ctypes.c_size_t]


def get_clipboard() -> str:
    if not IS_WINDOWS:
        return ""
    if not user32.IsClipboardFormatAvailable(CF_UNICODETEXT):
        return ""
    if not user32.OpenClipboard(None):
        return ""
    try:
        handle = user32.GetClipboardData(CF_UNICODETEXT)
        if not handle:
            return ""
        ptr = kernel32.GlobalLock(handle)
        if not ptr:
            return ""
        try:
            return ctypes.wstring_at(ptr)
        finally:
            kernel32.GlobalUnlock(handle)
    finally:
        user32.CloseClipboard()


def set_clipboard(text: str) -> bool:
    if not IS_WINDOWS:
        return False
    data = (text or "").encode("utf-16-le") + b"\x00\x00"
    if not user32.OpenClipboard(None):
        return False
    try:
        user32.EmptyClipboard()
        handle = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(data))
        if not handle:
            return False
        ptr = kernel32.GlobalLock(handle)
        if not ptr:
            kernel32.GlobalFree(handle)
            return False
        ctypes.memmove(ptr, data, len(data))
        kernel32.GlobalUnlock(handle)
        if not user32.SetClipboardData(CF_UNICODETEXT, handle):
            kernel32.GlobalFree(handle)
            return False
        return True
    finally:
        user32.CloseClipboard()


def _key(vk: int, up: bool = False) -> None:
    user32.keybd_event(vk, 0, KEYEVENTF_KEYUP if up else 0, 0)


def send_paste() -> bool:
    """给当前前台窗口发 Ctrl+V。"""
    if not IS_WINDOWS:
        return False
    _key(VK_CONTROL)
    _key(VK_V)
    time.sleep(0.03)
    _key(VK_V, up=True)
    _key(VK_CONTROL, up=True)
    return True


def send_enter() -> bool:
    if not IS_WINDOWS:
        return False
    _key(VK_RETURN)
    time.sleep(0.02)
    _key(VK_RETURN, up=True)
    return True


def foreground_title() -> str:
    if not IS_WINDOWS:
        return ""
    hwnd = user32.GetForegroundWindow()
    buf = ctypes.create_unicode_buffer(256)
    user32.GetWindowTextW(hwnd, buf, 256)
    return buf.value


def paste_text(text: str, enter: bool = False, restore: bool = True) -> dict:
    """把 text 粘进当前焦点窗口。返回结果描述。"""
    if not IS_WINDOWS:
        return {"ok": False, "detail": "仅支持 Windows"}
    prev = get_clipboard() if restore else ""
    if not set_clipboard(text):
        return {"ok": False, "detail": "写剪贴板失败（可能被其他程序占用）"}
    time.sleep(0.05)
    send_paste()
    if enter:
        time.sleep(0.15)
        send_enter()
    if restore and prev:
        time.sleep(0.25)
        set_clipboard(prev)
    return {"ok": True, "detail": f"已粘贴到「{foreground_title() or '当前窗口'}」"}
