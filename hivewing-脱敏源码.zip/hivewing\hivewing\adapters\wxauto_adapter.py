"""微信接入：wxauto（Windows 微信客户端 UI 自动化）。

需要先 `pip install wxauto`，登录 PC 微信，并保持窗口不要最小化。
wxauto 版本之间 API 有差异，这里做了兼容与明确报错。
"""
from __future__ import annotations

import threading
import time

from ..util import log
from .base import Adapter

LOG = log("wxauto")


class WxAutoAdapter(Adapter):
    name = "wxauto"
    platform = "wechat"
    title = "微信（wxauto）"
    capabilities = {"recv": True, "send": True, "auto": True}
    note = "需要 pip install wxauto + 登录 PC 微信；在「设置-适配器」里开启"

    def __init__(self, hub, cfg):
        super().__init__(hub, cfg)
        self._wx = None
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._seen: set[str] = set()

    async def start(self) -> None:
        await super().start()
        try:
            from wxauto import WeChat  # type: ignore
        except Exception as exc:  # noqa: BLE001
            self.error = (
                "没装 wxauto，自动读不了微信。"
                "先用「剪贴板桥 + 通用注入」顶着：微信里复制她的话，按 Ctrl+Alt+H。"
                f"（{exc}）"
            )
            self.running = False
            return
        try:
            self._wx = WeChat()
            who = getattr(self._wx, "nickname", "")
            self.note = f"已接管微信（{who}）；轮询间隔 {self.cfg.get('adapters.wxauto.poll_interval', 1.2)}s"
        except Exception as exc:  # noqa: BLE001
            self.error = f"找不到微信窗口：{exc}"
            self.running = False
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._poll_loop, name="wxauto-poll", daemon=True)
        self._thread.start()

    async def stop(self) -> None:
        self.running = False
        self._stop.set()
        self._wx = None

    def _poll_loop(self) -> None:
        interval = float(self.cfg.get("adapters.wxauto.poll_interval", 1.2) or 1.2)
        while not self._stop.is_set():
            try:
                msgs = self._fetch()
                for m in msgs:
                    self._handle(m)
            except Exception as exc:  # noqa: BLE001
                LOG.debug("wxauto 轮询异常：%s", exc)
            self._stop.wait(interval)

    def _fetch(self) -> list[dict]:
        wx = self._wx
        if wx is None:
            return []
        # wxauto 3.x
        if hasattr(wx, "GetNextNewMessage"):
            item = wx.GetNextNewMessage()  # type: ignore[attr-defined]
            if not item:
                return []
            if isinstance(item, dict):
                return [item]
            if isinstance(item, list):
                return [i for i in item if isinstance(i, dict)]
            return []
        # wxauto 4.x：一次性取当前会话列表
        if hasattr(wx, "GetAllMessage"):
            batch = wx.GetAllMessage()  # type: ignore[attr-defined]
            out = []
            for m in batch or []:
                key = f"{getattr(m, 'sender', '')}:{getattr(m, 'content', '')}"
                if key in self._seen:
                    continue
                self._seen.add(key)
                out.append({"sender": getattr(m, "sender", ""), "content": getattr(m, "content", "")})
            return out
        return []

    def _handle(self, item: dict) -> None:
        if str(item.get("type", "friend")) == "self":
            return
        sender = str(item.get("sender") or item.get("chat_name") or "").strip()
        content = str(item.get("content") or "").strip()
        if not sender or not content:
            return
        if sender in ("SYS", "系统消息", "Self", "self"):
            return
        key = f"{sender}:{content}"
        if key in self._seen:
            return
        self._seen.add(key)
        if len(self._seen) > 500:
            self._seen = set(list(self._seen)[-200:])
        self.last_event = f"recv:{sender}"
        self.submit(
            self.hub.ingest(platform="wechat", uid=sender, name=sender, text=content, meta={"raw": "wxauto"})
        )

    async def send(self, contact, text: str) -> dict:
        if self._wx is None:
            return {"ok": False, "mode": "wxauto", "detail": "微信未接管，请先启动适配器"}
        who = contact.platform_uid or contact.name
        try:
            self._wx.SendMsg(msg=text, who=who)  # type: ignore[attr-defined]
            time.sleep(float(self.cfg.get("adapters.wxauto.send_delay", 0.6) or 0.6))
            self.last_event = f"sent:{who}"
            return {"ok": True, "mode": "wxauto", "detail": f"已发送给 {who}"}
        except TypeError:
            try:
                self._wx.SendMsg(text, who)  # type: ignore[call-arg]
                return {"ok": True, "mode": "wxauto", "detail": f"已发送给 {who}"}
            except Exception as exc:  # noqa: BLE001
                return {"ok": False, "mode": "wxauto", "detail": str(exc)[:160]}
        except Exception as exc:  # noqa: BLE001
            return {"ok": False, "mode": "wxauto", "detail": str(exc)[:160]}
