"""配置：config.yaml + 环境变量覆盖，支持热保存。"""
from __future__ import annotations

import copy
import os
from pathlib import Path
from typing import Any

import yaml

from .util import ROOT, log, new_id

LOG = log("config")

DEFAULT_CONFIG: dict[str, Any] = {
    "server": {
        "host": "0.0.0.0",          # 手机要连就必须监听局域网；接口有 token 保护
        "port": 8760,
        "auth_token": "",          # 空 = 启动时自动生成
        "public_base": "",         # 手机访问用的地址，空 = 自动探测局域网 IP
    },
    "llm": {
        "default_provider": "deepseek",   # deepseek | ollama | mock
        "offline_fallback": "mock",       # 云端失败时降级到本地/离线
        "temperature": 0.8,
        "providers": {
            "deepseek": {
                "api_key": "",
                "base_url": "https://api.deepseek.com",
                "model_fast": "deepseek-chat",
                "model_smart": "deepseek-chat",
                "model_deep": "deepseek-reasoner",
                "timeout": 90,
            },
            "ollama": {
                "base_url": "http://127.0.0.1:11434",
                "model_fast": "qwen2.5:3b",
                "model_smart": "qwen2.5:7b",
                "model_deep": "qwen2.5:7b",
                "timeout": 180,
            },
        },
        "routing": {
            "perceive": "fast",
            "scout": "fast",
            "strategize": "smart",
            "draft": "smart",
            "polish": "fast",
            "critic": "smart",
            "escalate": "deep",
        },
        "budget": {
            "max_llm_calls": 18,
            "max_seconds": 75,
            "draft_variants": 3,
        },
    },
    "persona": {
        "nickname": "",
        "age": None,
        "city": "",
        "job": "",
        "self_description": "",
        "tone": {"warmth": 0.55, "directness": 0.55, "humor": 0.5, "brevity": 0.75},
        "taboos": [],
        "signature": "",           # 口头禅，例如「笑死」「就那样」
    },
    "goal": {
        "stage": "auto",           # 陌生/破冰/熟悉/暧昧/邀约/确认；auto = 自动判断
        "intent": "聊得自然、推进关系，不着急",   # 你当前这段关系的目标
    },
    "safety": {
        "require_human_approval": True,   # 默认人工确认后再发
        "block_manipulation": True,       # 拦截 PUA/卖惨/道德绑架
        "max_sends_per_minute": 6,
        "max_chars": 120,
        "allow_auto_send": False,
    },
    "privacy": {
        "consent_at": 0,            # 用户点「同意」的时间，0 = 没同意过
        "consent_scope": [],        # 同意范围：read_chat / local_store / cloud_llm / send_confirm
        "strict_confirm": True,     # 每条发送都要人工确认，不允许关
        "redact_pii": True,         # 发云端前打码手机号/身份证/邮箱
        "local_only": True,         # 默认只在本机跑；要用云端的必须手动关掉并勾选
        "retain_days": 0,           # 0 = 永久保留；>0 启动时清理更早的消息
    },
    "adapters": {
        "manual": {"enabled": True},
        "inject": {"enabled": True, "restore_clipboard": True},
        "onebot": {
            "enabled": False,
            "api_base": "http://127.0.0.1:3000",
            "access_token": "",
            "self_id": "",
            "reverse_ws": True,
        },
        "wxauto": {"enabled": False, "poll_interval": 1.2, "send_delay": 0.6},
        "douyin": {"enabled": False, "window_title": "抖音", "poll_interval": 2.0},
        "bridge": {"enabled": False},
    },
    "skills": {
        "dirs": ["skills/packs"],
        "active": ["tong-jincheng", "hivewing-core"],
        "max_chars": 9000,
    },
    "db": "data/hivewing.db",
    "ui": {"title": "蜂群僚机", "theme": "amber"},
}


def deep_merge(base: dict, patch: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (patch or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out


class Config:
    def __init__(self, path: Path | None = None, data: dict | None = None):
        self.path = Path(path) if path else ROOT / "config.yaml"
        self.data = deep_merge(DEFAULT_CONFIG, data or {})
        if self.path.exists() and not data:
            try:
                loaded = yaml.safe_load(self.path.read_text("utf-8")) or {}
                self.data = deep_merge(DEFAULT_CONFIG, loaded)
            except Exception as exc:  # noqa: BLE001
                LOG.warning("config.yaml 读取失败，用默认配置: %s", exc)
        self._apply_env()
        if not self.get("server.auth_token"):
            self.set("server.auth_token", new_id("tk_"))

    # ---------- 访问 ----------
    def get(self, dotted: str, default=None):
        cur: Any = self.data
        for part in dotted.split("."):
            if not isinstance(cur, dict) or part not in cur:
                return default
            cur = cur[part]
        return cur

    def set(self, dotted: str, value) -> None:
        parts = dotted.split(".")
        cur = self.data
        for part in parts[:-1]:
            cur = cur.setdefault(part, {})
        cur[parts[-1]] = value

    def _apply_env(self) -> None:
        mapping = {
            "DEEPSEEK_API_KEY": "llm.providers.deepseek.api_key",
            "HIVEWING_TOKEN": "server.auth_token",
            "OLLAMA_BASE_URL": "llm.providers.ollama.base_url",
            "HIVEWING_PORT": "server.port",
        }
        for env, key in mapping.items():
            val = os.environ.get(env)
            if val:
                if key == "server.port":
                    val = int(val)
                self.set(key, val)
        if os.environ.get("HIVEWING_OFFLINE") == "1":
            self.set("llm.default_provider", "mock")

    # ---------- 持久化 ----------
    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        text = yaml.safe_dump(self.data, allow_unicode=True, sort_keys=False, width=100)
        self.path.write_text(text, "utf-8")

    def ensure_file(self) -> None:
        if not self.path.exists():
            self.save()

    # ---------- 便捷 ----------
    @property
    def db_path(self) -> Path:
        p = Path(self.get("db", "data/hivewing.db"))
        return p if p.is_absolute() else ROOT / p

    @property
    def token(self) -> str:
        return str(self.get("server.auth_token") or "")

    def provider_cfg(self, name: str) -> dict:
        return self.get(f"llm.providers.{name}", {}) or {}
