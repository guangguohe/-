"""上下文组装：把联系人、消息、事实、风格样本压成一次提示词要用的 brief。"""
from __future__ import annotations

from dataclasses import dataclass, field

from .config import Config
from .db import Store
from .models import Contact, Message
from .polish import compare_samples
from .skills.loader import bigrams
from .util import iso, short

TONE_LABELS = {
    "warmth": ("偏冷", "温和", "热络"),
    "directness": ("绕着说", "正常", "直给"),
    "humor": ("正经", "偶尔皮", "很皮"),
    "brevity": ("可以长", "中等", "越短越好"),
}


@dataclass
class ChatContext:
    contact: Contact
    messages: list[Message]
    incoming: str
    stage: str = "熟悉"
    facts: list[dict] = field(default_factory=list)
    style_samples: list[str] = field(default_factory=list)
    style_stats: dict = field(default_factory=dict)
    persona: str = ""
    goal: str = ""
    trigger: str = "auto"
    now_label: str = ""

    @property
    def last_incoming(self) -> str:
        for m in reversed(self.messages):
            if m.direction == "in":
                return m.text
        return self.incoming

    def dialogue(self, max_turns: int = 14) -> list[dict]:
        msgs = self.messages[-max_turns:]
        out = []
        for m in msgs:
            out.append({
                "who": "她" if m.direction == "in" else "我",
                "text": short(m.text, 300),
                "t": iso(m.ts),
            })
        return out

    def brief(self) -> dict:
        return {
            "contact": self.contact.display,
            "stage": self.stage,
            "goal": self.goal,
            "incoming": self.incoming,
            "recent": self.dialogue(),
            "facts": [{"key": f["key"], "value": f["value"]} for f in self.facts[:12]],
            "persona": self.persona,
            "style_samples": self.style_samples[:6],
            "style_stats": self.style_stats,
            "trigger": self.trigger,
        }

    def retrieval_query(self) -> str:
        recent = " ".join(m.text for m in self.messages[-6:])
        return f"{self.incoming} {recent} {self.stage} {self.goal}"


def build_persona(cfg: Config, contact: Contact, stats: dict) -> str:
    p = cfg.get("persona", {}) or {}
    tone = p.get("tone", {}) or {}
    bits = []
    if p.get("nickname"):
        bits.append(f"昵称：{p['nickname']}")
    if p.get("age"):
        bits.append(f"年龄：{p['age']}")
    if p.get("city"):
        bits.append(f"城市：{p['city']}")
    if p.get("job"):
        bits.append(f"职业：{p['job']}")
    if p.get("self_description"):
        bits.append(f"自我描述：{p['self_description']}")
    if p.get("signature"):
        bits.append(f"口头禅：{p['signature']}（偶尔用，别每句都带）")
    if p.get("taboos"):
        bits.append("禁忌话题：" + "、".join(str(t) for t in p["taboos"]))
    label = []
    for key, words in TONE_LABELS.items():
        v = float(tone.get(key, 0.5))
        idx = 0 if v < 0.34 else 1 if v < 0.67 else 2
        label.append(f"{words[idx]}")
    bits.append(
        f"语气档位：温度={label[0]}，直接度={label[1]}，幽默={label[2]}，长度={label[3]}"
    )
    if stats:
        bits.append(
            f"他平时打字：平均 {stats.get('avg_len')} 字，"
            f"{int(stats.get('short_ratio', 0) * 100)}% 是短句，"
            f"每条 {stats.get('question_rate')} 个问号，"
            f"emoji {stats.get('emoji_rate')} 个/条"
        )
    bits.append(f"当前关系阶段：{contact.stage}")
    return "；".join(bits)


def pick_style_samples(store: Store, query: str, k: int = 6) -> list[str]:
    samples = store.style_samples(400)
    if not samples:
        return []
    q = bigrams(query)
    if not q:
        return samples[:k]
    ranked = sorted(
        samples,
        key=lambda s: len(q & bigrams(s)) / (len(bigrams(s)) ** 0.5 + 1),
        reverse=True,
    )
    picked = []
    for s in ranked:
        if s not in picked:
            picked.append(s)
        if len(picked) >= k:
            break
    return picked


def build_context(
    cfg: Config,
    store: Store,
    contact: Contact,
    incoming: str = "",
    trigger: str = "auto",
    limit: int = 16,
) -> ChatContext:
    messages = store.list_messages(contact.id, limit=limit)
    if not incoming:
        last_in = next((m for m in reversed(messages) if m.direction == "in"), None)
        incoming = last_in.text if last_in else (messages[-1].text if messages else "")
    facts = store.list_facts(contact.id)
    query = f"{incoming} {contact.notes}"
    samples = pick_style_samples(store, query)
    stats = compare_samples(store.style_samples(60))
    stage = cfg.get("goal.stage", "auto")
    if stage in ("", "auto", None):
        stage = contact.stage
    return ChatContext(
        contact=contact,
        messages=messages,
        incoming=incoming,
        stage=stage,
        facts=facts,
        style_samples=samples,
        style_stats=stats,
        persona=build_persona(cfg, contact, stats),
        goal=str(cfg.get("goal.intent", "")),
        trigger=trigger,
        now_label=iso(),
    )
