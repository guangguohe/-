"""反模式检测：舔狗、鸡汤、说教、炫富、卖惨、道德绑架、油腻、查户口、考验人性。

灵感直接来自 tong-jincheng-skill 的「绝对反对（反模式）」清单：
- 当舔狗（贬低自己去迎合）
- 心灵鸡汤（说让人舒坦但没用的话）
- 突袭检验（测试人性）
- 炫耀（越缺什么越想炫耀什么）
"""
from __future__ import annotations

import re

PATTERNS: list[dict] = [
    {
        "code": "simp",
        "label": "舔狗式",
        "severity": "high",
        "blocking": True,
        "pattern": r"(你开心就好|我都听你的|你说什么都行|只要你高兴|我配不上|我很卑微|求你了|不想失去你|你随便|我都可以的)",
        "hint": "把自己的位置放太低，短期讨好、长期掉价。换成「我有我的安排，也愿意为你调」。",
    },
    {
        "code": "simp_multi",
        "label": "连发轰炸",
        "severity": "high",
        "blocking": True,
        "pattern": r"(\n.*[？?].*\n.*[？?])",
        "hint": "一条消息里塞多个问题，像推销。一次只问一个。",
    },
    {
        "code": "chicken_soup",
        "label": "鸡汤",
        "severity": "mid",
        "blocking": False,
        "pattern": r"(你要相信|未来可期|一切都会好的|你值得被爱|慢慢来会好的|时间会给你答案|做最好的自己)",
        "hint": "正确但没用。她自己知道，她要的是你具体的一句话。",
    },
    {
        "code": "lecture",
        "label": "说教",
        "severity": "mid",
        "blocking": True,
        "pattern": r"(你应该|你要学会|听我的|我跟你说|说白了就是|你怎么就不明白|成熟一点)",
        "hint": "她在找对象，不是找班主任。",
    },
    {
        "code": "show_off",
        "label": "炫耀",
        "severity": "mid",
        "blocking": False,
        "pattern": r"(我朋友(都|开|做)|我认识(一个|几个)|我那辆|我年薪|我项目|我资源|我随便就)",
        "hint": "越缺什么越想炫耀什么。价值让她自己发现。",
    },
    {
        "code": "sob_story",
        "label": "卖惨",
        "severity": "high",
        "blocking": True,
        "pattern": r"(我这么惨|没人懂我|我都这样了|我活着还有什么意思|你要是不理我我就)",
        "hint": "用愧疚感换回应，是最贵的一种要。",
    },
    {
        "code": "guilt_trip",
        "label": "道德绑架",
        "severity": "high",
        "blocking": True,
        "pattern": r"(我都为你|你连这个都不|你是不是不把我|你这样做对得起|我为你付出)",
        "hint": "把喜欢变成债务，关系就变味了。",
    },
    {
        "code": "creepy",
        "label": "油腻称呼",
        "severity": "mid",
        "blocking": True,
        "pattern": r"(宝贝|亲爱的|老婆|小可爱|乖乖|小宝贝)",
        "hint": "关系没到就别叫，容易劝退。",
    },
    {
        "code": "interrogate",
        "label": "查户口",
        "severity": "mid",
        "blocking": False,
        "pattern": r"(你多大|你做什么工作|你住哪|你家里|你工资|你谈过几个|你以前)",
        "hint": "信息交换要自然，别像填表。先给一点自己的。",
    },
    {
        "code": "test_nature",
        "label": "考验人性",
        "severity": "high",
        "blocking": True,
        "pattern": r"(我故意不回|看她会不会|试探一下|假装生气|消失两天|冷战)",
        "hint": "人性经不起考验，你设的局最后困住的是你自己。",
    },
    {
        "code": "sexual",
        "label": "越界",
        "severity": "high",
        "blocking": True,
        "pattern": r"(开房|酒店|睡你|身体|胸|腿|约炮|发生关系)",
        "hint": "关系没到这个阶段，越界即出局。",
    },
    {
        "code": "desperate",
        "label": "急着要结果",
        "severity": "mid",
        "blocking": False,
        "pattern": r"(你到底喜不喜欢我|我们算什么|给我个答案|你是不是不喜欢我|你为什么不回)",
        "hint": "不确定就是不确定。问出来只会更远。",
    },
]

SEVERITY_WEIGHT = {"high": 18, "mid": 9, "low": 4}


def scan(text: str) -> list[dict]:
    hits = []
    for p in PATTERNS:
        if re.search(p["pattern"], text or ""):
            hits.append({
                "code": p["code"],
                "label": p["label"],
                "severity": p["severity"],
                "blocking": p["blocking"],
                "hint": p["hint"],
                "weight": SEVERITY_WEIGHT[p["severity"]],
            })
    return hits


def has_blocking(text: str) -> bool:
    return any(h["blocking"] for h in scan(text))


def penalty(hits: list[dict]) -> int:
    return sum(h["weight"] for h in hits)
