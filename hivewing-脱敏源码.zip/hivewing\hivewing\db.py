"""SQLite 存储层：会话、消息、草稿、运行记录、事实库、风格样本、策略信息素。"""
from __future__ import annotations

import sqlite3
import threading
from pathlib import Path
from typing import Iterable

from .models import Contact, Draft, Message
from .util import dump_json, load_json, log, new_id, now

LOG = log("db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS contacts (
  id TEXT PRIMARY KEY, name TEXT, platform TEXT, platform_uid TEXT, stage TEXT,
  notes TEXT, tags TEXT, avatar TEXT, created_at REAL, updated_at REAL
);
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY, contact_id TEXT, direction TEXT, text TEXT, ts REAL,
  platform TEXT, sender TEXT, external_id TEXT, meta TEXT
);
CREATE INDEX IF NOT EXISTS idx_msg_contact ON messages(contact_id, ts);
CREATE TABLE IF NOT EXISTS drafts (
  id TEXT PRIMARY KEY, contact_id TEXT, run_id TEXT, variants TEXT, status TEXT,
  chosen INTEGER, final_text TEXT, created_at REAL
);
CREATE INDEX IF NOT EXISTS idx_draft_contact ON drafts(contact_id, created_at);
CREATE TABLE IF NOT EXISTS runs (
  id TEXT PRIMARY KEY, contact_id TEXT, trigger TEXT, formation TEXT, situation TEXT,
  strategy TEXT, usage TEXT, duration_ms INTEGER, error TEXT, created_at REAL
);
CREATE TABLE IF NOT EXISTS facts (
  id TEXT PRIMARY KEY, contact_id TEXT, key TEXT, value TEXT, confidence REAL,
  source TEXT, ts REAL
);
CREATE INDEX IF NOT EXISTS idx_fact_contact ON facts(contact_id);
CREATE TABLE IF NOT EXISTS style_samples (
  id TEXT PRIMARY KEY, text TEXT, ts REAL
);
CREATE TABLE IF NOT EXISTS tactics (
  name TEXT, intent TEXT, tries INTEGER DEFAULT 0, wins INTEGER DEFAULT 0,
  last_ts REAL, PRIMARY KEY(name, intent)
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS events (
  id TEXT PRIMARY KEY, kind TEXT, payload TEXT, ts REAL
);
"""


class Store:
    def __init__(self, path: Path | str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._lock:
            self._conn.executescript(SCHEMA)
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA synchronous=NORMAL")
            self._conn.commit()

    # ---------- 基础 ----------
    def _exec(self, sql: str, params: Iterable = ()):
        with self._lock:
            cur = self._conn.execute(sql, tuple(params))
            self._conn.commit()
            return cur

    def _query(self, sql: str, params: Iterable = ()) -> list[dict]:
        with self._lock:
            cur = self._conn.execute(sql, tuple(params))
            return [dict(r) for r in cur.fetchall()]

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    # ---------- 联系人 ----------
    def upsert_contact(self, contact: Contact) -> Contact:
        contact.updated_at = now()
        row = contact.to_row()
        with self._lock:
            self._conn.execute(
                """INSERT INTO contacts (id,name,platform,platform_uid,stage,notes,tags,avatar,created_at,updated_at)
                   VALUES (:id,:name,:platform,:platform_uid,:stage,:notes,:tags,:avatar,:created_at,:updated_at)
                   ON CONFLICT(id) DO UPDATE SET name=:name, platform=:platform, platform_uid=:platform_uid,
                     stage=:stage, notes=:notes, tags=:tags, avatar=:avatar, updated_at=:updated_at""",
                row,
            )
            self._conn.commit()
        return contact

    def ensure_contact(self, name: str, platform: str = "manual", platform_uid: str = "") -> Contact:
        existing = self.find_contact(platform, platform_uid) if platform_uid else None
        if existing:
            return existing
        c = Contact(id=new_id("c_"), name=name, platform=platform, platform_uid=platform_uid)
        return self.upsert_contact(c)

    def find_contact(self, platform: str, platform_uid: str) -> Contact | None:
        if not platform_uid:
            return None
        rows = self._query(
            "SELECT * FROM contacts WHERE platform=? AND platform_uid=? LIMIT 1",
            (platform, platform_uid),
        )
        return Contact.from_row(rows[0]) if rows else None

    def get_contact(self, cid: str) -> Contact | None:
        rows = self._query("SELECT * FROM contacts WHERE id=?", (cid,))
        return Contact.from_row(rows[0]) if rows else None

    def list_contacts(self) -> list[Contact]:
        rows = self._query(
            """SELECT c.*, (SELECT MAX(ts) FROM messages m WHERE m.contact_id=c.id) AS last_ts
               FROM contacts c ORDER BY COALESCE(last_ts, c.updated_at) DESC"""
        )
        out = []
        for r in rows:
            c = Contact.from_row(r)
            c.last_ts = r.get("last_ts") or c.updated_at  # type: ignore[attr-defined]
            out.append(c)
        return out

    def update_contact_stage(self, cid: str, stage: str) -> None:
        self._exec("UPDATE contacts SET stage=?, updated_at=? WHERE id=?", (stage, now(), cid))

    def delete_contact(self, cid: str) -> None:
        with self._lock:
            for table in ("messages", "drafts", "runs", "facts"):
                self._conn.execute(f"DELETE FROM {table} WHERE contact_id=?", (cid,))
            self._conn.execute("DELETE FROM contacts WHERE id=?", (cid,))
            self._conn.commit()

    # ---------- 消息 ----------
    def add_message(self, msg: Message) -> Message:
        self._exec(
            """INSERT OR IGNORE INTO messages (id,contact_id,direction,text,ts,platform,sender,external_id,meta)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (msg.id, msg.contact_id, msg.direction, msg.text, msg.ts, msg.platform,
             msg.sender, msg.external_id, dump_json(msg.meta)),
        )
        if msg.direction == "out" and msg.sender == "me" and len(msg.text.strip()) >= 2:
            self.add_style_sample(msg.text)
        return msg

    def has_external(self, external_id: str) -> bool:
        if not external_id:
            return False
        return bool(self._query("SELECT 1 FROM messages WHERE external_id=? LIMIT 1", (external_id,)))

    def list_messages(self, cid: str, limit: int = 60, before: float | None = None) -> list[Message]:
        if before:
            rows = self._query(
                "SELECT * FROM messages WHERE contact_id=? AND ts<? ORDER BY ts DESC LIMIT ?",
                (cid, before, limit),
            )
        else:
            rows = self._query(
                "SELECT * FROM messages WHERE contact_id=? ORDER BY ts DESC LIMIT ?", (cid, limit)
            )
        return [Message.from_row(r) for r in reversed(rows)]

    def last_message(self, cid: str) -> Message | None:
        rows = self._query("SELECT * FROM messages WHERE contact_id=? ORDER BY ts DESC LIMIT 1", (cid,))
        return Message.from_row(rows[0]) if rows else None

    def unread_count(self, cid: str) -> int:
        rows = self._query("SELECT COUNT(*) n FROM messages WHERE contact_id=? AND direction='in'", (cid,))
        return int(rows[0]["n"]) if rows else 0

    # ---------- 草稿 ----------
    def save_draft(self, draft: Draft) -> Draft:
        row = draft.to_row()
        self._exec(
            """INSERT OR REPLACE INTO drafts (id,contact_id,run_id,variants,status,chosen,final_text,created_at)
               VALUES (?,?,?,?,?,?,?,?)""",
            (row["id"], row["contact_id"], row["run_id"], row["variants"], row["status"],
             row["chosen"], row["final_text"], row["created_at"]),
        )
        return draft

    def get_draft(self, did: str) -> Draft | None:
        rows = self._query("SELECT * FROM drafts WHERE id=?", (did,))
        return Draft.from_row(rows[0]) if rows else None

    def list_drafts(self, cid: str | None = None, limit: int = 30) -> list[Draft]:
        if cid:
            rows = self._query(
                "SELECT * FROM drafts WHERE contact_id=? ORDER BY created_at DESC LIMIT ?", (cid, limit)
            )
        else:
            rows = self._query("SELECT * FROM drafts ORDER BY created_at DESC LIMIT ?", (limit,))
        return [Draft.from_row(r) for r in rows]

    def update_draft(self, did: str, **fields) -> None:
        if not fields:
            return
        cols = ", ".join(f"{k}=?" for k in fields)
        self._exec(f"UPDATE drafts SET {cols} WHERE id=?", (*fields.values(), did))

    # ---------- 运行记录 ----------
    def save_run(self, run: dict) -> None:
        self._exec(
            """INSERT OR REPLACE INTO runs (id,contact_id,trigger,formation,situation,strategy,usage,duration_ms,error,created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?)""",
            (run["id"], run.get("contact_id"), run.get("trigger", ""), run.get("formation", ""),
             dump_json(run.get("situation")), dump_json(run.get("strategy")),
             dump_json(run.get("usage")), run.get("duration_ms", 0), run.get("error", ""), now()),
        )

    def get_run(self, rid: str) -> dict | None:
        rows = self._query("SELECT * FROM runs WHERE id=?", (rid,))
        if not rows:
            return None
        r = rows[0]
        for k in ("situation", "strategy", "usage"):
            r[k] = load_json(r.get(k), {})
        return r

    def recent_runs(self, cid: str, limit: int = 5) -> list[dict]:
        rows = self._query(
            "SELECT * FROM runs WHERE contact_id=? ORDER BY created_at DESC LIMIT ?", (cid, limit)
        )
        for r in rows:
            for k in ("situation", "strategy", "usage"):
                r[k] = load_json(r.get(k), {})
        return rows

    # ---------- 事实库 ----------
    def add_fact(self, cid: str, key: str, value: str, confidence: float = 0.7, source: str = "") -> None:
        existing = self._query(
            "SELECT id, confidence FROM facts WHERE contact_id=? AND key=? AND value=?",
            (cid, key, value),
        )
        if existing:
            self._exec(
                "UPDATE facts SET confidence=?, ts=? WHERE id=?",
                (max(confidence, existing[0]["confidence"]), now(), existing[0]["id"]),
            )
            return
        self._exec(
            "INSERT INTO facts (id,contact_id,key,value,confidence,source,ts) VALUES (?,?,?,?,?,?,?)",
            (new_id("f_"), cid, key, value, confidence, source, now()),
        )

    def list_facts(self, cid: str, limit: int = 30) -> list[dict]:
        return self._query(
            "SELECT * FROM facts WHERE contact_id=? ORDER BY confidence DESC, ts DESC LIMIT ?",
            (cid, limit),
        )

    # ---------- 风格样本 ----------
    def add_style_sample(self, text: str) -> None:
        text = (text or "").strip()
        if not (2 <= len(text) <= 200):
            return
        if self._query("SELECT 1 FROM style_samples WHERE text=? LIMIT 1", (text,)):
            return
        self._exec("INSERT INTO style_samples (id,text,ts) VALUES (?,?,?)", (new_id("s_"), text, now()))

    def style_samples(self, limit: int = 200) -> list[str]:
        rows = self._query("SELECT text FROM style_samples ORDER BY ts DESC LIMIT ?", (limit,))
        return [r["text"] for r in rows]

    # ---------- 策略信息素（stigmergy） ----------
    def bump_tactic(self, name: str, intent: str, win: bool) -> None:
        with self._lock:
            self._conn.execute(
                """INSERT INTO tactics (name,intent,tries,wins,last_ts) VALUES (?,?,1,?,?)
                   ON CONFLICT(name,intent) DO UPDATE SET tries=tries+1,
                     wins=wins+excluded.wins, last_ts=excluded.last_ts""",
                (name, intent, 1 if win else 0, now()),
            )
            self._conn.commit()

    def tactic_scores(self, intent: str) -> dict[str, float]:
        rows = self._query("SELECT name,tries,wins FROM tactics WHERE intent=?", (intent,))
        return {r["name"]: (r["wins"] + 1) / (r["tries"] + 2) for r in rows}

    # ---------- 设置 / 事件 ----------
    def get_setting(self, key: str, default=None):
        rows = self._query("SELECT value FROM settings WHERE key=?", (key,))
        return load_json(rows[0]["value"], default) if rows else default

    def set_setting(self, key: str, value) -> None:
        self._exec(
            "INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, dump_json(value)),
        )

    def log_event(self, kind: str, payload: dict) -> None:
        self._exec(
            "INSERT INTO events (id,kind,payload,ts) VALUES (?,?,?,?)",
            (new_id("e_"), kind, dump_json(payload), now()),
        )

    def stats(self) -> dict:
        def count(sql: str) -> int:
            rows = self._query(sql)
            return int(rows[0]["n"]) if rows else 0

        return {
            "contacts": count("SELECT COUNT(*) n FROM contacts"),
            "messages": count("SELECT COUNT(*) n FROM messages"),
            "drafts": count("SELECT COUNT(*) n FROM drafts"),
            "runs": count("SELECT COUNT(*) n FROM runs"),
            "style_samples": count("SELECT COUNT(*) n FROM style_samples"),
        }

    # ---------- 隐私 / 清理 ----------
    def events(self, limit: int = 60) -> list[dict]:
        rows = self._query("SELECT * FROM events ORDER BY ts DESC LIMIT ?", (limit,))
        for r in rows:
            r["payload"] = load_json(r.get("payload"), {})
        return rows

    def purge(self, what: str = "all") -> dict:
        """清数据。what=all 连会话一起清；messages 只清聊天与草稿。"""
        tables = ["messages", "drafts", "runs", "facts", "tactics"]
        if what == "all":
            tables += ["contacts", "style_samples"]
        done = {}
        for t in tables:
            before = self._query(f"SELECT COUNT(*) n FROM {t}")[0]["n"]
            self._exec(f"DELETE FROM {t}")
            done[t] = int(before)
        if what == "all":
            self._exec("DELETE FROM events")
        return done

    def purge_older_than(self, days: int) -> int:
        if days <= 0:
            return 0
        cutoff = now() - days * 86400
        before = self._query("SELECT COUNT(*) n FROM messages WHERE ts < ?", (cutoff,))[0]["n"]
        self._exec("DELETE FROM messages WHERE ts < ?", (cutoff,))
        self._exec("DELETE FROM drafts WHERE created_at < ?", (cutoff,))
        self._exec("DELETE FROM runs WHERE created_at < ?", (cutoff,))
        return int(before)

    def db_bytes(self) -> int:
        try:
            return Path(self.path).stat().st_size
        except OSError:
            return 0

