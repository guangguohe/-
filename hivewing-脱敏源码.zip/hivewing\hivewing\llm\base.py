"""LLM 抽象层。"""
from __future__ import annotations

from dataclasses import dataclass, field

Message = dict[str, str]  # {"role": "system|user|assistant", "content": "..."}


@dataclass
class LLMReply:
    text: str
    model: str = ""
    tier: str = ""
    provider: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    ms: int = 0
    fallback: bool = False
    raw: dict = field(default_factory=dict)

    @property
    def tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens


class LLMError(RuntimeError):
    """模型调用失败（key 缺失、超时、HTTP 错误、返回为空）。"""


class Provider:
    name = "base"

    async def chat(
        self,
        messages: list[Message],
        *,
        model: str,
        temperature: float = 0.8,
        json_mode: bool = False,
        max_tokens: int = 900,
        timeout: float | None = None,
        role: str = "",
    ) -> LLMReply:
        raise NotImplementedError

    async def health(self) -> dict:
        return {"ok": False, "detail": "not implemented"}

    async def close(self) -> None:
        return None


def system(text: str) -> Message:
    return {"role": "system", "content": text}


def user(text: str) -> Message:
    return {"role": "user", "content": text}
