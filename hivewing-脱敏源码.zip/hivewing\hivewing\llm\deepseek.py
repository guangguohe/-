"""DeepSeek 云端模型（OpenAI 兼容协议）。"""
from __future__ import annotations

import time

import httpx

from .base import LLMError, LLMReply, Message, Provider


class DeepSeekProvider(Provider):
    name = "deepseek"

    def __init__(self, cfg: dict):
        self.cfg = cfg or {}
        self.api_key = (self.cfg.get("api_key") or "").strip()
        self.base_url = (self.cfg.get("base_url") or "https://api.deepseek.com").rstrip("/")
        self.timeout = float(self.cfg.get("timeout", 90))
        self._client: httpx.AsyncClient | None = None

    def _http(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout, connect=15.0),
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
            )
        return self._client

    def available(self) -> bool:
        return bool(self.api_key)

    async def chat(
        self,
        messages: list[Message],
        *,
        model: str,
        temperature: float = 0.8,
        json_mode: bool = False,
        max_tokens: int = 900,
        timeout: float | None = None,
        role: str = "",
    ) -> LLMReply:
        if not self.api_key:
            raise LLMError("DEEPSEEK_API_KEY 未配置")
        body = {
            "model": model or "deepseek-chat",
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": False,
        }
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        t0 = time.time()
        try:
            r = await self._http().post(
                f"{self.base_url}/chat/completions", json=body, timeout=timeout or self.timeout
            )
        except httpx.TimeoutException as exc:
            raise LLMError(f"DeepSeek 超时（{timeout or self.timeout}s）") from exc
        except httpx.HTTPError as exc:
            raise LLMError(f"DeepSeek 网络错误：{exc}") from exc
        if r.status_code >= 400:
            detail = r.text[:300]
            raise LLMError(f"DeepSeek HTTP {r.status_code}: {detail}")
        try:
            data = r.json()
            text = data["choices"][0]["message"]["content"] or ""
        except (KeyError, IndexError, ValueError) as exc:
            raise LLMError(f"DeepSeek 返回结构异常：{r.text[:200]}") from exc
        usage = data.get("usage") or {}
        return LLMReply(
            text=text.strip(),
            model=body["model"],
            provider=self.name,
            prompt_tokens=int(usage.get("prompt_tokens") or 0),
            completion_tokens=int(usage.get("completion_tokens") or 0),
            ms=int((time.time() - t0) * 1000),
            raw=data,
        )

    async def health(self) -> dict:
        if not self.api_key:
            return {"ok": False, "detail": "未配置 api_key（环境变量 DEEPSEEK_API_KEY）"}
        try:
            r = await self._http().get(f"{self.base_url}/models", timeout=8)
            return {"ok": r.status_code < 400, "detail": f"HTTP {r.status_code}"}
        except httpx.HTTPError as exc:
            return {"ok": False, "detail": str(exc)[:120]}

    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
