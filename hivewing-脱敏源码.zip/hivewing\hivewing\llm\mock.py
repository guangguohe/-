"""离线 Mock 模型：没有 API key、没有 Ollama 时也能完整跑通蜂群。

它是一套规则引擎：识别意图 -> 抽事实 -> 选打法 -> 套口语模板 -> 打分。
用途：开箱演示、单元测试、云端失败时的兜底。
"""
from __future__ import annotations

import hashlib
import re
import time

from ..util import extract_json
from .base import LLMReply, Message, Provider

EMOJI = "🙂😅😂🤣🥲😊😌🙃😏🤔"

INTENT_RULES: list[tuple[str, list[str]]] = [
    ("暧昧", ["想你", "抱抱", "亲", "晚安", "睡了吗", "喜欢你", "心动", "宝宝", "宝贝"]),
    ("试探", ["你喜欢什么", "你是不是", "什么关系", "怎么看", "为什么", "是不是喜欢", "对我"]),
    ("邀约信号", ["有空", "周末", "一起", "出来", "去哪", "约", "无聊", "好闲", "见面"]),
    ("情绪低落", ["累", "烦", "不开心", "难受", "emo", "哭", "压力", "丧", "崩溃", "委屈", "懒得", "没劲"]),
    ("生气", ["无语", "随便", "呵呵", "行吧", "算了", "不想说", "烦人", "讨厌"]),
    ("拒绝", ["不用", "下次吧", "改天", "再说", "没时间", "在忙", "忙吗", "不方便"]),
    ("分享日常", ["今天", "刚刚", "刚才", "吃了", "看到", "买了", "在上班", "在下班", "同事", "朋友", "忙完", "终于"]),
    ("追问", ["？", "?", "什么意思", "然后呢", "真的假的", "怎么"]),
]

COLD_TOKENS = {"嗯", "哦", "哦哦", "好", "好吧", "行", "哈哈", "哈哈哈", "呵呵", "。。", "……", "在", "没事"}

TACTICS = {
    "冷场": [("换频道", "丢一个具体、有画面感的新话题，别追问", "low"),
             ("自嘲降温", "先自嘲一句，把尴尬变成玩笑", "low")],
    "试探": [("不正面回答", "把问题抛回去，保留神秘感", "low"),
             ("给台阶", "认真但不说满，让她有安全感", "mid")],
    "邀约信号": [("给台阶式邀约", "把邀约包装成顺路/顺便，降低她的拒绝成本", "low"),
                 ("模糊定框架", "先定时间不定位，测试她的意愿度", "mid")],
    "情绪低落": [("先接情绪", "先承认她的感受，不急着给建议", "low"),
                 ("具体关心", "给一个能做的小动作，而不是口头安慰", "low")],
    "生气": [("不辩解", "先接住情绪，不解释、不反击", "low"),
             ("给空间", "给她退路，别逼她当场表态", "mid")],
    "拒绝": [("体面撤退", "不纠缠，留一个下次的钩子", "low")],
    "分享日常": [("接细节", "抓住她话里的一个细节往下问", "low"),
                 ("轻轻推", "从日常切到一个更私人一点的话题", "mid")],
    "暧昧": [("接住不解释", "接住暧昧，别急着表白或跑题", "low"),
             ("具体化", "把暧昧落到一个具体场景/时间", "mid")],
    "追问": [("短答+反问", "回答一句，再把球踢回去", "low")],
    "闲聊": [("接梗", "顺着她的话开个玩笑", "low")],
}

TEMPLATES: dict[str, dict[str, list[str]]] = {
    "冷场": {
        "接梗": ["就一个嗯？我这边都快结冰了", "行，那我猜你在忙，猜对没", "你这个嗯，信息量为零啊"],
        "关心": ["是不是累了", "今天是不是不太顺", "感觉你没力气说话，先歇会儿"],
        "给台阶": ["不打扰你，忙完吱一声", "那我不吵你，晚点再说", "你先忙，我等你"],
        "推进": ["换一个，你今天有没有一件想骂人的事", "说个正事，周末你哪天有空"],
    },
    "试探": {
        "接梗": ["你这种问法很像在查岗", "怎么，开始面试我了", "这题超纲了，得加钱"],
        "关心": ["怎么突然问这个", "你是在担心什么吗", "先说说你怎么想的"],
        "给台阶": ["我要是说得太具体，你又要对号入座了", "我标准挺低的，看感觉"],
        "推进": ["先不答，你猜", "你猜对了我就告诉你"],
    },
    "邀约信号": {
        "接梗": ["无聊是吧，那我给你安排个不无聊的", "你这个无聊，是缺人还是缺事"],
        "关心": ["最近是不是太闲了，还是太累了", "一个人待着容易想多"],
        "给台阶": ["周六我打算去逛下{place}，你要是也没事，一起？", "我那天正好路过你那边，顺路喝杯东西？"],
        "推进": ["那周六下午留给我，地点我定，你人到就行", "别计划了，跟我走"],
    },
    "情绪低落": {
        "接梗": ["这谁啊，报名字，我去给他发个问号", "听着就想替你骂两句"],
        "关心": ["听起来今天挺糟的，先别分析对错，说说谁惹的", "先不急着解决，你想说就说", "这事儿换谁都得烦"],
        "给台阶": ["不想说就不说，我陪你待会儿", "那今天先不聊这个，吃点东西"],
        "推进": ["下楼走十分钟？我陪你走", "晚上给你打个电话，不用你说话"],
    },
    "生气": {
        "接梗": ["行，我闭嘴", "好好好，我错，我先不讲话"],
        "关心": ["是不是我哪句说错了", "你先别气，慢慢说"],
        "给台阶": ["那我不问了，你想说的时候再说", "今天先这样，你缓一缓"],
        "推进": ["等我十分钟，我给你打个电话", "这样，你先骂我两句，骂完再说"],
    },
    "拒绝": {
        "接梗": ["行吧，那我这算被发配了", "收到，撤退"],
        "关心": ["那你自己注意休息", "忙归忙，饭得吃"],
        "给台阶": ["行，那你先忙，改天我再问你", "不催你，等你有空"],
        "推进": ["那下周呢，我先占个位", "行，那我记着了，下次你别跑"],
    },
    "分享日常": {
        "接梗": ["这听着就像你干的", "你是不是又偷偷乐了", "可以啊，日子过得挺有戏"],
        "关心": ["然后呢，后来咋样", "这事儿你当时什么感觉", "听着还挺有意思的"],
        "给台阶": ["那下次带我一个", "这种局你叫我啊"],
        "推进": ["下次别自己去了，带上我", "你说的这个，我也想去看看"],
    },
    "暧昧": {
        "接梗": ["你这话我截图了，以后别不认", "行啊，那你别反悔", "这么会说，跟谁学的"],
        "关心": ["今天怎么突然这么甜", "你这话说得我有点当真了"],
        "给台阶": ["那就先这样，别急着定义", "慢慢来，我不催你"],
        "推进": ["那明天见？", "光说没用，明天当面说"],
    },
    "追问": {
        "接梗": ["你问题好多啊", "查户口呢"],
        "关心": ["怎么突然想知道这个", "你是不是有点在意"],
        "给台阶": ["这个说来话长，改天当面讲", "先欠着，见面说"],
        "推进": ["你先把你的答案给我", "一人一个，公平"],
    },
    "闲聊": {
        "接梗": ["哈哈哈，你这人真有意思", "行，被你逗到了", "这话我爱听"],
        "关心": ["你今天心情不错啊", "感觉你今天状态挺好"],
        "给台阶": ["那就不聊正事了，随便扯扯", "行，今天不聊严肃的"],
        "推进": ["那说点别的，你最近有什么想要的", "正好，我问你个事"],
    },
}

PLACES = ["那家新开的咖啡店", "江边", "书店", "夜市", "公园", "附近那家面馆"]

# 带上下文的模板：认出她具体说了什么，比通用模板像人得多
CONTEXT_TEMPLATES: list[tuple[str, dict[str, list[str]]]] = [
    (r"(忙完|终于|解放|收工)", {
        "接梗": ["终于解放了，那得庆祝一下", "忙完了？我还以为你要忙到过年"],
        "关心": ["终于熬完了，今晚早点睡", "这周辛苦，收尾了吗"],
        "给台阶": ["忙完就歇着，别再给自己找事"],
        "推进": ["那周末出来透透气？我带你去个地方"],
    }),
    (r"(猫|狗|仓鼠|兔子|宠物)", {
        "接梗": ["听着就像它才是这个家的主人", "你是不是已经被它拿捏了"],
        "关心": ["多大？粘人吗", "它平时跟你睡吗"],
        "给台阶": ["下次发张照片，我评评它长得像不像你"],
        "推进": ["改天带它出来，我给它带点吃的"],
    }),
    (r"(加班|熬夜|困|没睡)", {
        "接梗": ["你们公司是把你当永动机了", "这班加得，老板该给你发个奖"],
        "关心": ["几点能到家？路上慢点", "到家先吃点东西，别直接躺"],
        "给台阶": ["今天先不聊了，你赶紧睡"],
        "推进": ["明天别硬撑，中午我提醒你吃饭"],
    }),
    (r"(无聊|没事干|好闲|不知道干嘛)", {
        "接梗": ["无聊是吧，那我给你找点事", "闲成这样，正好被我逮到"],
        "关心": ["一个人待着容易想多，找点事做", "是不是最近太闲了"],
        "给台阶": ["你要真没事，周六跟我去个地方", "我这边有个事，你来帮我参谋一下"],
        "推进": ["那别计划了，周六下午跟我走"],
    }),
    (r"(生日)", {
        "接梗": ["生日？那我得提前准备一下", "这么巧，我正愁没理由请你吃饭"],
        "关心": ["今年想怎么过", "有没有特别想要的"],
        "给台阶": ["不用搞太大，吃个饭就行"],
        "推进": ["那天留给我，我来安排"],
    }),
    (r"(冷|降温|下雨|天气)", {
        "接梗": ["这天气翻脸比翻书快", "你这是不是又在硬扛"],
        "关心": ["出门加件外套", "别又穿那么少"],
        "给台阶": ["冷就待着，别出门了"],
        "推进": ["周末要是不下雨，带你去个地方"],
    }),
    (r"(算什么|什么关系|定义|我们之间|认真的)", {
        "接梗": ["你这是要给我个名分吗", "这题我得坐直了答"],
        "关心": ["怎么突然想这个，是我哪里让你没底了", "你是有点不安吗"],
        "给台阶": ["不用急着定义，处着舒服比什么都强", "先别贴标签，标签容易把人框住"],
        "推进": ["那我说了：我想认真跟你处，但我不催你", "我想要的挺简单，就是你下次还愿意跟我出来"],
    }),
    (r"(路过|那家店|排队|好吃)", {
        "接梗": ["进去看了没？别光路过", "路过不算，进去才算"],
        "关心": ["那家店排队吗", "你一个人去的？"],
        "给台阶": ["下次一起去，我请", "正好我也想去，一起"],
        "推进": ["那周末去一趟？我安排"],
    }),
    (r"(在干嘛|干嘛呢|忙吗|在忙|做什么呢)", {
        "接梗": ["在跟你聊天啊", "在想要不要回你，你就来了"],
        "关心": ["刚忙完，你呢", "在发呆，正好你来了"],
        "给台阶": ["没事干，你说", "闲着呢，怎么了"],
        "推进": ["在等你约我", "在挑周末去哪，你给个方向"],
    }),
    (r"(到家|到了|洗澡|睡了|躺下)", {
        "接梗": ["到家就好，我这边刚要报警", "行，安全抵达"],
        "关心": ["先洗个热水澡", "累就早点睡，别刷手机了"],
        "给台阶": ["那你歇着，不用回我"],
        "推进": ["明天叫你起床？"],
    }),
]


def _hash(text: str) -> int:
    return int(hashlib.md5(text.encode("utf-8")).hexdigest()[:8], 16)


def classify(text: str) -> str:
    t = (text or "").strip()
    if not t:
        return "冷场"
    if len(t) <= 4 and (t in COLD_TOKENS or re.fullmatch(r"[哈嗯哦好行啊？?。，、\s]+", t)):
        return "冷场"
    best, best_score = "闲聊", 0
    for intent, keys in INTENT_RULES:
        score = sum(1 for k in keys if k in t)
        if score > best_score:
            best, best_score = intent, score
    return best if best_score else "闲聊"


EMOTION_RULES = [
    ("低落", ["累", "烦", "难受", "不开心", "emo", "哭", "压力", "丧", "委屈"]),
    ("生气", ["无语", "呵呵", "随便", "行吧", "讨厌", "烦人"]),
    ("害羞", ["害羞", "不好意思", "哪有", "讨厌啦", "哼"]),
    ("开心", ["哈哈", "开心", "好耶", "笑死", "太棒", "喜欢"]),
    ("疏离", ["嗯", "哦", "随便", "再说吧", "忙"]),
]


def _emotion(text: str) -> str:
    for name, keys in EMOTION_RULES:
        if any(k in (text or "") for k in keys):
            return name
    return "平淡"


def _signal(intent: str, text: str) -> dict:
    mapping = {
        "冷场": ("她暂时没话，或不想接这个话题", 0.3, "别追问，换个轻的"),
        "试探": ("她在确认你的态度和边界", 0.5, "别急着表态，也别敷衍"),
        "邀约信号": ("她在释放「可以见面」的口子", 0.8, "给一个低成本的邀约"),
        "情绪低落": ("她需要被接住，不需要被教育", 0.6, "先共情，后建议"),
        "生气": ("她有情绪，正在等你反应", 0.7, "先接情绪，不辩解"),
        "拒绝": ("她在后撤，别硬推", 0.4, "体面撤退，留钩子"),
        "分享日常": ("她在主动给你话题入口", 0.55, "接细节，别只说好棒"),
        "暧昧": ("她在升温，等你接住", 0.6, "接住，别跑题"),
        "追问": ("她想更了解你，或在测试你", 0.5, "短答，留白"),
    }
    return mapping.get(intent, ("普通闲聊，保持节奏", 0.35, "自然就好"))


FACT_PATTERNS = [
    ("生日", r"生日[是为]?\s*(\d{1,2}\s*月\s*\d{1,2}[号日]?|\d{1,2}[./]\d{1,2})"),
    ("工作", r"(加班|上班|下班|公司在|做运营|做设计|做销售|老师|护士|会计)"),
    ("宠物", r"(猫|狗|仓鼠|兔子)"),
    ("饮食", r"(不吃辣|爱吃辣|减肥|奶茶|咖啡|火锅|烧烤)"),
    ("城市", r"(在北京|在上海|在杭州|在成都|在深圳|在南京|在武汉|在西安)"),
    ("爱好", r"(健身|跑步|瑜伽|看展|电影|追剧|剧本杀|露营|旅行|爬山|拍照)"),
    ("情绪词", r"(焦虑|失眠|想辞职|压力大|不开心)"),
]


class MockProvider(Provider):
    name = "mock"

    def __init__(self, cfg: dict | None = None):
        self.cfg = cfg or {}

    # ------------------------------------------------------------------
    async def chat(
        self,
        messages: list[Message],
        *,
        model: str = "mock-hive",
        temperature: float = 0.8,
        json_mode: bool = True,
        max_tokens: int = 900,
        timeout: float | None = None,
        role: str = "",
    ) -> LLMReply:
        t0 = time.time()
        brief: dict = {}
        for m in reversed(messages):
            if m.get("role") == "user":
                parsed = extract_json(m.get("content", ""))
                if isinstance(parsed, dict):
                    brief = parsed
                break
        role = role or brief.get("_role", "") or self._role_from_text(messages)
        text = self._dispatch(role, brief)
        return LLMReply(
            text=text,
            model=model or "mock-hive",
            provider=self.name,
            prompt_tokens=len(str(messages)) // 3,
            completion_tokens=len(text) // 2,
            ms=int((time.time() - t0) * 1000),
        )

    @staticmethod
    def _role_from_text(messages: list[Message]) -> str:
        joined = " ".join(m.get("content", "") for m in messages[:1])
        m = re.search(r"#\s*ROLE\s*[:：]\s*(\w+)", joined)
        return m.group(1) if m else "draft"

    def _dispatch(self, role: str, brief: dict) -> str:
        import json

        if role == "perceive":
            return json.dumps(self.perceive(brief), ensure_ascii=False)
        if role == "scout":
            return json.dumps(self.scout(brief), ensure_ascii=False)
        if role == "strategize":
            return json.dumps(self.strategize(brief), ensure_ascii=False)
        if role == "draft":
            return json.dumps(self.draft(brief), ensure_ascii=False)
        if role == "polish":
            return json.dumps({"text": self.polish(brief)}, ensure_ascii=False)
        if role == "critic":
            return json.dumps(self.critic(brief), ensure_ascii=False)
        if role == "extract":
            return json.dumps({"facts": self.facts(brief.get("text", ""))}, ensure_ascii=False)
        return json.dumps({"text": self.polish(brief)}, ensure_ascii=False)

    # ------------------------------------------------------------------
    def perceive(self, brief: dict) -> dict:
        incoming = brief.get("incoming", "") or ""
        recent = brief.get("recent") or []
        # 她这一句常常很短，要带上前面几条才看得出局势
        context_text = incoming + " " + incoming + " " + " ".join(
            m.get("text", "") for m in recent[-4:]
        )
        intent = classify(context_text)
        stripped = (incoming or "").strip()
        if (stripped in COLD_TOKENS or re.fullmatch(r"[。，、？！?！\s…]+", stripped or "x")) and not re.search(
            r"(累|烦|难受|生气|哭|喜欢|想你)", context_text
        ):
            # 极短且无情绪的回复按冷场处理；「在干嘛」这种短问句不算
            intent = "冷场"
        signal, urgency, hint = _signal(intent, incoming)
        stage = brief.get("stage") or "熟悉"
        return {
            "intent": intent,
            "emotion": _emotion(context_text),
            "signal": signal,
            "urgency": urgency,
            "risk": "她有情绪" if intent in ("生气", "情绪低落") else ("关系较浅" if stage in ("陌生", "破冰") else "无"),
            "stage": stage,
            "reply_needed": True,
            "hint": hint,
        }

    def facts(self, text: str) -> list[dict]:
        out, seen = [], set()
        for key, pattern in FACT_PATTERNS:
            for m in re.finditer(pattern, text or ""):
                value = m.group(1) if m.groups() else m.group(0)
                sig = (key, value)
                if sig in seen:
                    continue
                seen.add(sig)
                out.append({"key": key, "value": value, "confidence": 0.65})
        return out[:8]

    def scout(self, brief: dict) -> dict:
        incoming = brief.get("incoming", "") or ""
        recent = brief.get("recent") or []
        ctx = incoming + " " + " ".join(m.get("text", "") for m in recent[-8:])
        facts = self.facts(ctx)
        topics = [f["value"] for f in facts]
        hooks = []
        if "?" in incoming or "？" in incoming:
            hooks.append("她问了一个问题，可以先答再反问")
        if re.search(r"(周末|下班|有空|无聊)", incoming):
            hooks.append("她提了时间，说明有窗口")
        if re.search(r"(哈哈|笑死|😂|😅)", incoming):
            hooks.append("她在笑，气氛是松的")
        if not hooks:
            hooks.append("她愿意接话，节奏正常")
        avoid = []
        if re.search(r"(前男友|前任|分手)", ctx):
            avoid.append("别提前任")
        if re.search(r"(胖|丑|老|矮)", incoming):
            avoid.append("别接外貌评价")
        if _emotion(incoming) in ("低落", "生气"):
            avoid.append("别讲道理、别教育")
        return {
            "facts": facts,
            "topics": topics[:6],
            "hooks": hooks,
            "avoid": avoid or ["别连环提问", "别急着表白"],
            "subtext": _signal(classify(incoming), incoming)[0],
        }

    def strategize(self, brief: dict) -> dict:
        situation = brief.get("situation") or {}
        intent = situation.get("intent") or classify(brief.get("incoming", ""))
        pool = TACTICS.get(intent) or TACTICS["闲聊"]
        prior = brief.get("tactic_prior") or {}
        ranked = sorted(pool, key=lambda t: prior.get(t[0], 0.5), reverse=True)
        tactics = [{"name": n, "why": w, "risk": r} for n, w, r in ranked]
        goal = {
            "冷场": "把话头递回去，让她愿意接",
            "试探": "既让她安心，又不把底牌全亮",
            "邀约信号": "把「有空」变成一个具体的、低成本的见面",
            "情绪低落": "让她觉得被理解，而不是被安排",
            "生气": "先降温，别把小事吵大",
            "拒绝": "体面收住，保住下次的机会",
            "分享日常": "顺着细节聊深一点",
            "暧昧": "接住暧昧，往具体场景推一步",
        }.get(intent, "让对话自然继续，别用力过猛")
        return {
            "goal": goal,
            "tactics": tactics,
            "dont": (brief.get("scout") or {}).get("avoid") or ["别连发", "别解释太多"],
            "tone": "短句、口语、别端着；一次只推进半步",
        }

    def draft(self, brief: dict) -> dict:
        situation = brief.get("situation") or {}
        strategy = brief.get("strategy") or {}
        incoming = brief.get("incoming", "") or ""
        intent = situation.get("intent") or classify(incoming)
        angle = brief.get("angle", "接梗")
        pool = None
        for pattern, by_angle in CONTEXT_TEMPLATES:
            if re.search(pattern, incoming) and angle in by_angle:
                pool = by_angle
                break
        if pool is None:
            pool = TEMPLATES.get(intent) or TEMPLATES["闲聊"]
        options = pool.get(angle) or pool.get("接梗") or ["嗯，我在"]
        seed = _hash(incoming + angle + str(brief.get("variant", 0)))
        text = options[seed % len(options)]
        place = PLACES[seed % len(PLACES)]
        text = text.format(place=place)
        signature = (brief.get("signature") or "").strip()
        if signature and seed % 4 == 0:
            text = f"{text}{signature}"
        tactics = strategy.get("tactics") or []
        return {
            "text": text,
            "angle": angle,
            "tactic": tactics[0]["name"] if tactics else "接话",
            "why": f"她现在是「{intent}」，这个角度先{('接住情绪' if angle == '关心' else '把气氛放轻' if angle == '接梗' else '降低她的压力')}",
            "risk": "low" if angle != "推进" else "mid",
        }

    def polish(self, brief: dict) -> str:
        text = (brief.get("text") or "").strip()
        text = re.sub(r"[，,]\s*(?=[，,])", "", text)
        text = text.replace("！", "。").replace("!", "。")
        text = re.sub(r"[ \t]+", " ", text)
        return text

    def critic(self, brief: dict) -> dict:
        from ..polish import lint

        variants = brief.get("variants") or []
        incoming = brief.get("incoming") or ""
        incoming_chars = set(re.sub(r"\s", "", incoming))
        scores = []
        for v in variants:
            text = v.get("text", "")
            report = lint(text)
            seed = _hash(text)
            nat = max(40, min(99, report["score"] + (seed % 7) - 3))
            overlap = len(set(re.sub(r"\s", "", text)) & incoming_chars)
            fit = min(94, 70 + overlap * 2 + (seed % 5))
            push = {"推进": 82, "给台阶": 78, "关心": 74, "接梗": 72}.get(v.get("angle"), 70) + (seed % 4)
            risk = 14 + (seed % 9)
            if report["issues"]:
                risk += 10 + 6 * len(report["issues"])
            likes = 70 + (seed % 11)
            risk = min(88, risk)
            overall = round(nat * 0.34 + fit * 0.2 + push * 0.16 + (100 - risk) * 0.16 + likes * 0.14, 1)
            scores.append({
                "scores": {"自然度": nat, "贴合度": fit, "推进力": push, "风险": risk, "像本人": likes},
                "issues": report["issues"][:3],
                "verdict": "pass" if overall >= 68 and risk <= 55 else "revise",
                "suggestion": report["suggestions"][0] if report["suggestions"] else "",
                "overall": overall,
            })
        return {"variants": scores}

    async def health(self) -> dict:
        return {"ok": True, "detail": "离线规则引擎可用"}
