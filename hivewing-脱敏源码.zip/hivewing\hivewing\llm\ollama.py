"""Ollama 本地模型（/api/chat）。"""
from __future__ import annotations

import time

import httpx

from .base import LLMError, LLMReply, Message, Provider


class OllamaProvider(Provider):
    name = "ollama"

    def __init__(self, cfg: dict):
        self.cfg = cfg or {}
        self.base_url = (self.cfg.get("base_url") or "http://127.0.0.1:11434").rstrip("/")
        self.timeout = float(self.cfg.get("timeout", 180))
        self._client: httpx.AsyncClient | None = None

    def _http(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=httpx.Timeout(self.timeout, connect=5.0))
        return self._client

    async def chat(
        self,
        messages: list[Message],
        *,
        model: str,
        temperature: float = 0.8,
        json_mode: bool = False,
        max_tokens: int = 900,
        timeout: float | None = None,
        role: str = "",
    ) -> LLMReply:
        body = {
            "model": model or "qwen2.5:7b",
            "messages": messages,
            "stream": False,
            "options": {"temperature": temperature, "num_predict": max_tokens},
        }
        if json_mode:
            body["format"] = "json"
        t0 = time.time()
        try:
            r = await self._http().post(
                f"{self.base_url}/api/chat", json=body, timeout=timeout or self.timeout
            )
        except httpx.TimeoutException as exc:
            raise LLMError(f"Ollama 超时（{timeout or self.timeout}s），本地模型可能太慢或未加载") from exc
        except httpx.HTTPError as exc:
            raise LLMError(f"Ollama 连接失败（{self.base_url}）：{exc}") from exc
        if r.status_code >= 400:
            raise LLMError(f"Ollama HTTP {r.status_code}: {r.text[:300]}")
        try:
            data = r.json()
            text = (data.get("message") or {}).get("content", "") or ""
        except ValueError as exc:
            raise LLMError("Ollama 返回非 JSON") from exc
        return LLMReply(
            text=text.strip(),
            model=body["model"],
            provider=self.name,
            prompt_tokens=int(data.get("prompt_eval_count") or 0),
            completion_tokens=int(data.get("eval_count") or 0),
            ms=int((time.time() - t0) * 1000),
            raw=data,
        )

    async def health(self) -> dict:
        try:
            r = await self._http().get(f"{self.base_url}/api/tags", timeout=5)
            if r.status_code >= 400:
                return {"ok": False, "detail": f"HTTP {r.status_code}"}
            models = [m.get("name", "") for m in (r.json().get("models") or [])]
            return {"ok": True, "detail": f"{len(models)} 个模型", "models": models[:12]}
        except httpx.HTTPError as exc:
            return {"ok": False, "detail": f"连不上 {self.base_url}：{str(exc)[:80]}"}

    async def close(self) -> None:
        if self._client:
            await self._client.aclose()
