"""模型路由：按角色选档位（fast/smart/deep），失败自动降级。"""
from __future__ import annotations

import json
import time

from .. import privacy
from ..config import Config
from ..util import extract_json, log
from .base import LLMError, LLMReply, Message, Provider, system, user
from .deepseek import DeepSeekProvider
from .mock import MockProvider
from .ollama import OllamaProvider

LOG = log("llm")


class BudgetExceeded(RuntimeError):
    pass


class LLMParseError(LLMError):
    pass


class Budget:
    """一次蜂群运行的成本闸门。"""

    def __init__(self, max_calls: int = 18, max_seconds: float = 75.0):
        self.max_calls = max_calls
        self.max_seconds = max_seconds
        self.start = time.time()
        self.calls = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.by_model: dict[str, int] = {}

    def check(self) -> None:
        if self.calls >= self.max_calls:
            raise BudgetExceeded(f"本次最多 {self.max_calls} 次模型调用")
        if time.time() - self.start > self.max_seconds:
            raise BudgetExceeded(f"本次已超过 {int(self.max_seconds)} 秒")

    def spend(self, reply: LLMReply) -> None:
        self.calls += 1
        self.prompt_tokens += reply.prompt_tokens
        self.completion_tokens += reply.completion_tokens
        key = f"{reply.provider}:{reply.model}"
        self.by_model[key] = self.by_model.get(key, 0) + 1

    def can_afford(self, n: int = 1) -> bool:
        return self.calls + n <= self.max_calls and (time.time() - self.start) < self.max_seconds

    def snapshot(self) -> dict:
        return {
            "calls": self.calls,
            "max_calls": self.max_calls,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "by_model": dict(self.by_model),
            "seconds": round(time.time() - self.start, 1),
        }


class LLMRouter:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.providers: dict[str, Provider] = {
            "deepseek": DeepSeekProvider(cfg.provider_cfg("deepseek")),
            "ollama": OllamaProvider(cfg.provider_cfg("ollama")),
            "mock": MockProvider(cfg.provider_cfg("mock")),
        }
        self.calls: list[dict] = []
        self.on_call = None  # 审计回调：记录这次调用去了哪、有没有脱敏

    # ------------------------------------------------------------------
    def provider_name(self, role: str) -> str:
        name = str(self.cfg.get("llm.default_provider", "deepseek") or "deepseek")
        if name == "deepseek" and not self.providers["deepseek"].available():  # type: ignore[attr-defined]
            LOG.info("DeepSeek 未配置 key，改用 %s", self.cfg.get("llm.offline_fallback", "mock"))
            name = str(self.cfg.get("llm.offline_fallback", "mock"))
        # 没勾「允许发给云端」或者开了 local_only，就一步都不许出本机
        if not privacy.can_use_cloud(self.cfg, name):
            LOG.info("隐私设置禁止云端调用，降级为本地离线引擎")
            name = "mock"
        return name

    def model_for(self, provider: str, role: str) -> str:
        tier = str(self.cfg.get(f"llm.routing.{role}", "smart") or "smart")
        cfg = self.cfg.provider_cfg(provider)
        return str(cfg.get(f"model_{tier}") or cfg.get("model_smart") or "")

    def tier_for(self, role: str) -> str:
        return str(self.cfg.get(f"llm.routing.{role}", "smart") or "smart")

    # ------------------------------------------------------------------
    async def call(
        self,
        *,
        role: str,
        system_prompt: str,
        brief: dict,
        budget: Budget | None = None,
        json_mode: bool = True,
        temperature: float | None = None,
        timeout: float | None = None,
    ) -> tuple[dict | None, LLMReply]:
        if budget:
            budget.check()
        provider_name = self.provider_name(role)
        chain = [provider_name]
        fb = str(self.cfg.get("llm.offline_fallback", "mock") or "mock")
        if fb and fb != provider_name:
            chain.append(fb)

        last_error: Exception | None = None
        for idx, name in enumerate(chain):
            provider = self.providers.get(name)
            if provider is None:
                continue
            model = self.model_for(name, role) or "mock-hive"
            payload = json.dumps(brief, ensure_ascii=False)
            redacted = False
            if not privacy.is_local(name) and bool(self.cfg.get("privacy.redact_pii", True)):
                cleaned = privacy.redact(payload)
                redacted = cleaned != payload
                payload = cleaned
            msgs: list[Message] = [system(system_prompt), user(payload)]
            temp = self.cfg.get("llm.temperature", 0.8) if temperature is None else temperature
            try:
                reply = await provider.chat(
                    msgs,
                    model=model,
                    temperature=float(temp),
                    json_mode=json_mode,
                    role=role,
                    timeout=timeout,
                )
            except LLMError as exc:
                last_error = exc
                LOG.warning("[%s/%s] 调用失败：%s", name, role, exc)
                continue
            except Exception as exc:  # noqa: BLE001  任何意外都降级，不让整轮挂掉
                last_error = exc
                LOG.warning("[%s/%s] 未预期错误：%s", name, role, exc)
                continue

            reply.tier = self.tier_for(role)
            reply.fallback = idx > 0
            if budget:
                budget.spend(reply)
            self.calls.append({
                "role": role,
                "provider": reply.provider,
                "model": reply.model,
                "ms": reply.ms,
                "tokens": reply.tokens,
                "fallback": reply.fallback,
            })
            if self.on_call:
                try:
                    self.on_call({"role": role, "provider": reply.provider, "model": reply.model,
                                  "chars": len(payload), "redacted": redacted,
                                  "local": privacy.is_local(reply.provider)})
                except Exception:  # noqa: BLE001
                    pass
            data = extract_json(reply.text) if json_mode else None
            if json_mode and data is None:
                # 一次修复机会：让它只吐 JSON
                data = await self._repair(provider, msgs, reply, role, budget, model, temp, timeout)
            return (data if json_mode else None), reply

        raise LLMError(f"{role} 所有模型都调用失败：{last_error}")

    async def _repair(self, provider, msgs, first, role, budget, model, temp, timeout) -> dict | None:
        LOG.info("[%s/%s] 输出不是 JSON，尝试修复一次", provider.name, role)
        repair_msgs = msgs + [
            {"role": "assistant", "content": first.text[:1200]},
            {"role": "user", "content": "上面的输出不是合法 JSON。请只输出一个 JSON 对象，不要任何其他文字。"},
        ]
        try:
            reply = await provider.chat(
                repair_msgs, model=model, temperature=0.2, json_mode=True, role=role, timeout=timeout
            )
        except LLMError:
            return None
        if budget:
            budget.spend(reply)
        return extract_json(reply.text)

    # ------------------------------------------------------------------
    async def health(self) -> dict:
        out = {}
        for name, provider in self.providers.items():
            try:
                out[name] = await provider.health()
            except Exception as exc:  # noqa: BLE001
                out[name] = {"ok": False, "detail": str(exc)[:120]}
        out["active"] = self.provider_name("draft")
        return out

    async def close(self) -> None:
        for provider in self.providers.values():
            await provider.close()
