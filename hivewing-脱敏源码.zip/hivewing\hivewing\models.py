"""领域模型：联系人、消息、草稿、运行记录、轨迹。"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any

from .util import dump_json, load_json, new_id, now


STAGES = ["陌生", "破冰", "熟悉", "暧昧", "邀约", "确认"]
STAGE_ORDER = {s: i for i, s in enumerate(STAGES)}


def next_stage(stage: str) -> str:
    i = STAGE_ORDER.get(stage, 0)
    return STAGES[min(i + 1, len(STAGES) - 1)]


@dataclass
class Contact:
    id: str
    name: str
    platform: str = "manual"
    platform_uid: str = ""
    stage: str = "陌生"
    notes: str = ""
    tags: list[str] = field(default_factory=list)
    avatar: str = ""
    created_at: float = field(default_factory=now)
    updated_at: float = field(default_factory=now)

    @property
    def display(self) -> str:
        return self.name or self.platform_uid or "未命名"

    def to_row(self) -> dict:
        d = asdict(self)
        d["tags"] = dump_json(self.tags)
        return d

    @classmethod
    def from_row(cls, row: dict) -> "Contact":
        d = dict(row)
        d["tags"] = load_json(d.get("tags"), []) or []
        return cls(**{k: d.get(k) for k in cls.__dataclass_fields__})


@dataclass
class Message:
    id: str
    contact_id: str
    direction: str          # in | out
    text: str
    ts: float = field(default_factory=now)
    platform: str = "manual"
    sender: str = ""        # her | me | system
    external_id: str = ""
    meta: dict = field(default_factory=dict)

    def to_row(self) -> dict:
        d = asdict(self)
        d["meta"] = dump_json(self.meta)
        return d

    @classmethod
    def from_row(cls, row: dict) -> "Message":
        d = dict(row)
        d["meta"] = load_json(d.get("meta"), {}) or {}
        return cls(**{k: d.get(k) for k in cls.__dataclass_fields__})


@dataclass
class DraftVariant:
    text: str
    angle: str = ""            # 角度：接梗/关心/给台阶/推进
    tactic: str = ""           # 采用的策略名
    score: float = 0.0
    scores: dict = field(default_factory=dict)
    issues: list[str] = field(default_factory=list)
    why: str = ""              # 为什么这么回
    risk: str = ""             # 风险提示
    next_step: str = ""        # 下一步建议
    blocked: bool = False      # 触发反模式，禁止直接发送


@dataclass
class Draft:
    id: str
    contact_id: str
    run_id: str
    variants: list[DraftVariant] = field(default_factory=list)
    status: str = "pending"    # pending | approved | sent | rejected
    chosen: int = -1
    final_text: str = ""
    created_at: float = field(default_factory=now)

    def to_row(self) -> dict:
        d = asdict(self)
        d["variants"] = dump_json([asdict(v) if not isinstance(v, dict) else v for v in self.variants])
        return d

    @classmethod
    def from_row(cls, row: dict) -> "Draft":
        d = dict(row)
        variants = load_json(d.get("variants"), []) or []
        fields = set(DraftVariant.__dataclass_fields__)
        out = []
        for v in variants:
            if isinstance(v, dict):
                out.append(DraftVariant(**{k: val for k, val in v.items() if k in fields}))
            elif isinstance(v, DraftVariant):
                out.append(v)
        d["variants"] = out
        return cls(**{k: d.get(k) for k in cls.__dataclass_fields__})

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "contact_id": self.contact_id,
            "run_id": self.run_id,
            "status": self.status,
            "chosen": self.chosen,
            "final_text": self.final_text,
            "created_at": self.created_at,
            "variants": [asdict(v) for v in self.variants],
        }


@dataclass
class TraceEvent:
    run_id: str
    node: str
    phase: str           # start | done | fail | skip
    level: int = 0
    tier: str = ""
    model: str = ""
    ms: int = 0
    summary: str = ""
    detail: dict = field(default_factory=dict)
    ts: float = field(default_factory=now)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class RunResult:
    run_id: str
    contact_id: str
    formation: str = "standard"
    trigger: str = ""
    situation: dict = field(default_factory=dict)
    strategy: dict = field(default_factory=dict)
    drafts: Draft | None = None
    trace: list[dict] = field(default_factory=list)
    usage: dict = field(default_factory=dict)
    duration_ms: int = 0
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "run_id": self.run_id,
            "contact_id": self.contact_id,
            "formation": self.formation,
            "trigger": self.trigger,
            "situation": self.situation,
            "strategy": self.strategy,
            "draft": self.drafts.to_dict() if self.drafts else None,
            "trace": self.trace,
            "usage": self.usage,
            "duration_ms": self.duration_ms,
            "error": self.error,
        }
