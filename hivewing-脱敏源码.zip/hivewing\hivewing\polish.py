"""口语化 / 去 AI 味引擎。

两条路径：
1. tidy()  确定性改写：把书面词、AI 套话、客服腔换成口语（安全替换，不改语义）。
2. lint()  打分与诊断：给「自然度」0-100 分，列出 AI 痕迹，供质检蜂使用。

设计原则：宁可少改，不可改错。所有替换都是等义的。
"""
from __future__ import annotations

import re

# --- 硬套话（直接删/替换） -------------------------------------------------
HARD_PHRASES = [
    (r"希望(对你|能)有(所)?帮助[。！!]?", ""),
    (r"希望对你有帮助[。！!]?", ""),
    (r"作为(一个|一名)?(AI|人工智能|语言模型)[，,]?", ""),
    (r"总的来说[，,]?", ""),
    (r"总而言之[，,]?", ""),
    (r"值得一提的是[，,]?", ""),
    (r"需要注意的是[，,]?", ""),
    (r"不可否认[，,]?", ""),
    (r"换句话说[，,]?", "就是说，"),
    (r"在这个[^，。]{1,8}的时代[，,]?", ""),
    (r"让我们一起[^。！!]{0,12}[。！!]?", ""),
    (r"首先[，,]?", ""),
    (r"其次[，,]?", ""),
    (r"最后[，,]?(?=[\u4e00-\u9fa5])", ""),
    (r"综上[，,]?", ""),
]

# --- 书面 -> 口语（等义替换） ----------------------------------------------
SOFT_SWAPS = [
    ("但是", "不过"),
    ("因此", "所以"),
    ("此外", "还有"),
    ("另外", "还有"),
    ("十分", "挺"),
    ("非常", "挺"),
    ("是否", "是不是"),
    ("如何", "咋"),
    ("以及", "和"),
    ("并且", "而且"),
    ("给予", "给"),
    ("进行", "做"),
    ("存在", "有"),
    ("的确", "确实"),
    ("我认为", "我觉得"),
    ("应该是", "应该是"),
    ("不要", "别"),
    ("可以吗", "行吗"),
    ("如果你方便的话", "你要是有空"),
    ("不好意思", "那个"),
    ("抱歉", "不好意思"),
]

# --- 诊断规则 ---------------------------------------------------------------
DIAGNOSTICS: list[tuple[str, str, str, int]] = [
    # (code, 正则, 提示, 扣分)
    ("connector", r"(首先|其次|再次|最后|总之|综上|此外|因此|然而|一方面|另一方面)", "书面连接词，口语里直接说事就行", 8),
    ("ai_talk", r"(总的来说|值得一提的是|需要注意的是|不可否认|某种程度上|换句话说|不得不说)", "AI 腔套话", 12),
    ("ai_help", r"(希望(对你|能)有(所)?帮助|作为(一个|一名)?(AI|人工智能))", "助手腔，删掉", 15),
    ("service", r"(亲[，,]|您好|请问|呢~|哦~|哈~|感谢您的)", "客服腔", 10),
    ("long_sentence", r"[^。！？!?\n]{32,}", "句子太长，断成两句", 6),
    ("many_questions", r"[？?].*[？?]", "一次别问两个以上问题", 8),
    ("many_exclaim", r"[！!].*[！!]", "感叹号连用，显得用力过猛", 6),
    ("parallel", r"(既要.{1,12}又要|不仅.{1,12}而且.{1,12}更|既.{1,10}又.{1,10}还)", "排比句，像发言稿", 8),
    ("empty_cheer", r"(加油|相信你|你可以的|会好起来的|一切都会|别想太多|想开点|时间会证明|你值得更好的)", "空泛鼓励，她听不进去", 10),
    ("over_polite", r"(不好意思|抱歉打扰|如果您|方便的话|不知道你是否|冒昧)", "过度客气，拉开距离", 6),
    ("bookish", r"(十分|非常|的确|是否|如何|以及|并且|进行|给予|存在|应当|务必)", "书面词，换成口语", 4),
    ("emoji_spam", r"([\U0001F300-\U0001FAFF\u2600-\u27BF].*){3,}", "表情太多", 5),
    ("self_center", r"(?:^|[。！？!?\n])\s*我", "句句以「我」开头，显得自我", 3),
    ("stiff_end", r"(了呢|的呢|哦呢|啦呢)", "结尾助词打架", 4),
    ("hedge", r"(可能也许大概|或许可能|应该是吧|差不多吧)", "模糊词堆叠，显得没底气", 5),
]

EMOJI_RE = re.compile(r"[\U0001F300-\U0001FAFF\u2600-\u27BF\uFE0F]")
SENTENCE_RE = re.compile(r"[^。！？!?\n]+[。！？!?]?")


def tidy(text: str) -> str:
    """确定性的口语化改写。"""
    if not text:
        return ""
    out = text.strip()
    for pattern, repl in HARD_PHRASES:
        out = re.sub(pattern, repl, out)
    for old, new in SOFT_SWAPS:
        if old == new:
            continue
        out = out.replace(old, new)
    # 标点收敛
    out = out.replace("！", "。").replace("!", "。")
    out = re.sub(r"[。]{2,}", "。", out)
    out = re.sub(r"[？?]{2,}", "？", out)
    out = re.sub(r"[，,]{2,}", "，", out)
    out = re.sub(r"[ \t]{2,}", " ", out)
    # 去掉句首多余逗号/空格
    out = re.sub(r"^[，,。.\s]+", "", out)
    # 单句问号最多一个
    if out.count("？") + out.count("?") > 1:
        first = min([i for i in (out.find("？"), out.find("?")) if i >= 0], default=-1)
        if first >= 0:
            head, tail = out[: first + 1], out[first + 1 :]
            tail = tail.replace("？", "，").replace("?", "，")
            out = head + tail
    out = out.strip("，, ")
    return out.strip()


def lint(text: str, max_chars: int = 120) -> dict:
    """返回 {score, grade, issues, suggestions, stats}。"""
    text = (text or "").strip()
    if not text:
        return {"score": 0, "grade": "空", "issues": ["没有内容"], "suggestions": ["先写一句"], "stats": {}}

    issues: list[str] = []
    suggestions: list[str] = []
    penalty = 0
    seen: set[str] = set()

    for code, pattern, hint, cost in DIAGNOSTICS:
        matches = re.findall(pattern, text)
        if not matches:
            continue
        if code in seen:
            continue
        seen.add(code)
        issues.append(hint)
        suggestions.append(hint)
        penalty += cost

    sentences = [s.strip() for s in SENTENCE_RE.findall(text) if s.strip()]
    lengths = [len(s) for s in sentences] or [len(text)]
    avg_len = sum(lengths) / len(lengths)
    if avg_len > 22:
        issues.append("平均句长偏长，拆短")
        penalty += 5
    if len(text) > max_chars:
        issues.append(f"超过 {max_chars} 字，一条消息别写小作文")
        penalty += 10
    if len(text) < 2:
        issues.append("太短，看不出态度")
        penalty += 4

    emoji = len(EMOJI_RE.findall(text))
    stats = {
        "chars": len(text),
        "sentences": len(sentences),
        "avg_len": round(avg_len, 1),
        "questions": text.count("？") + text.count("?"),
        "exclaims": text.count("！") + text.count("!"),
        "emoji": emoji,
        "lines": text.count("\n") + 1,
    }
    score = max(0, min(100, 100 - penalty))
    grade = "自然" if score >= 85 else "还行" if score >= 70 else "有 AI 味" if score >= 50 else "很生硬"
    return {"score": score, "grade": grade, "issues": issues, "suggestions": suggestions, "stats": stats}


def compare_samples(user_samples: list[str]) -> dict:
    """从用户自己的历史消息里提取风格指纹。"""
    samples = [s for s in (user_samples or []) if s.strip()]
    if not samples:
        return {}
    lengths = [len(s) for s in samples]
    q = sum(s.count("？") + s.count("?") for s in samples)
    e = sum(len(EMOJI_RE.findall(s)) for s in samples)
    excl = sum(s.count("！") + s.count("!") for s in samples)
    n = len(samples)

    def rate(x: int) -> float:
        return round(x / n, 2)

    return {
        "samples": n,
        "avg_len": round(sum(lengths) / n, 1),
        "short_ratio": round(sum(1 for l in lengths if l <= 12) / n, 2),
        "question_rate": rate(q),
        "emoji_rate": rate(e),
        "exclaim_rate": rate(excl),
    }
