"""隐私与授权：范围同意、脱敏、审计。

这里的原则只有一条：**她不知道你在用工具，所以你必须自己盯住每一步。**
- 读：只读你电脑上已登录的窗口，不碰服务器、不碰云端；
- 存：只存本机 data/hivewing.db；
- 发：默认每条都要你点确认；
- 出机：只有你勾了「云端模型」才会把对话片段发出去，且先脱敏。
"""
from __future__ import annotations

import re
from typing import Any

from .util import log, now

LOG = log("privacy")

# 授权项。read_chat / send_confirm 是必选，其余可勾可不勾。
SCOPE_ITEMS: list[dict[str, Any]] = [
    {
        "key": "read_chat",
        "label": "读取聊天内容",
        "detail": "读取微信 / QQ / 抖音窗口里她发来的消息。只在你电脑的内存和本地数据库里。",
        "required": True,
    },
    {
        "key": "local_store",
        "label": "在本机保存聊天记录",
        "detail": "聊天记录、草稿、她的喜好存在 data/hivewing.db。不上传，删掉 data 目录即清空。",
        "required": False,
    },
    {
        "key": "cloud_llm",
        "label": "把对话片段发给云端模型",
        "detail": "用 DeepSeek 生成回复时，会把最近几条对话发出去（手机号、身份证、邮箱会先打码）。"
                  "不勾这项就只能用本机 Ollama，效果差一点，但一个字都不出这台电脑。",
        "required": False,
    },
    {
        "key": "send_confirm",
        "label": "每条消息都要我确认",
        "detail": "强制开启。蜂群可以自动起稿，但任何一条都不能自动发出去。",
        "required": True,
    },
]

REQUIRED_KEYS = {"read_chat", "send_confirm"}

# 出机前要打掉的东西
_PHONE = re.compile(r"(?<!\d)1[3-9]\d{9}(?!\d)")
_IDCARD = re.compile(r"(?<!\d)\d{17}[\dXx](?!\d)")
_BANK = re.compile(r"(?<!\d)\d{16,19}(?!\d)")
_EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+")
_STREET = re.compile(r"[\u4e00-\u9fa5A-Za-z0-9]{2,12}(?:路|街|大道)\d{1,4}号")
_PLATE = re.compile(r"[\u4e00-\u9fa5][A-Z][A-Z0-9]{5,6}")

REDACT_RULES = [
    (_PHONE, "[手机号]"),
    (_IDCARD, "[身份证]"),
    (_BANK, "[卡号]"),
    (_EMAIL, "[邮箱]"),
    (_STREET, "[地址]"),
    (_PLATE, "[车牌]"),
]

LOCAL_PROVIDERS = {"ollama", "mock"}


def redact(text: str) -> str:
    """出行前脱敏。宁可多打，不可漏打。"""
    if not text:
        return text
    out = text
    for pattern, tag in REDACT_RULES:
        out = pattern.sub(tag, out)
    return out


def is_local(provider: str) -> bool:
    return provider in LOCAL_PROVIDERS


def state(cfg) -> dict:
    scope = list(cfg.get("privacy.consent_scope") or [])
    at = float(cfg.get("privacy.consent_at") or 0)
    granted = bool(at) and REQUIRED_KEYS.issubset(set(scope))
    return {
        "granted": granted,
        "at": at,
        "scope": scope,
        "missing": sorted(REQUIRED_KEYS - set(scope)),
        "strict_confirm": bool(cfg.get("privacy.strict_confirm", True)),
        "redact_pii": bool(cfg.get("privacy.redact_pii", True)),
        "local_only": bool(cfg.get("privacy.local_only", False)),
        "retain_days": int(cfg.get("privacy.retain_days", 0) or 0),
    }


def grant(cfg, scope: list[str]) -> dict:
    scope = [s for s in scope if any(i["key"] == s for i in SCOPE_ITEMS)]
    if not REQUIRED_KEYS.issubset(set(scope)):
        return {"ok": False, "detail": "必选项没勾完：" + "、".join(sorted(REQUIRED_KEYS - set(scope)))}
    cfg.set("privacy.consent_scope", scope)
    cfg.set("privacy.consent_at", now())
    cfg.set("privacy.strict_confirm", True)  # 不允许关
    cfg.set("privacy.local_only", "cloud_llm" not in scope)
    cfg.set("safety.require_human_approval", True)
    cfg.set("safety.allow_auto_send", False)
    cfg.save()
    LOG.info("隐私授权已记录：%s（云端=%s）", ",".join(scope), "cloud_llm" in scope)
    return {"ok": True, "state": state(cfg)}


def revoke(cfg) -> dict:
    cfg.set("privacy.consent_scope", [])
    cfg.set("privacy.consent_at", 0)
    cfg.save()
    LOG.info("隐私授权已撤回")
    return {"ok": True, "state": state(cfg)}


def can_use_cloud(cfg, provider: str) -> bool:
    """远端模型必须同时满足：不是 local_only、且勾了 cloud_llm。"""
    if is_local(provider):
        return True
    if bool(cfg.get("privacy.local_only", False)):
        return False
    scope = set(cfg.get("privacy.consent_scope") or [])
    return "cloud_llm" in scope


def audit(store, kind: str, payload: dict) -> None:
    try:
        store.log_event(kind, payload)
    except Exception as exc:  # noqa: BLE001 审计失败不能拖垮主流程
        LOG.debug("审计写入失败：%s", exc)


def describe(provider: str, cfg) -> dict:
    """给界面显示：这次的数据到底去哪了。"""
    local = is_local(provider)
    return {
        "provider": provider,
        "local": local,
        "cloud_allowed": can_use_cloud(cfg, provider),
        "redact_pii": bool(cfg.get("privacy.redact_pii", True)),
        "summary": "全部在本机处理" if local else "对话片段会发给云端模型（已脱敏）",
    }
