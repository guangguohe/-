"""HTTP / WebSocket 服务层。入口在 hivewing.server.app:app。"""
