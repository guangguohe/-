"""Hub：连接服务器与所有客户端（PC / 手机），负责消息落库、广播、触发蜂群。"""
from __future__ import annotations

import asyncio
import time
from collections import OrderedDict, deque
from dataclasses import dataclass, field

from ..config import Config
from ..db import Store
from ..models import Contact, Draft, Message
from ..swarm.queen import Queen
from ..util import log, new_id, now

LOG = log("hub")


@dataclass
class ClientInfo:
    id: str
    kind: str = "pc"
    ua: str = ""
    connected_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict:
        return {"id": self.id, "kind": self.kind, "ua": self.ua[:80],
                "connected_at": self.connected_at}


class Hub:
    def __init__(self, cfg: Config, store: Store, queen: Queen, adapters):
        self.cfg = cfg
        self.store = store
        self.queen = queen
        self.adapters = adapters
        self.clients: dict = OrderedDict()      # ws -> ClientInfo
        self.active_contact_id: str = ""
        self.runs: "OrderedDict[str, object]" = OrderedDict()
        self._pending: dict[str, asyncio.Task] = {}
        self._locks: dict[str, asyncio.Lock] = {}
        self._send_times: deque[float] = deque(maxlen=20)

    # ------------------------------------------------------------------ 连接
    async def connect(self, ws) -> ClientInfo:
        ua = (ws.headers.get("user-agent") or "").lower()
        kind = "mobile" if any(k in ua for k in ("iphone", "android", "mobile", "ipad")) else "pc"
        info = ClientInfo(id=new_id("cl_"), kind=kind, ua=ws.headers.get("user-agent") or "")
        self.clients[ws] = info
        await ws.send_json({"type": "hello", "client": info.to_dict(),
                            "active_contact_id": self.active_contact_id,
                            "server": {"version": self.cfg.get("ui.title", "蜂群僚机")}})
        await self.broadcast_presence()
        LOG.info("客户端接入 %s（%s），当前 %d 个", info.id, kind, len(self.clients))
        return info

    async def disconnect(self, ws) -> None:
        self.clients.pop(ws, None)
        await self.broadcast_presence()

    async def broadcast(self, event: dict) -> None:
        dead = []
        for ws in list(self.clients):
            try:
                await ws.send_json(event)
            except Exception:  # noqa: BLE001
                dead.append(ws)
        for ws in dead:
            self.clients.pop(ws, None)

    async def broadcast_presence(self) -> None:
        await self.broadcast({
            "type": "presence",
            "clients": [c.to_dict() for c in self.clients.values()],
        })

    async def toast(self, message: str, level: str = "info") -> None:
        await self.broadcast({"type": "toast", "message": message, "level": level, "ts": now()})

    def set_active(self, contact_id: str) -> None:
        self.active_contact_id = contact_id or ""

    # ------------------------------------------------------------------ 收消息
    async def ingest(
        self,
        *,
        platform: str,
        uid: str = "",
        name: str = "",
        text: str,
        direction: str = "in",
        external_id: str = "",
        meta: dict | None = None,
        auto: bool = True,
        ts: float | None = None,
    ) -> Message | None:
        text = (text or "").strip()
        if not text:
            return None
        if external_id and self.store.has_external(external_id):
            return None
        contact = self.store.find_contact(platform, uid) if uid else None
        if not contact:
            contact = self.store.ensure_contact(name or uid or "未命名", platform, uid)
        if name and contact.name in ("", "未命名", uid) and name != contact.name:
            contact.name = name
            self.store.upsert_contact(contact)
        msg = Message(
            id=new_id("m_"),
            contact_id=contact.id,
            direction=direction,
            text=text,
            ts=ts or now(),
            platform=platform,
            sender="her" if direction == "in" else "me",
            external_id=external_id,
            meta=meta or {},
        )
        self.store.add_message(msg)
        await self.broadcast({
            "type": "message.new",
            "contact_id": contact.id,
            "message": msg_dict(msg),
            "contact": contact_dict(contact),
        })
        if auto and direction == "in":
            self.schedule_compose(contact, trigger="auto")
        return msg

    async def ingest_from_bridge(self, text: str) -> None:
        """剪贴板桥：优先归到界面当前选中的会话。"""
        contact = self.store.get_contact(self.active_contact_id) if self.active_contact_id else None
        if not contact:
            contact = self.store.ensure_contact("剪贴板对象", "clipboard", "clipboard")
        await self.ingest(
            platform=contact.platform,
            uid=contact.platform_uid,
            name=contact.name,
            text=text,
            meta={"source": "clipboard-bridge"},
        )
        await self.toast(f"已从剪贴板收进「{contact.display}」，蜂群开始工作", "ok")

    # ------------------------------------------------------------------ 触发蜂群
    def schedule_compose(self, contact: Contact, trigger: str = "auto", delay: float = 0.9) -> str:
        run_id = new_id("r_")
        old = self._pending.pop(contact.id, None)
        if old and not old.done():
            old.cancel()

        async def runner() -> None:
            try:
                await asyncio.sleep(delay)
                await self.run_compose(contact, trigger=trigger, run_id=run_id)
            except asyncio.CancelledError:
                LOG.info("合并了 %s 的重复触发", contact.display)

        self._pending[contact.id] = asyncio.create_task(runner())
        return run_id

    async def run_compose(self, contact: Contact, trigger: str = "auto",
                          formation: str = "auto", run_id: str | None = None) -> object:
        lock = self._locks.setdefault(contact.id, asyncio.Lock())
        async with lock:
            run_id = run_id or new_id("r_")
            await self.broadcast({"type": "run.start", "run_id": run_id,
                                  "contact_id": contact.id, "trigger": trigger})
            result = await self.queen.compose(
                contact, trigger=trigger, formation=formation, run_id=run_id
            )
            self.runs[run_id] = result
            while len(self.runs) > 60:
                self.runs.popitem(last=False)
            if result.error and not result.drafts:
                await self.broadcast({"type": "run.error", "run_id": run_id,
                                      "contact_id": contact.id, "error": result.error})
            if result.drafts:
                await self.broadcast({
                    "type": "draft.ready",
                    "run_id": run_id,
                    "contact_id": contact.id,
                    "draft": draft_dict(result.drafts),
                    "situation": result.situation,
                    "strategy": result.strategy,
                    "formation": result.formation,
                    "duration_ms": result.duration_ms,
                    "usage": result.usage,
                })
            return result

    # ------------------------------------------------------------------ 发消息
    def _rate_ok(self) -> bool:
        limit = int(self.cfg.get("safety.max_sends_per_minute", 6) or 6)
        cutoff = time.time() - 60
        while self._send_times and self._send_times[0] < cutoff:
            self._send_times.popleft()
        return len(self._send_times) < limit

    async def deliver(self, draft: Draft, index: int = 0, text: str | None = None,
                      override: bool = False) -> dict:
        contact = self.store.get_contact(draft.contact_id)
        if not contact:
            return {"ok": False, "detail": "会话不存在"}
        variant = draft.variants[index] if 0 <= index < len(draft.variants) else None
        final = (text if text is not None else (variant.text if variant else "")).strip()
        if not final:
            return {"ok": False, "detail": "没有可发送的内容"}
        if variant and getattr(variant, "blocked", False) and not override:
            return {"ok": False, "detail": "这条被质检拦了：触发反模式，建议换一条或改一改"}
        if not self._rate_ok():
            return {"ok": False, "detail": "发得太快了，缓一分钟"}

        result = await self.adapters.send(contact, final)
        self._send_times.append(time.time())

        if result.get("ok") and result.get("mode") != "copy":
            msg = Message(id=new_id("m_"), contact_id=contact.id, direction="out",
                          text=final, platform=contact.platform, sender="me")
            self.store.add_message(msg)
            self.store.update_draft(draft.id, status="sent", chosen=index, final_text=final)
            run = self.store.get_run(draft.run_id) or {}
            intent = (run.get("situation") or {}).get("intent", "")
            if variant and variant.tactic:
                self.store.bump_tactic(variant.tactic, intent, True)
            await self.broadcast({"type": "message.new", "contact_id": contact.id,
                                  "message": msg_dict(msg), "contact": contact_dict(contact)})
            await self.broadcast({"type": "draft.sent", "draft_id": draft.id,
                                  "contact_id": contact.id, "text": final, "mode": result.get("mode")})
            await self.toast(f"已发送：{final[:24]}", "ok")
        elif result.get("ok"):
            self.store.update_draft(draft.id, status="approved", chosen=index, final_text=final)
            await self.broadcast({"type": "draft.approved", "draft_id": draft.id,
                                  "contact_id": contact.id, "text": final})
        else:
            await self.toast(f"发送失败：{result.get('detail', '')}", "error")
        return result

    async def deliver_text(self, contact: Contact, text: str) -> dict:
        """不经过草稿，直接发一句（输入框手写的那条）。"""
        text = (text or "").strip()
        if not text:
            return {"ok": False, "detail": "没有内容"}
        if not self._rate_ok():
            return {"ok": False, "detail": "发得太快了，缓一分钟"}
        result = await self.adapters.send(contact, text)
        self._send_times.append(time.time())
        if result.get("ok") and result.get("mode") != "copy":
            msg = Message(id=new_id("m_"), contact_id=contact.id, direction="out",
                          text=text, platform=contact.platform, sender="me")
            self.store.add_message(msg)
            await self.broadcast({"type": "message.new", "contact_id": contact.id,
                                  "message": msg_dict(msg), "contact": contact_dict(contact)})
            await self.toast(f"已发送：{text[:24]}", "ok")
        return result

    def reject(self, draft: Draft) -> None:
        self.store.update_draft(draft.id, status="rejected")
        run = self.store.get_run(draft.run_id) or {}
        intent = (run.get("situation") or {}).get("intent", "")
        for v in draft.variants:
            if v.tactic:
                self.store.bump_tactic(v.tactic, intent, False)

    # ------------------------------------------------------------------ 状态
    def snapshot(self) -> dict:
        stats = self.store.stats()
        contacts = [contact_dict(c, self.store) for c in self.store.list_contacts()]
        return {
            "contacts": contacts,
            "adapters": self.adapters.statuses(),
            "active_contact_id": self.active_contact_id,
            "stats": stats,
            "clients": [c.to_dict() for c in self.clients.values()],
        }


# ---------------------------------------------------------------- 序列化
def msg_dict(m: Message) -> dict:
    return {"id": m.id, "contact_id": m.contact_id, "direction": m.direction,
            "text": m.text, "ts": m.ts, "platform": m.platform, "sender": m.sender}


def contact_dict(c: Contact, store: Store | None = None) -> dict:
    d = {
        "id": c.id, "name": c.name, "platform": c.platform, "platform_uid": c.platform_uid,
        "stage": c.stage, "notes": c.notes, "tags": c.tags,
        "created_at": c.created_at, "updated_at": getattr(c, "updated_at", 0),
    }
    if store:
        last = store.last_message(c.id)
        d["last_text"] = last.text if last else ""
        d["last_ts"] = last.ts if last else c.updated_at
        d["pending"] = sum(1 for x in store.list_drafts(c.id, 20) if x.status == "pending")
    return d


def draft_dict(d: Draft) -> dict:
    return d.to_dict()


def variant_dict(v) -> dict:
    return {
        "text": v.text, "angle": v.angle, "tactic": v.tactic, "score": v.score,
        "scores": v.scores, "issues": v.issues, "why": v.why, "risk": v.risk,
        "next_step": v.next_step, "blocked": getattr(v, "blocked", False),
    }
