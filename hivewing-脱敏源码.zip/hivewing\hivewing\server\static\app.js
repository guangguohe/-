/* 蜂群僚机 · 前端（无框架，单文件） */
(() => {
  "use strict";

  const BOOT = window.__HIVE_BOOT__ || {};
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const isMobile = () => window.matchMedia("(max-width: 760px)").matches;

  const S = {
    token: BOOT.token || "",
    contacts: [],
    activeId: "",
    contact: null,
    messages: [],
    drafts: [],
    situation: null,
    strategy: null,
    formation: "",
    usage: null,
    trace: [],
    adapters: [],
    config: {},
    stages: ["陌生", "破冰", "熟悉", "暧昧", "邀约", "确认"],
    pairing: null,
    skills: null,
    privacy: null,
    running: false,
    ws: null,
    retry: 0,
    view: "list",
  };

  /* ------------------------------------------------------------------ 基础 */
  async function api(path, { method = "GET", body } = {}) {
    const headers = {};
    if (S.token) headers["X-Hive-Token"] = S.token;
    if (body !== undefined) headers["Content-Type"] = "application/json";
    const r = await fetch(path, {
      method,
      headers,
      credentials: "same-origin",
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    if (r.status === 401) {
      throw new Error("登录凭证失效，请用带 ?token= 的地址重新打开");
    }
    if (!r.ok) {
      let detail = r.statusText;
      try { detail = (await r.json()).detail || detail; } catch (_) {}
      throw new Error(detail);
    }
    return r.json();
  }

  function toast(message, level = "info") {
    const el = document.createElement("div");
    el.className = `toast ${level}`;
    el.textContent = message;
    $("#toasts").appendChild(el);
    setTimeout(() => { el.style.opacity = "0"; el.style.transform = "translateY(8px)"; el.style.transition = ".3s"; }, 2300);
    setTimeout(() => el.remove(), 2700);
  }

  function fmtTime(ts) {
    if (!ts) return "";
    const d = new Date(ts * 1000);
    const now = new Date();
    const sameDay = d.toDateString() === now.toDateString();
    if (sameDay) return d.toTimeString().slice(0, 5);
    return `${d.getMonth() + 1}/${d.getDate()}`;
  }
  function fmtDay(ts) {
    const d = new Date(ts * 1000);
    const now = new Date();
    if (d.toDateString() === now.toDateString()) return "今天";
    const y = new Date(now); y.setDate(now.getDate() - 1);
    if (d.toDateString() === y.toDateString()) return "昨天";
    return `${d.getMonth() + 1} 月 ${d.getDate()} 日`;
  }
  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch (_) {
      const ta = document.createElement("textarea");
      ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select(); document.execCommand("copy"); ta.remove();
    }
    toast("已复制", "ok");
  }

  /* ------------------------------------------------------------------ 启动 */
  async function boot() {
    bindStatic();
    try {
      const data = await api("/api/bootstrap");
      hydrate(data);
      if (!S.token) S.token = data.pairing?.token || "";
      if (!S.activeId && S.contacts.length) S.activeId = S.contacts[0].id;
      if (S.activeId) await selectContact(S.activeId, true);
      connectWS();
    } catch (err) {
      $("#presence").innerHTML = `<span class="dot off"></span><span>${esc(err.message)}</span>`;
      $("#contact-list").innerHTML = `<li class="empty" style="padding:24px 18px">
        <div class="glyph">⚿</div><div>${esc(err.message)}</div>
        <div style="font-size:11px">从终端里复制带 token 的地址打开</div></li>`;
    }
  }

  function hydrate(data) {
    S.contacts = data.contacts || [];
    S.adapters = data.adapters || [];
    S.config = data.config || {};
    S.stages = data.stages || S.stages;
    S.pairing = data.pairing || {};
    S.skills = data.skills || null;
    S.privacy = data.privacy || null;
    if (data.active_contact_id && !S.activeId) S.activeId = data.active_contact_id;
    const saved = localStorage.getItem("hive_active");
    if (saved && S.contacts.some((c) => c.id === saved)) S.activeId = saved;
    renderContacts();
    renderAdapters();
    renderPresence(data.clients || []);
    renderPrivacyBadge();
  }

  function renderPrivacyBadge() {
    const el = $("#privacy-badge");
    if (!el) return;
    const p = S.privacy || {};
    const flow = p.data_flow || {};
    const local = flow.local !== false;
    el.textContent = local ? "只在本机" : "会发云端";
    el.classList.toggle("local", local);
    el.classList.toggle("cloud", !local);
    el.title = p.granted
      ? (flow.summary || "") + (p.redact_pii ? "｜敏感信息已打码" : "")
      : "还没做隐私授权，点一下看看数据去哪了";
  }

  /* ------------------------------------------------------------------ WebSocket */
  function connectWS() {
    const proto = location.protocol === "https:" ? "wss" : "ws";
    const url = `${proto}://${location.host}/ws?token=${encodeURIComponent(S.token)}`;
    const ws = new WebSocket(url);
    S.ws = ws;
    ws.onopen = () => {
      S.retry = 0;
      setOnline(true);
      ws.send(JSON.stringify({ type: "presence", kind: isMobile() ? "mobile" : "pc" }));
      if (S.activeId) ws.send(JSON.stringify({ type: "focus", contact_id: S.activeId }));
    };
    ws.onmessage = (e) => { try { handle(JSON.parse(e.data)); } catch (err) { console.warn(err); } };
    ws.onclose = () => {
      setOnline(false);
      const wait = Math.min(8000, 600 * 2 ** S.retry++);
      setTimeout(connectWS, wait);
    };
    ws.onerror = () => ws.close();
  }

  function handle(ev) {
    switch (ev.type) {
      case "hello":
        break;
      case "presence":
        renderPresence(ev.clients);
        break;
      case "message.new":
        onMessage(ev);
        break;
      case "draft.ready":
        if (ev.contact_id === S.activeId) {
          S.drafts = [ev.draft];
          S.situation = ev.situation || S.situation;
          S.strategy = ev.strategy || S.strategy;
          S.formation = ev.formation || "";
          S.usage = ev.usage || null;
          S.running = false;
          renderDrafts(); renderSituation(); setWingStatus("已出稿");
          if (isMobile()) openWing();
          toast(`${S.formation} 队形出了 ${ev.draft.variants.length} 条`, "ok");
        } else {
          S.contacts = S.contacts.map((c) => c.id === ev.contact_id ? { ...c, pending: 1, last_text: ev.draft.variants[0]?.text || c.last_text, last_ts: Date.now() / 1000 } : c);
          renderContacts();
          toast("另一个会话有新草稿", "info");
        }
        updateDraftPill();
        break;
      case "trace":
        pushTrace(ev);
        break;
      case "stage":
        setWingStatus(ev.label);
        break;
      case "run.start":
        if (ev.contact_id === S.activeId) {
          S.running = true; S.trace = []; S.drafts = []; renderTrace(); renderDrafts();
          setWingStatus("蜂群出发");
        }
        break;
      case "run.error":
        S.running = false; setWingStatus("出错");
        toast(ev.error || "蜂群出错了", "error");
        break;
      case "draft.sent":
        if (ev.contact_id === S.activeId) refreshMessages();
        break;
      case "draft.approved":
        if (ev.contact_id === S.activeId) refreshMessages();
        break;
      case "contact.updated":
        upsertContact(ev.contact); renderContacts();
        if (S.contact && ev.contact.id === S.contact.id) { S.contact = ev.contact; renderHeader(); }
        break;
      case "contact.deleted":
        S.contacts = S.contacts.filter((c) => c.id !== ev.contact_id);
        if (S.activeId === ev.contact_id) { S.activeId = ""; S.contact = null; renderThread(); renderHeader(); }
        renderContacts();
        break;
      case "adapters":
        S.adapters = ev.adapters || []; renderAdapters();
        break;
      case "config.updated":
        S.config = ev.config || S.config;
        break;
      case "privacy":
        S.privacy = ev.privacy || S.privacy;
        if (ev.config) S.config = ev.config;
        renderPrivacyBadge();
        if (settingsTab === "privacy") renderSettings();
        if (ev.adapters) { S.adapters = ev.adapters; renderAdapters(); }
        break;
      case "state":
        S.contacts = ev.contacts || S.contacts;
        S.adapters = ev.adapters || S.adapters;
        renderContacts(); renderAdapters();
        break;
      case "toast":
        toast(ev.message, ev.level || "info");
        break;
      case "focus":
        break;
      default:
        break;
    }
  }

  function setOnline(ok) {
    const p = $("#presence");
    p.innerHTML = `<span class="dot ${ok ? "" : "off"}"></span><span>${ok ? "已连接" : "重连中…"}</span>`;
  }

  function renderPresence(clients = []) {
    const wrap = $("#presence");
    const pc = clients.filter((c) => c.kind === "pc").length;
    const mb = clients.filter((c) => c.kind === "mobile").length;
    wrap.innerHTML = `<span class="dot"></span>
      <span>${clients.length ? `已连接 · 电脑 ${pc} / 手机 ${mb}` : "已连接"}</span>`;
  }

  /* ------------------------------------------------------------------ 会话列表 */
  function renderContacts() {
    const list = $("#contact-list");
    if (!S.contacts.length) {
      list.innerHTML = `<li class="empty" style="padding:34px 16px"><div class="glyph">⬡</div><div>还没有会话</div><div style="font-size:11px">点上面「示例数据」先看看效果</div></li>`;
      return;
    }
    list.innerHTML = S.contacts.map((c) => {
      const active = c.id === S.activeId ? " active" : "";
      const initial = (c.name || "?").slice(0, 1);
      const plat = c.platform === "wechat" ? "wx" : c.platform === "qq" ? "qq" : c.platform === "douyin" ? "douyin" : "manual";
      return `<li class="contact${active}" data-id="${c.id}">
        <div class="avatar ${plat === "qq" ? "qq" : plat === "douyin" ? "douyin" : ""}">${esc(initial)}</div>
        <div class="c-main">
          <div class="c-row">
            <span class="c-name">${esc(c.name)}</span>
            <span class="c-time">${fmtTime(c.last_ts)}</span>
          </div>
          <div class="c-preview">${esc(c.last_text || "（还没有消息）")}</div>
          <div class="c-tags">
            <span class="tag stage">${esc(c.stage)}</span>
            <span class="tag">${platformName(c.platform)}</span>
            ${c.pending ? `<span class="badge">${c.pending}</span>` : ""}
          </div>
        </div>
      </li>`;
    }).join("");
    $$("#contact-list .contact").forEach((el) => {
      el.onclick = () => selectContact(el.dataset.id);
    });
  }

  function platformName(p) {
    return ({ wechat: "微信", qq: "QQ", douyin: "抖音", clipboard: "剪贴板", manual: "手动" })[p] || p;
  }

  function upsertContact(c) {
    if (!c) return;
    const i = S.contacts.findIndex((x) => x.id === c.id);
    if (i >= 0) S.contacts[i] = { ...S.contacts[i], ...c };
    else S.contacts.unshift(c);
    S.contacts.sort((a, b) => (b.last_ts || b.updated_at || 0) - (a.last_ts || a.updated_at || 0));
  }

  async function selectContact(id, silent = false) {
    S.activeId = id;
    localStorage.setItem("hive_active", id);
    S.view = "chat";
    document.body.dataset.view = "chat";
    renderContacts();
    if (S.ws && S.ws.readyState === 1) S.ws.send(JSON.stringify({ type: "focus", contact_id: id }));
    try {
      const data = await api(`/api/contacts/${id}`);
      S.contact = data.contact;
      S.messages = data.messages || [];
      S.drafts = data.drafts || [];
      S.situation = null; S.strategy = null;
      const latest = S.drafts[0];
      if (latest) {
        const run = (data.runs || []).find((r) => r.id === latest.run_id);
        S.situation = run?.situation || null;
        S.strategy = run?.strategy || null;
      }
      renderHeader(); renderThread(); renderDrafts(); renderSituation(); renderTrace(true);
      if (!silent && isMobile()) document.body.dataset.view = "chat";
    } catch (err) {
      toast(err.message, "error");
    }
  }

  function renderHeader() {
    const c = S.contact;
    if (!c) {
      $("#chat-name").textContent = "选一个会话";
      $("#chat-meta").textContent = "把她的消息粘进来，蜂群会给你三条能直接发的话";
      return;
    }
    $("#chat-name").textContent = c.name;
    $("#chat-meta").innerHTML = `${platformName(c.platform)} · ${esc(c.stage)}${c.notes ? " · " + esc(c.notes) : ""}`;
  }

  function renderThread() {
    const box = $("#thread");
    if (!S.messages.length) { box.innerHTML = ""; return; }
    let html = "";
    let lastDay = "";
    for (const m of S.messages) {
      const day = fmtDay(m.ts);
      if (day !== lastDay) { html += `<div class="day">${day}</div>`; lastDay = day; }
      const mine = m.direction === "out";
      html += `<div class="msg ${mine ? "me" : "them"}" data-id="${m.id}">
        <div class="bubble">${esc(m.text)}</div>
        <div class="meta">${fmtTime(m.ts)}${mine ? " · 我" : ""}</div>
      </div>`;
    }
    box.innerHTML = html;
    box.scrollTop = box.scrollHeight;
  }

  function onMessage(ev) {
    const c = ev.contact;
    if (c) {
      upsertContact({ ...c, last_text: ev.message.text, last_ts: ev.message.ts });
      renderContacts();
    }
    if (ev.contact_id !== S.activeId) return;
    if (S.messages.some((m) => m.id === ev.message.id)) return;
    S.messages.push(ev.message);
    renderThread();
    if (ev.message.direction === "in") {
      S.running = true;
      setWingStatus("感知中…");
      setTimeout(() => { if (!S.trace.length) setWingStatus("待命"); }, 2600);
    }
  }

  async function refreshMessages() {
    if (!S.activeId) return;
    try {
      const data = await api(`/api/contacts/${S.activeId}`);
      S.messages = data.messages || [];
      if (data.drafts && data.drafts.length) {
        S.drafts = data.drafts;
        renderDrafts();
      }
      renderThread();
    } catch (_) {}
  }

  /* ------------------------------------------------------------------ 草稿 */
  function renderDrafts() {
    const box = $("#drafts");
    const variants = S.drafts[0]?.variants || [];
    if (!variants.length) {
      box.innerHTML = `<div class="empty"><div class="glyph">⬡</div><div>还没有草稿</div>
        <div>选中会话，点「蜂群起稿」<br/>感知 → 侦察 → 定策 → 起稿 → 打磨 → 质检</div></div>`;
      return;
    }
    const draft = S.drafts[0];
    box.innerHTML = variants.map((v, i) => {
      const sc = v.score >= 78 ? "good" : v.score >= 62 ? "mid" : "bad";
      const best = i === 0 ? " best" : "";
      const blocked = v.blocked ? " blocked" : "";
      const dims = v.scores || {};
      const bar = (k, invert = false) => {
        const val = Math.round(dims[k] ?? 0);
        const danger = invert ? val > 55 : val < 50;
        return `<div class="bar"><span>${k}</span><i><b class="${danger ? "low" : ""}" style="width:${Math.max(2, val)}%"></b></i></div>`;
      };
      const issues = (v.issues || []).slice(0, 3).map((x) => `<li>${esc(x)}</li>`).join("");
      return `<article class="draft-card${best}${blocked}" data-i="${i}">
        <div class="dc-top">
          <span class="chip ${v.blocked ? "warn" : ""}">${esc(v.angle || "回复")}</span>
          ${v.blocked ? '<span class="chip warn">被拦截</span>' : ""}
          <span class="dc-score ${sc}">${Math.round(v.score)}</span>
        </div>
        <div class="dc-text" data-copy="${i}" title="点一下填进输入框">${esc(v.text)}</div>
        ${v.why ? `<p class="dc-why">${esc(v.why)}</p>` : ""}
        <div class="bars">${bar("自然度")}${bar("贴合度")}${bar("推进力")}${bar("风险", true)}${bar("像本人")}</div>
        ${issues ? `<ul class="dc-issues">${issues}</ul>` : ""}
        <div class="dc-actions">
          <button class="btn primary" data-send="${i}">${v.blocked ? "仍要发送" : "发送"}</button>
          <button class="btn" data-copy="${i}">复制</button>
          <button class="btn" data-reject="${i}">不要</button>
        </div>
      </article>`;
    }).join("");

    $$("#drafts [data-send]").forEach((b) => (b.onclick = () => sendDraft(+b.dataset.send)));
    $$("#drafts [data-copy]").forEach((b) => (b.onclick = (e) => { e.stopPropagation(); copyText(variants[+b.dataset.copy].text); }));
    $$("#drafts .dc-text").forEach((el) => (el.onclick = () => { $("#reply-input").value = variants[+el.dataset.copy].text; autoGrow($("#reply-input")); $("#reply-input").focus(); }));
    $$("#drafts [data-reject]").forEach((b) => (b.onclick = () => rejectDraft()));
    updateDraftPill();
  }

  function updateDraftPill() {
    const pill = $("#draft-pill");
    const n = (S.drafts[0]?.variants || []).length;
    pill.hidden = !n;
    pill.textContent = n;
  }

  /* ------------------------------------------------------------------ 确认与授权 */
  function askConsent(after) {
    const p = S.privacy || {};
    const items = p.items || [];
    const scope = new Set(p.scope || []);
    $("#consent-body").innerHTML = `
      <p class="hint" style="margin-top:0">点同意之前，先看清楚这四件事。授权随时可以收回。</p>
      ${items.map((i) => `<label class="consent-item">
        <input type="checkbox" data-scope="${i.key}" ${i.required || scope.has(i.key) ? "checked" : ""} ${i.required ? "disabled" : ""}/>
        <span><b>${esc(i.label)}${i.required ? "（必选）" : ""}</b><em>${esc(i.detail)}</em></span>
      </label>`).join("")}
      <p class="hint" style="margin-top:14px">最要紧的一句：<b>她不知道你在用工具</b>。你可以一直不说，但别让她从别的地方发现。</p>`;
    S._afterConsent = after || null;
    openOverlay("consent-overlay");
  }

  async function grantConsent() {
    const scope = $$("#consent-body [data-scope]").filter((x) => x.checked).map((x) => x.dataset.scope);
    try {
      const res = await api("/api/privacy/consent", { method: "POST", body: { scope } });
      S.privacy = res.privacy;
      renderPrivacyBadge();
      closeOverlay("consent-overlay");
      toast("授权已记录，随时可在「设置 → 隐私」撤回", "ok");
      const fn = S._afterConsent;
      S._afterConsent = null;
      if (fn) await fn();
    } catch (err) { toast(err.message, "error"); }
  }

  async function readWechatScreen() {
    const btn = $("#btn-screen-read");
    const hint = $("#screen-hint");
    if (!S.privacy || !S.privacy.granted) {
      toast("先勾一下隐私授权，读取要走那条", "error");
      return;
    }
    btn.disabled = true;
    btn.textContent = "正在读…";
    try {
      const res = await api("/api/wechat/screen");
      if (!res.ok) { toast(res.error || "没读到", "error"); return; }
      const lines = res.messages || [];
      const hers = lines.filter((m) => m.mine === false).slice(-2).map((m) => m.text);
      const text = (hers.length ? hers : lines.slice(-1).map((m) => m.text)).join("\n");
      if (!text) { toast("没识别到她的消息，微信窗口先打开那个聊天", "error"); return; }
      $("#incoming-text").value = text;
      hint.textContent = `已读「${res.title || "当前聊天"}」，识别可能有错，改完再起稿`;
      toast("读到了，检查一下错别字");
    } catch (err) {
      toast(err.message, "error");
    } finally {
      btn.disabled = false;
      btn.textContent = "读微信屏幕";
    }
  }

  function channelLabel(platform) {
    const running = (S.adapters || []).filter((x) => x.running).map((x) => x.name);
    if (platform === "wechat" && running.includes("wxauto")) return "微信直发";
    if (platform === "qq" && running.includes("onebot")) return "QQ 直发";
    if (running.includes("inject")) return "粘到聊天输入框";
    return "复制到剪贴板";
  }

  function confirmSend({ to, platform, text, channel, onConfirm }) {
    $("#confirm-meta").innerHTML = `<span class="tag stage">${esc(to || "未命名")}</span>
      <span class="tag">${esc(platformName(platform))}</span>
      <span class="tag">${esc(channel)}</span>`;
    $("#confirm-text").textContent = text;
    openOverlay("confirm-overlay");
    $("#btn-confirm-send").onclick = async () => {
      const btn = $("#btn-confirm-send");
      btn.disabled = true;
      try { await onConfirm(); } catch (err) { toast(err.message, "error"); }
      finally { btn.disabled = false; closeOverlay("confirm-overlay"); }
    };
  }

  async function sendDraft(i) {
    const draft = S.drafts[0];
    if (!draft) return;
    const v = draft.variants[i];
    const c = S.contact || {};
    if (v.blocked && !confirm("这条命中了反模式（舔狗/越界/卖惨等），确定还要发？")) return;
    confirmSend({
      to: c.name,
      platform: c.platform,
      text: v.text,
      channel: channelLabel(c.platform),
      onConfirm: async () => {
        const res = await api(`/api/drafts/${draft.id}/send`, {
          method: "POST",
          body: { index: i, override: !!v.blocked, confirm: true },
        });
        if (!res.ok) { toast(res.detail || "发送失败", "error"); return; }
        if (res.mode === "copy") {
          await copyText(v.text);
          toast("已复制，粘到聊天窗口就行", "ok");
        } else {
          toast(res.detail || "已发送", "ok");
        }
        await refreshMessages();
      },
    });
  }

  async function purge(what) {
    const tip = what === "all"
      ? "会连会话、风格样本一起删掉，找不回来。确定？"
      : "会清空所有聊天记录和草稿，会话本身保留。确定？";
    if (!confirm(tip)) return;
    try {
      const r = await api("/api/privacy/purge", { method: "POST", body: { what } });
      const n = Object.values(r.removed || {}).reduce((a, b) => a + b, 0);
      toast(`已清理 ${n} 条数据`, "ok");
      S.privacy = await api("/api/privacy");
      renderPrivacyBadge();
      S.contacts = (await api("/api/contacts")).contacts || [];
      renderContacts();
      S.messages = [];
      renderThread();
      renderSettings();
    } catch (err) { toast(err.message, "error"); }
  }

  async function rejectDraft() {
    const draft = S.drafts[0];
    if (!draft) return;
    try {
      await api(`/api/drafts/${draft.id}/reject`, { method: "POST", body: {} });
      S.drafts = S.drafts.slice(1);
      renderDrafts();
      toast("这条不要了，下次换角度", "info");
    } catch (err) { toast(err.message, "error"); }
  }

  function renderSituation() {
    const box = $("#situation");
    const s = S.situation;
    if (!s || !Object.keys(s).length) { box.innerHTML = ""; return; }
    const strategy = S.strategy || {};
    const tactics = (strategy.tactics || []).map((t) => t.name).filter(Boolean).join("、");
    box.innerHTML = `<div class="sit-card">
      <div class="sit-row"><span class="sit-k">局势</span><span class="sit-v"><b>${esc(s.intent || "")}</b> · ${esc(s.emotion || "")}</span></div>
      ${s.signal ? `<div class="sit-row"><span class="sit-k">潜台词</span><span class="sit-v">${esc(s.signal)}</span></div>` : ""}
      ${strategy.goal ? `<div class="sit-row"><span class="sit-k">目标</span><span class="sit-v">${esc(strategy.goal)}</span></div>` : ""}
      ${tactics ? `<div class="sit-row"><span class="sit-k">打法</span><span class="sit-v">${esc(tactics)}</span></div>` : ""}
      ${s.hint ? `<div class="sit-row"><span class="sit-k">提醒</span><span class="sit-v" style="color:var(--muted)">${esc(s.hint)}</span></div>` : ""}
    </div>`;
  }

  /* ------------------------------------------------------------------ 轨迹 */
  const NODE_GLYPH = { Queen: "♛", perceive: "◉", scout: "⌕", strategize: "◈", draft: "✎", polish: "≈", critic: "⚖" };

  function pushTrace(ev) {
    if (ev.phase === "stage") {
      setWingStatus(ev.label);
      return;
    }
    const key = `${ev.seq}`;
    if (S.trace.some((t) => t.seq === ev.seq)) return;
    if (ev.phase === "start") {
      S.trace.push({ ...ev, _live: true });
    } else {
      const node = S.trace.find((t) => t.node === ev.node && t._live && t.phase === "start");
      if (node) { Object.assign(node, ev, { _live: false }); }
      else { S.trace.push({ ...ev, _live: false }); }
    }
    renderTrace();
    $("#trace-count").textContent = S.trace.length;
  }

  function renderTrace(reset = false) {
    if (reset) { S.trace = []; $("#trace").innerHTML = ""; $("#trace-count").textContent = "0"; return; }
    const box = $("#trace");
    box.innerHTML = S.trace.map((e) => {
      if (e.phase === "start") {
        return `<li class="l${e.level || 0} running" data-seq="${e.seq}">
          <span class="n">${NODE_GLYPH[e.node] || "·"} ${e.node}</span>
          <span class="s">${esc(e.note || "运行中")}</span><span class="t"></span></li>`;
      }
      return `<li class="l${e.level || 0} ${e.phase === "fail" ? "fail" : ""}" data-seq="${e.seq}">
        <span class="n">${NODE_GLYPH[e.node] || "·"} ${e.node}</span>
        <span class="s">${esc(e.summary || (e.phase === "fail" ? "失败" : ""))}</span>
        <span class="t">${e.ms != null ? e.ms + "ms" : ""}</span></li>`;
    }).join("");
    box.scrollTop = box.scrollHeight;
    $("#trace-count").textContent = S.trace.filter((t) => t.phase !== "start").length;
  }

  function setWingStatus(text) {
    const el = $("#wing-status");
    el.textContent = text || "待命";
    el.classList.toggle("busy", !/待命|已出稿|出错/.test(text || ""));
  }

  /* ------------------------------------------------------------------ 适配器 */
  function renderAdapters() {
    const bar = $("#adapter-bar");
    bar.innerHTML = S.adapters.map((a) => {
      const cls = a.error ? "err" : a.running ? "live" : "";
      const label = a.name === "manual" ? "手动" : a.name === "inject" ? "注入" : a.name === "onebot" ? "QQ" : a.name === "wxauto" ? "微信" : a.name === "douyin" ? "抖音" : a.name === "bridge" ? "热键" : a.name;
      return `<span class="adapter-pill ${cls}" data-adapter="${a.name}" title="${esc(a.error || a.note || "")}">
        <span class="dot ${a.running ? "" : "off"}"></span>${esc(label)}</span>`;
    }).join("");
    $$("#adapter-bar [data-adapter]").forEach((el) => {
      el.onclick = () => {
        const name = el.dataset.adapter;
        openSettings("plug");
        toast(`在「接入」里启停 ${name}`, "info");
      };
    });
  }

  /* ------------------------------------------------------------------ 操作 */
  async function compose(formation = "auto") {
    if (!S.activeId) { toast("先选一个会话", "error"); return; }
    if (S.running) { toast("蜂群还在飞", "info"); return; }
    S.running = true; S.trace = []; renderTrace(true);
    setWingStatus("蜂群出发");
    try {
      await api(`/api/contacts/${S.activeId}/compose`, { method: "POST", body: { formation, trigger: "manual" } });
    } catch (err) {
      S.running = false; setWingStatus("出错"); toast(err.message, "error");
    }
  }

  async function ingest() {
    const text = $("#incoming-text").value.trim();
    if (!text) { toast("先粘一句她的话", "error"); return; }
    if (!S.activeId) { toast("先选一个会话", "error"); return; }
    $("#incoming-text").value = "";
    closeOverlay("incoming-overlay");
    try {
      await api("/api/messages", { method: "POST", body: { contact_id: S.activeId, text, direction: "in" } });
    } catch (err) { toast(err.message, "error"); }
  }

  async function sendReply() {
    const text = $("#reply-input").value.trim();
    if (!text) return;
    if (!S.activeId) { toast("先选一个会话", "error"); return; }
    const c = S.contact || {};
    confirmSend({
      to: c.name,
      platform: c.platform,
      text,
      channel: channelLabel(c.platform),
      onConfirm: async () => {
        const res = await api(`/api/contacts/${S.activeId}/say`, { method: "POST", body: { text, confirm: true } });
        if (!res.ok) { toast(res.detail || "发送失败", "error"); return; }
        $("#reply-input").value = "";
        autoGrow($("#reply-input"));
        if (res.mode === "copy") await copyText(text);
        else toast(res.detail || "已发送", "ok");
        await refreshMessages();
      },
    });
  }

  function autoGrow(el) {
    el.style.height = "auto";
    el.style.height = Math.min(120, el.scrollHeight) + "px";
  }

  function openWing() { $("#wing").classList.add("open"); }
  function closeWing() { $("#wing").classList.remove("open"); }
  function openOverlay(id) { $("#" + id).classList.add("open"); }
  function closeOverlay(id) { $("#" + id).classList.remove("open"); }

  /* ------------------------------------------------------------------ 设置面板 */
  let settingsTab = "me";

  function openSettings(tab = "me") {
    settingsTab = tab;
    $$("#settings-tabs button").forEach((b) => b.classList.toggle("on", b.dataset.tab === tab));
    renderSettings();
    openOverlay("settings-overlay");
  }

  function renderSettings() {
    const c = S.config || {};
    const persona = c.persona || {};
    const tone = persona.tone || {};
    const llm = c.llm || {};
    const ds = (llm.providers || {}).deepseek || {};
    const ol = (llm.providers || {}).ollama || {};
    const safety = c.safety || {};
    const goal = c.goal || {};
    const adapters = c.adapters || {};
    const body = $("#settings-body");
    const stageOpts = S.stages.map((s) => `<option ${goal.stage === s ? "selected" : ""}>${s}</option>`).join("");

    const T = {
      me: `
        <div class="row2">
          <div class="field"><label>昵称</label><input type="text" id="s-nickname" value="${esc(persona.nickname || "")}" placeholder="她看到的名字" /></div>
          <div class="field"><label>城市</label><input type="text" id="s-city" value="${esc(persona.city || "")}" placeholder="杭州" /></div>
        </div>
        <div class="row2">
          <div class="field"><label>年龄</label><input type="number" id="s-age" value="${persona.age || ""}" /></div>
          <div class="field"><label>职业</label><input type="text" id="s-job" value="${esc(persona.job || "")}" placeholder="做设计的" /></div>
        </div>
        <div class="field"><label>自我介绍（会进提示词，帮她判断怎么接你）</label>
          <textarea id="s-self" rows="2" placeholder="平时健身、看电影，话不多但接得住梗">${esc(persona.self_description || "")}</textarea></div>
        <div class="field"><label>口头禅（蜂群会偶尔用）</label><input type="text" id="s-signature" value="${esc(persona.signature || "")}" placeholder="笑死 / 就那样" /></div>
        <div class="field"><label>禁忌话题（逗号分隔）</label><input type="text" id="s-taboos" value="${esc((persona.taboos || []).join("，"))}" placeholder="前任，体重" /></div>
        <div class="field"><label>这段关系的目标</label>
          <input type="text" id="s-goal" value="${esc(goal.intent || "")}" placeholder="聊得自然一点，先约出来喝杯东西" /></div>
        <div class="field"><label>关系阶段</label><select id="s-stage">
          <option value="auto" ${goal.stage === "auto" ? "selected" : ""}>自动（按会话设定）</option>${stageOpts}</select></div>`,
      tone: `
        ${["warmth", "directness", "humor", "brevity"].map((k) => {
          const label = { warmth: "温度", directness: "直接度", humor: "幽默", brevity: "简短" }[k];
          const v = Math.round((tone[k] ?? 0.5) * 100);
          return `<div class="field"><label>${label}</label>
            <div class="slider"><input type="range" min="0" max="100" value="${v}" data-tone="${k}" />
            <b data-tone-val="${k}">${v}</b></div></div>`;
        }).join("")}
        <div class="field"><label>单条最多几个字</label><input type="number" id="s-maxchars" value="${safety.max_chars || 120}" /></div>
        <div class="field"><label class="switch"><input type="checkbox" id="s-approval" ${safety.require_human_approval !== false ? "checked" : ""}/> 发送前必须我确认（推荐）</label></div>
        <div class="field"><label class="switch"><input type="checkbox" id="s-autosend" ${safety.allow_auto_send ? "checked" : ""}/> 允许自动代发（不推荐，容易翻车）</label></div>
        <div class="field"><label class="switch"><input type="checkbox" id="s-block" ${safety.block_manipulation !== false ? "checked" : ""}/> 拦截 PUA / 卖惨 / 道德绑架类话术</label></div>`,
      model: `
        <div class="field"><label>主模型</label><select id="s-provider">
          <option value="deepseek" ${llm.default_provider === "deepseek" ? "selected" : ""}>DeepSeek（云端，效果最好）</option>
          <option value="ollama" ${llm.default_provider === "ollama" ? "selected" : ""}>Ollama（本地，免费离线）</option>
          <option value="mock" ${llm.default_provider === "mock" ? "selected" : ""}>离线演示（不用 key）</option>
        </select><div class="hint">云端失败会自动降级到离线引擎，不会卡住你</div></div>
        <div class="field"><label>DeepSeek API Key</label>
          <input type="password" id="s-dskey" placeholder="${ds.api_key_set ? "已配置 " + esc(ds.api_key_hint || "") + "，留空不改" : "sk-..."}" />
          <div class="hint">也可以设环境变量 DEEPSEEK_API_KEY</div></div>
        <div class="row2">
          <div class="field"><label>快档模型</label><input type="text" id="s-fast" value="${esc(ds.model_fast || "")}" /></div>
          <div class="field"><label>强档模型</label><input type="text" id="s-smart" value="${esc(ds.model_smart || "")}" /></div>
        </div>
        <div class="field"><label>Ollama 地址</label><input type="text" id="s-ollama" value="${esc(ol.base_url || "http://127.0.0.1:11434")}" /></div>
        <div class="row2">
          <div class="field"><label>本地快档</label><input type="text" id="s-ol-fast" value="${esc(ol.model_fast || "")}" /></div>
          <div class="field"><label>本地强档</label><input type="text" id="s-ol-smart" value="${esc(ol.model_smart || "")}" /></div>
        </div>
        <div class="field"><label>当前状态</label><div class="hint" id="s-model-health">检查中…</div></div>`,
      plug: `
        <p class="hint" style="margin-top:0">点按钮直接启停；只有「手动」和「注入」开箱即用，其它需要先装环境。</p>
        ${["inject", "onebot", "wxauto", "douyin", "bridge"].map((name) => {
          const a = S.adapters.find((x) => x.name === name) || {};
          const t = { inject: "通用注入（微信/QQ/抖音 PC 端）", onebot: "QQ · OneBot 11（NapCat）", wxauto: "微信 · wxauto", douyin: "抖音 · 剪贴板桥 + 注入", bridge: "剪贴板桥 · Ctrl+Alt+H" }[name];
          return `<div class="skill-item">
            <div style="display:flex;align-items:center;gap:8px">
              <b>${t}</b>
              <span class="dot ${a.running ? "" : "off"}" style="margin-left:auto"></span>
              <button class="btn" data-toggle-adapter="${name}" data-on="${a.running ? "0" : "1"}">${a.running ? "停止" : "启动"}</button>
            </div>
            <p>${esc(a.error || a.note || "")}</p>
          </div>`;
        }).join("")}
        <div class="field" style="margin-top:14px"><label>OneBot HTTP 地址（NapCat 默认 3000）</label>
          <input type="text" id="s-onebot" value="${esc((adapters.onebot || {}).api_base || "http://127.0.0.1:3000")}" /></div>
        <div class="field"><label>OneBot Access Token</label><input type="password" id="s-onebot-token" placeholder="${(adapters.onebot || {}).access_token ? "已配置，留空不改" : "没有就留空"}" /></div>
        <div class="field"><label>我的 QQ 号（用于忽略自己发的消息）</label><input type="text" id="s-selfid" value="${esc((adapters.onebot || {}).self_id || "")}" /></div>
        <div class="hint">NapCat 里把反向 WS 指向 <code>ws://127.0.0.1:${location.port || 8760}/onebot/ws</code>，私聊消息就会进来。</div>`,
      skill: `
        <p class="hint" style="margin-top:0">${S.skills ? `已加载 ${S.skills.sections} 节 · ${S.skills.chars} 字` : ""}</p>
        ${(S.skills?.packs || []).map((p) => `<div class="skill-item"><b>${esc(p.name)}</b><p>${esc(p.description || "")}</p>
          <p style="font-family:var(--mono)">${p.sections} 节 · ${esc(p.slug)}</p></div>`).join("") || '<div class="hint">还没有技能包</div>'}
        <div class="field" style="margin-top:12px"><label>从 GitHub 导入一个 Skill</label>
          <input type="text" id="s-skill-url" placeholder="https://github.com/owner/repo" /></div>
        <div style="display:flex;gap:8px">
          <button class="btn" id="btn-skill-import">导入</button>
          <button class="btn" id="btn-skill-reload">重新加载</button>
        </div>`,
      pair: `
        <div class="qr-box">
          <div id="qr"></div>
          <div style="min-width:0">
            <div class="field"><label>手机扫码，或直接打开这个地址</label>
              <div class="pair-url" id="pair-url">${esc(S.pairing?.url || "")}</div></div>
            <button class="btn" id="btn-copy-pair">复制链接</button>
            <p class="hint">手机和电脑要在同一个 Wi-Fi。电脑端收到的消息、起的稿，手机实时同步；手机上点的发送，也会走电脑的适配器。</p>
          </div>
        </div>
        <div class="field" style="margin-top:14px"><label>在线设备</label><div class="hint" id="pair-clients">—</div></div>`,
      privacy: (() => {
        const p = S.privacy || {};
        const flow = p.data_flow || {};
        const evs = (p.events || []).slice(0, 8).map((e) => {
          const label = { consent: "授权", revoke: "撤回授权", send: "发送", model_call: "模型调用", purge: "清数据" }[e.kind] || e.kind;
          const t = new Date((e.ts || 0) * 1000);
          const detail = e.kind === "model_call"
            ? `${e.payload?.provider || ""} ${e.payload?.local ? "本机" : "云端"}${e.payload?.redacted ? "·已脱敏" : ""}`
            : e.kind === "send" ? `${e.payload?.contact || ""} / ${e.payload?.mode || ""}` : "";
          return `<li><span class="n">${label}</span><span class="s">${esc(detail)}</span>
            <span class="t">${t.toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit" })}</span></li>`;
        }).join("");
        return `
        <div class="privacy-state ${p.granted ? "ok" : "warn"}">
          <b>${p.granted ? "已授权" : "还没授权"}</b>
          <span>${p.granted ? new Date((p.at || 0) * 1000).toLocaleString("zh-CN") : "接入微信 / QQ / 抖音前必须点一次"}</span>
        </div>
        <div class="field"><label>数据去向</label>
          <div class="hint">${esc(flow.summary || "—")}｜模型：<b>${esc(flow.provider || "")}</b></div></div>
        <div class="field"><label class="switch"><input type="checkbox" id="s-redact" ${p.redact_pii !== false ? "checked" : ""}/> 发云端前打码手机号 / 身份证 / 地址</label></div>
        <div class="field"><label class="switch"><input type="checkbox" id="s-localonly" ${p.local_only ? "checked" : ""}/> 只用本机模型（一个字都不出这台电脑）</label></div>
        <div class="field"><label>聊天记录保留天数（0 = 一直留着）</label>
          <input type="number" id="s-retain" value="${p.retain_days || 0}" /></div>
        <div class="field"><label>本机数据</label>
          <div class="hint">${p.stats?.messages || 0} 条消息 · ${(p.db_bytes / 1024).toFixed(0)} KB · 库在 data/hivewing.db</div></div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin:14px 0">
          <button class="btn" id="btn-reconsent">修改授权范围</button>
          <button class="btn" id="btn-purge-msg">清空聊天记录</button>
          <button class="btn" id="btn-purge-all">清空全部数据</button>
          <button class="btn ghost" id="btn-revoke">撤回授权</button>
        </div>
        <div class="field"><label>最近的操作记录</label>
          <ul class="trace audit">${evs || '<li><span class="s">还没有记录</span></li>'}</ul></div>`;
      })(),
    };

    body.innerHTML = T[settingsTab] || T.me;

    if (settingsTab === "pair") {
      drawQR(S.pairing?.url || "");
      $("#btn-copy-pair").onclick = () => copyText(S.pairing?.url || "");
    }
    if (settingsTab === "model") {
      api("/api/llm/health").then((h) => {
        const el = $("#s-model-health");
        if (!el) return;
        el.innerHTML = Object.entries(h).filter(([k]) => k !== "active").map(([k, v]) =>
          `<div>${k}: <b style="color:${v.ok ? "var(--ok)" : "var(--bad)"}">${v.ok ? "可用" : "不可用"}</b> ${esc(v.detail || "")}</div>`).join("")
          + `<div>当前生效：<b>${esc(h.active || "")}</b></div>`;
      }).catch(() => {});
    }
    if (settingsTab === "skill") {
      $("#btn-skill-import").onclick = async () => {
        const url = $("#s-skill-url").value.trim();
        if (!url) return;
        toast("正在拉取仓库…", "info");
        try {
          const res = await api("/api/skills/import", { method: "POST", body: { url } });
          toast(`导入 ${res.pack}：${res.files} 个文件`, "ok");
          S.skills = await api("/api/skills");
          renderSettings();
        } catch (err) { toast(err.message, "error"); }
      };
      $("#btn-skill-reload").onclick = async () => {
        try { S.skills = await api("/api/skills/reload", { method: "POST" }); toast("已重新加载", "ok"); renderSettings(); }
        catch (err) { toast(err.message, "error"); }
      };
    }
    if (settingsTab === "privacy") {
      $("#btn-reconsent").onclick = () => askConsent(() => { renderSettings(); renderPrivacyBadge(); });
      $("#btn-purge-msg").onclick = () => purge("messages");
      $("#btn-purge-all").onclick = () => purge("all");
      $("#btn-revoke").onclick = async () => {
        if (!confirm("撤回授权会立刻停掉所有读取聊天和控制的通道。确定？")) return;
        try {
          const r = await api("/api/privacy/revoke", { method: "POST" });
          S.privacy = r.privacy;
          renderPrivacyBadge();
          renderAdapters();
          renderSettings();
          toast("已撤回授权", "ok");
        } catch (err) { toast(err.message, "error"); }
      };
    }
    $$("#settings-body [data-tone]").forEach((r) => {
      r.oninput = () => { $(`[data-tone-val="${r.dataset.tone}"]`).textContent = r.value; };
    });
    $$("#settings-body [data-toggle-adapter]").forEach((b) => {
      b.onclick = async () => {
        const name = b.dataset.toggleAdapter;
        const action = b.dataset.on === "1" ? "start" : "stop";
        b.disabled = true;
        try {
          const res = await api(`/api/adapters/${name}/${action}`, { method: "POST", body: {} });
          if (res.need_consent) {
            b.disabled = false;
            askConsent(async () => {
              try {
                const again = await api(`/api/adapters/${name}/${action}`, { method: "POST", body: {} });
                if (again.status) S.adapters = S.adapters.map((a) => a.name === name ? again.status : a);
                renderAdapters();
                renderSettings();
                toast("通道已启动", "ok");
              } catch (err) { toast(err.message, "error"); }
            });
            return;
          }
          if (res.status) S.adapters = S.adapters.map((a) => a.name === name ? res.status : a);
          else if (res.ok === false) toast(res.detail || "操作失败", "error");
          renderAdapters();
          renderSettings();
        } catch (err) { toast(err.message, "error"); }
      };
    });
  }

  function drawQR(text) {
    const box = $("#qr");
    if (!box || !text) return;
    box.innerHTML = "";
    try {
      new QRCode(box, { text, width: 120, height: 120, correctLevel: QRCode.CorrectLevel.M });
    } catch (err) {
      box.innerHTML = `<div style="color:#333;font-size:10px;padding:8px;word-break:break-all">${esc(text)}</div>`;
    }
    const clients = $("#pair-clients");
    if (clients) clients.textContent = `${S.contacts.length} 个会话 · 端点 ${location.host}`;
  }

  async function saveSettings() {
    const val = (id) => ($("#" + id) ? $("#" + id).value : undefined);
    const has = (id) => !!document.getElementById(id);
    const payload = {};
    if (has("s-nickname")) {
      const tone = {};
      $$("#settings-body [data-tone]").forEach((r) => { tone[r.dataset.tone] = Number(r.value) / 100; });
      payload.persona = {
        nickname: val("s-nickname"),
        city: val("s-city"),
        age: val("s-age") ? Number(val("s-age")) : null,
        job: val("s-job"),
        self_description: val("s-self"),
        signature: val("s-signature"),
        taboos: (val("s-taboos") || "").split(/[，,、;；]/).map((x) => x.trim()).filter(Boolean),
        tone: { ...(S.config.persona?.tone || {}), ...tone },
      };
      payload.goal = { intent: val("s-goal"), stage: val("s-stage") || "auto" };
    }
    if (has("s-maxchars")) {
      payload.safety = {
        max_chars: Number(val("s-maxchars") || 120),
        require_human_approval: $("#s-approval").checked,
        allow_auto_send: $("#s-autosend").checked,
        block_manipulation: $("#s-block").checked,
      };
    }
    if (has("s-provider")) {
      payload.llm = {
        default_provider: val("s-provider"),
        providers: {
          deepseek: {
            model_fast: val("s-fast"),
            model_smart: val("s-smart"),
            ...(val("s-dskey") ? { api_key: val("s-dskey") } : {}),
          },
          ollama: {
            base_url: val("s-ollama"),
            model_fast: val("s-ol-fast"),
            model_smart: val("s-ol-smart"),
          },
        },
      };
    }
    if (has("s-onebot")) {
      payload.adapters = {
        onebot: {
          api_base: val("s-onebot"),
          self_id: val("s-selfid"),
          ...(val("s-onebot-token") ? { access_token: val("s-onebot-token") } : {}),
        },
      };
    }
    if (has("s-redact")) {
      payload.privacy = {
        redact_pii: $("#s-redact").checked,
        local_only: $("#s-localonly").checked,
        retain_days: Number(val("s-retain") || 0),
      };
    }
    try {
      const res = await api("/api/settings", { method: "PUT", body: payload });
      S.config = res.config;
      if (payload.privacy) {
        S.privacy = await api("/api/privacy");
        renderPrivacyBadge();
      }
      closeOverlay("settings-overlay");
      toast("已保存，下一轮起稿生效", "ok");
    } catch (err) { toast(err.message, "error"); }
  }

  /* ------------------------------------------------------------------ 绑定 */
  function bindStatic() {
    $("#btn-settings").onclick = () => openSettings("me");
    $("#btn-consent-ok").onclick = grantConsent;
    $("#privacy-badge").onclick = () => {
      const p = S.privacy || {};
      if (!p.granted) askConsent();
      else openSettings("privacy");
    };
    $("#btn-new").onclick = () => {
      $("#new-stage").innerHTML = S.stages.map((s) => `<option>${s}</option>`).join("");
      openOverlay("new-overlay");
    };
    $("#btn-create-contact").onclick = async () => {
      const name = $("#new-name").value.trim();
      if (!name) { toast("给她起个名字", "error"); return; }
      try {
        const res = await api("/api/contacts", {
          method: "POST",
          body: { name, platform: $("#new-platform").value, uid: $("#new-uid").value.trim(), stage: $("#new-stage").value },
        });
        upsertContact(res.contact);
        renderContacts();
        closeOverlay("new-overlay");
        $("#new-name").value = ""; $("#new-uid").value = "";
        await selectContact(res.contact.id);
      } catch (err) { toast(err.message, "error"); }
    };
    $("#btn-incoming").onclick = () => openOverlay("incoming-overlay");
    $("#btn-screen-read").onclick = () => readWechatScreen();
    $("#btn-ingest").onclick = ingest;
    $("#btn-compose").onclick = () => compose("auto");
    $("#btn-back").onclick = () => { document.body.dataset.view = "list"; S.view = "list"; closeWing(); };
    $("#btn-trace-toggle").onclick = () => {
      $("#trace").classList.toggle("hidden");
    };
    $("#btn-wing-close").onclick = () => closeWing();
    $("#btn-copy").onclick = () => {
      const text = $("#reply-input").value.trim();
      if (text) copyText(text);
    };
    $("#composer").onsubmit = (e) => { e.preventDefault(); sendReply(); };
    $("#reply-input").addEventListener("input", (e) => autoGrow(e.target));
    $("#reply-input").addEventListener("keydown", (e) => {
      if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); sendReply(); }
    });
    $("#btn-save-settings").onclick = saveSettings;
    $("#settings-tabs").onclick = (e) => {
      const b = e.target.closest("button[data-tab]");
      if (!b) return;
      settingsTab = b.dataset.tab;
      $$("#settings-tabs button").forEach((x) => x.classList.toggle("on", x === b));
      renderSettings();
    };
    $$("[data-close]").forEach((b) => (b.onclick = () => closeOverlay(b.dataset.close)));
    $$(".overlay").forEach((o) => (o.onclick = (e) => { if (e.target === o) o.classList.remove("open"); }));
    $("#tabbar").onclick = (e) => {
      const b = e.target.closest("button[data-tab]");
      if (!b) return;
      const tab = b.dataset.tab;
      if (tab === "list") { document.body.dataset.view = "list"; closeWing(); }
      else if (tab === "wing") {
        if ($("#wing").classList.contains("open")) closeWing();
        else openWing();
      }
      else if (tab === "settings") openSettings("me");
    };
    window.addEventListener("resize", () => { if (!isMobile()) closeWing(); });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") { closeWing(); $$(".overlay.open").forEach((o) => o.classList.remove("open")); }
      if ((e.metaKey || e.ctrlKey) && e.key === "Enter") { e.preventDefault(); compose("auto"); }
    });
  }

  boot();
})();
