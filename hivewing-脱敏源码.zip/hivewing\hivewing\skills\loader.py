"""技能包加载：把 SKILL.md 拆成可检索的「战术手册」。

一个技能包 = 一个目录：
    <pack>/SKILL.md   YAML frontmatter + Markdown 正文（可含 ## 小节）
    <pack>/BRIEF.md   可选，常驻的精简版（每次提示词都会带上）
    <pack>/references/*.md  可选，补充素材

检索用字符二元组重叠打分（中文不需要分词），保证每次只把最相关的几节塞进提示词。
"""
from __future__ import annotations

import base64
import json
import re
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from ..util import ROOT, log, short

LOG = log("skills")
FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---\s*\n", re.S)
HEADING_RE = re.compile(r"^##\s+(.+?)\s*$", re.M)


@dataclass
class Section:
    pack: str
    title: str
    body: str
    source: str = ""
    _grams: set[str] = field(default_factory=set, repr=False)

    @property
    def text(self) -> str:
        return f"### {self.title}\n{self.body.strip()}"

    def grams(self) -> set[str]:
        if not self._grams:
            self._grams = bigrams(self.title + "\n" + self.body)
        return self._grams


@dataclass
class Pack:
    slug: str
    name: str
    description: str = ""
    triggers: list[str] = field(default_factory=list)
    brief: str = ""
    sections: list[Section] = field(default_factory=list)
    path: Path | None = None

    def meta(self) -> dict:
        return {
            "slug": self.slug,
            "name": self.name,
            "description": self.description,
            "triggers": self.triggers,
            "sections": len(self.sections),
            "has_brief": bool(self.brief),
        }


def bigrams(text: str) -> set[str]:
    clean = re.sub(r"[\s，。！？、；：「」（）()\[\]【】\-—…·#*>`|]", "", text or "")
    if len(clean) < 2:
        return {clean} if clean else set()
    return {clean[i : i + 2] for i in range(len(clean) - 1)}


def _split_sections(pack: str, body: str, source: str = "") -> list[Section]:
    parts = HEADING_RE.split(body)
    out: list[Section] = []
    # parts = [前言, 标题1, 内容1, 标题2, 内容2, ...]
    if parts and parts[0].strip():
        out.append(Section(pack=pack, title="总述", body=parts[0].strip(), source=source))
    for i in range(1, len(parts) - 1, 2):
        title = parts[i].strip()
        content = parts[i + 1].strip()
        if content:
            out.append(Section(pack=pack, title=title, body=content, source=source))
    return out


class SkillLibrary:
    def __init__(self, dirs: list[str] | None = None, active: list[str] | None = None):
        self.dirs = [self._resolve(d) for d in (dirs or ["skills/packs"])]
        self.active = active or []
        self.packs: dict[str, Pack] = {}

    @staticmethod
    def _resolve(p: str) -> Path:
        path = Path(p)
        return path if path.is_absolute() else ROOT / path

    # ------------------------------------------------------------------
    def load(self) -> "SkillLibrary":
        self.packs.clear()
        for base in self.dirs:
            if not base.is_dir():
                LOG.warning("技能目录不存在：%s", base)
                continue
            for pack_dir in sorted(base.iterdir()):
                if not pack_dir.is_dir():
                    continue
                if self.active and pack_dir.name not in self.active:
                    continue
                pack = self._load_pack(pack_dir)
                if pack:
                    self.packs[pack.slug] = pack
        LOG.info("已加载技能包：%s", ", ".join(f"{k}({len(v.sections)}节)" for k, v in self.packs.items()))
        return self

    def _load_pack(self, pack_dir: Path) -> Pack | None:
        skill_file = pack_dir / "SKILL.md"
        if not skill_file.exists():
            return None
        raw = skill_file.read_text("utf-8")
        meta: dict = {}
        body = raw
        m = FRONTMATTER_RE.match(raw)
        if m:
            try:
                meta = yaml.safe_load(m.group(1)) or {}
            except yaml.YAMLError as exc:
                LOG.warning("%s frontmatter 解析失败：%s", pack_dir.name, exc)
            body = raw[m.end() :]
        name = str(meta.get("name") or pack_dir.name)
        slug = pack_dir.name
        triggers = meta.get("triggers") or meta.get("trigger") or []
        if isinstance(triggers, str):
            triggers = re.findall(r"[「\"]?([^「」\"、,，\s]{2,12})[」\"]?", triggers)
        brief_file = pack_dir / "BRIEF.md"
        brief = brief_file.read_text("utf-8").strip() if brief_file.exists() else ""
        pack = Pack(
            slug=slug,
            name=name,
            description=str(meta.get("description") or "").strip(),
            triggers=[str(t) for t in triggers][:8],
            brief=brief,
            path=pack_dir,
        )
        pack.sections.extend(_split_sections(slug, body, "SKILL.md"))
        for ref in sorted((pack_dir / "references").rglob("*.md")) if (pack_dir / "references").exists() else []:
            ref_body = ref.read_text("utf-8")
            ref_body = FRONTMATTER_RE.sub("", ref_body)
            pack.sections.extend(_split_sections(slug, ref_body, ref.name))
        return pack

    # ------------------------------------------------------------------
    def list_packs(self) -> list[dict]:
        return [p.meta() for p in self.packs.values()]

    def briefs(self, max_chars: int = 5000) -> str:
        chunks, used = [], 0
        for pack in self.packs.values():
            if not pack.brief:
                continue
            text = pack.brief.strip()
            if used + len(text) > max_chars:
                text = text[: max(0, max_chars - used)]
            if text:
                chunks.append(text)
                used += len(text)
        return "\n\n".join(chunks)

    def digest(self, query: str, max_chars: int = 4000, top_k: int = 4) -> str:
        """检索与当前对话最相关的技能小节。"""
        q = bigrams(query or "")
        if not q:
            return ""
        ranked: list[tuple[float, Section]] = []
        for pack in self.packs.values():
            for sec in pack.sections:
                g = sec.grams()
                if not g:
                    continue
                inter = len(q & g)
                if not inter:
                    continue
                # 长度归一 + 标题命中加权
                score = inter / (len(g) ** 0.5)
                title_hit = len(q & bigrams(sec.title))
                score *= 1.0 + 0.35 * title_hit
                if pack.slug in (query or ""):
                    score *= 1.2
                ranked.append((score, sec))
        ranked.sort(key=lambda x: x[0], reverse=True)
        out, used, seen = [], 0, set()
        for score, sec in ranked:
            key = (sec.pack, sec.title)
            if key in seen:
                continue
            seen.add(key)
            text = sec.text
            if used + len(text) > max_chars:
                text = text[: max(0, max_chars - used)] + "…"
            if not text.strip():
                break
            out.append(text)
            used += len(text)
            if used >= max_chars or len(out) >= top_k:
                break
        return "\n\n".join(out)

    def stats(self) -> dict:
        return {
            "packs": self.list_packs(),
            "sections": sum(len(p.sections) for p in self.packs.values()),
            "chars": sum(len(s.body) for p in self.packs.values() for s in p.sections),
        }

    # ------------------------------------------------------------------
    def import_from_github(self, url: str) -> dict:
        """把 GitHub 上的 SKILL.md 仓库抓进 skills/packs/<slug>/。

        支持 https://github.com/owner/repo 与直接 raw 链接。走 api.github.com 拿 base64。
        """
        m = re.match(r"https?://github\.com/([^/]+)/([^/#?]+)", url.strip())
        if not m:
            raise ValueError("只支持 https://github.com/owner/repo 形式")
        owner, repo = m.group(1), m.group(2).removesuffix(".git")

        def api(path: str):
            req = urllib.request.Request(
                f"https://api.github.com/repos/{owner}/{repo}/{path}",
                headers={"User-Agent": "hivewing-skill-import", "Accept": "application/vnd.github+json"},
            )
            with urllib.request.urlopen(req, timeout=25) as r:
                return json.loads(r.read().decode())

        def walk(path: str = ""):
            for item in api("contents/" + path if path else "contents"):
                if item["type"] == "dir":
                    if item["name"] in ("assets", "images", ".github"):
                        continue
                    yield from walk(item["path"])
                elif item["name"].lower().endswith(".md"):
                    yield item

        target = self._resolve("skills/packs") / repo
        target.mkdir(parents=True, exist_ok=True)
        count = 0
        for item in walk():
            dest = target / item["path"]
            dest.parent.mkdir(parents=True, exist_ok=True)
            blob = api(f"contents/{item['path']}")["content"]
            dest.write_bytes(base64.b64decode(blob))
            count += 1
        self.load()
        LOG.info("导入技能包 %s：%d 个文件 -> %s", repo, count, target)
        return {"pack": repo, "files": count, "path": str(target), "packs": self.list_packs()}
