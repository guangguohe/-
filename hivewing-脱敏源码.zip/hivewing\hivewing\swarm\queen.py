"""蜂群调度核心。

         ┌─────────────── Queen（L0 分诊 / 定队形 / 汇总） ───────────────┐
         │                                                              │
   感知蜂 L1 ──┐                                               ┌── 侦察蜂 L1
               ├── 军师蜂 L2 ── 起稿蜂×N（L3 并行）── 打磨蜂×N（L3 并行）
         局势 ─┘                                               └── 质检蜂 L2
                                   │
                              排名 / 返工 / 呈报

真正的「蜂群」体现在：
- 分工：不同角色用不同模型档位（本地小模型干粗活，DeepSeek 干细活）
- 并行：感知与侦察同时出发，多个起稿蜂同时写不同角度
- 信息素：历史哪种打法被采纳得多，下次优先（tactics 表）
- 闭环：质检不通过就带着批注返工一轮
- 预算：Queen 控制调用次数与耗时，超了就降级交付
"""
from __future__ import annotations

import asyncio
import time

from ..config import Config
from ..context import ChatContext, build_context
from ..critic import scan as anti_scan
from ..db import Store
from ..models import Contact, Draft, DraftVariant, RunResult
from ..polish import lint, tidy
from ..skills.loader import SkillLibrary
from ..util import log, new_id, short
from .prompts import (
    CRITIC_RULES,
    DRAFT_RULES,
    PERCEIVE_RULES,
    POLISH_RULES,
    SCOUT_RULES,
    STRATEGIZE_RULES,
    brief_json,
    system_prompt,
)

LOG = log("queen")

FORMATIONS: dict[str, dict] = {
    "quick": {"drafts": 1, "scout": False, "critic": False, "polish": False, "retries": 0},
    "standard": {"drafts": 3, "scout": True, "critic": True, "polish": True, "retries": 1},
    "deep": {"drafts": 4, "scout": True, "critic": True, "polish": True, "retries": 2},
}

ANGLES_BY_INTENT = {
    "邀约信号": ["给台阶", "接梗", "推进"],
    "情绪低落": ["关心", "给台阶", "接梗"],
    "生气": ["关心", "给台阶", "接梗"],
    "冷场": ["接梗", "关心", "给台阶"],
    "暧昧": ["接梗", "推进", "给台阶"],
    "试探": ["接梗", "给台阶", "关心"],
    "拒绝": ["给台阶", "接梗", "关心"],
    "分享日常": ["接梗", "关心", "推进"],
}
DEFAULT_ANGLES = ["接梗", "关心", "推进", "给台阶"]
STYLE_HINTS = ["再短一点，控制在 15 字内", "带一个具体的细节", "用一句轻反问收尾", "先自嘲半句再递话头"]

COLD = {"嗯", "哦", "哦哦", "好", "好吧", "行", "行吧", "哈哈", "呵呵", "。。", "……"}


class Tracer:
    def __init__(self, run_id: str, emit=None):
        self.run_id = run_id
        self.emit = emit
        self.events: list[dict] = []
        self._seq = 0

    async def _push(self, ev: dict) -> None:
        self._seq += 1
        ev["seq"] = self._seq
        ev["run_id"] = self.run_id
        ev["ts"] = round(time.time(), 3)
        self.events.append(ev)
        if self.emit:
            try:
                await self.emit(ev)
            except Exception:  # noqa: BLE001 广播失败不影响推理
                pass

    async def begin(self, node: str, level: int, tier: str = "", note: str = "") -> float:
        await self._push({"type": "trace", "node": node, "level": level, "phase": "start",
                          "tier": tier, "note": note})
        return time.time()

    async def end(self, node: str, level: int, t0: float, summary: str,
                  *, tier: str = "", model: str = "", detail: dict | None = None) -> None:
        await self._push({"type": "trace", "node": node, "level": level, "phase": "done",
                          "tier": tier, "model": model, "ms": int((time.time() - t0) * 1000),
                          "summary": short(summary, 90), "detail": detail or {}})

    async def fail(self, node: str, level: int, t0: float, err: str) -> None:
        await self._push({"type": "trace", "node": node, "level": level, "phase": "fail",
                          "ms": int((time.time() - t0) * 1000), "summary": short(err, 90)})

    async def stage(self, label: str) -> None:
        await self._push({"type": "stage", "phase": "stage", "node": "stage", "label": label})


class Queen:
    def __init__(self, cfg: Config, store: Store, skills: SkillLibrary, router, emit=None):
        self.cfg = cfg
        self.store = store
        self.skills = skills
        self.router = router
        self.emit = emit

    # ------------------------------------------------------------------ 入口
    async def compose(
        self,
        contact: Contact,
        *,
        trigger: str = "auto",
        formation: str = "auto",
        incoming: str | None = None,
        run_id: str | None = None,
    ) -> RunResult:
        t_start = time.time()
        run_id = run_id or new_id("r_")
        budget = _budget(self.cfg)
        tracer = Tracer(run_id, self.emit)
        ctx = build_context(self.cfg, self.store, contact, incoming or "", trigger)
        formation = formation if formation in FORMATIONS else self.decide(ctx)
        plan = dict(FORMATIONS[formation])
        result = RunResult(run_id=run_id, contact_id=contact.id, formation=formation, trigger=trigger)

        LOG.info("run %s 队形=%s 她: %s", run_id, formation, short(ctx.incoming, 40))
        await tracer.begin("Queen", 0, note=f"队形 {formation}")
        await tracer.stage("分诊")

        # 技能检索只做一次
        digest = self.skills.digest(ctx.retrieval_query(), int(self.cfg.get("skills.max_chars", 9000)))
        common = {"brief": self.skills.briefs(), "digest": digest}

        def sys_for(role: str) -> str:
            return system_prompt(role, common["brief"], common["digest"])

        try:
            # ---- L1：感知 & 侦察 同时出发 ----
            await tracer.stage("侦察")
            perceive_task = self._perceive(tracer, sys_for("perceive"), ctx, budget)
            scout_task = (
                self._scout(tracer, sys_for("scout"), ctx, budget)
                if plan["scout"]
                else _done({"facts": [], "topics": [], "hooks": [], "avoid": [], "subtext": ""})
            )
            situation, scout = await asyncio.gather(perceive_task, scout_task)
            result.situation = situation
            if scout.get("facts"):
                for f in scout["facts"][:6]:
                    if isinstance(f, dict) and f.get("key") and f.get("value"):
                        self.store.add_fact(contact.id, str(f["key"]), str(f["value"]),
                                            float(f.get("confidence", 0.6)), "scout")

            # ---- L2：军师 ----
            await tracer.stage("定策")
            strategy = await self._strategize(tracer, sys_for("strategize"), ctx, situation, scout, budget)
            result.strategy = strategy

            # ---- L3：起稿（并行） ----
            await tracer.stage("起稿")
            variants = await self._draft_many(
                tracer, sys_for("draft"), ctx, situation, scout, strategy,
                n=int(plan["drafts"]), budget=budget, feedback="",
            )

            # ---- L3：打磨（并行，确定性 + 可选模型） ----
            if plan["polish"] and variants:
                await tracer.stage("打磨")
                variants = await self._polish_many(tracer, sys_for("polish"), variants, ctx, budget)

            # ---- L2：质检 ----
            critique: list[dict] = []
            if plan["critic"] and variants:
                await tracer.stage("质检")
                critique = await self._critic(tracer, sys_for("critic"), ctx, situation, variants, budget)

            ranked = self._rank(variants, critique)

            # ---- 返工闭环 ----
            attempt = 0
            while (
                ranked
                and ranked[0].score < 62
                and attempt < int(plan["retries"])
                and budget.can_afford(3)
            ):
                attempt += 1
                await tracer.stage(f"返工第 {attempt} 轮")
                bad = [v for v in ranked[:1]]
                feedback = "；".join(
                    [i for v in bad for i in v.issues][:3]
                    or ["上一版不够自然/不够贴合，换一种说法"]
                )
                extra = await self._draft_many(
                    tracer, sys_for("draft"), ctx, situation, scout, strategy,
                    n=max(1, int(plan["drafts"]) // 2), budget=budget, feedback=feedback,
                )
                if not extra:
                    break
                if plan["polish"]:
                    extra = await self._polish_many(tracer, sys_for("polish"), extra, ctx, budget)
                extra_crit = await self._critic(tracer, sys_for("critic"), ctx, situation, extra, budget)
                merged = self._rank(variants + extra, critique + extra_crit)
                if merged and (not ranked or merged[0].score > ranked[0].score):
                    variants, critique, ranked = variants + extra, critique + extra_crit, merged

            ranked = [v for v in ranked if v.text.strip()][:3]
            if not ranked:
                ranked = [self._emergency_variant(ctx)]

            draft = Draft(
                id=new_id("d_"),
                contact_id=contact.id,
                run_id=run_id,
                variants=ranked,
                status="pending",
            )
            self.store.save_draft(draft)
            result.drafts = draft
            await tracer.end("Queen", 0, t_start,
                             f"{formation} 队形出了 {len(ranked)} 条，最高 {ranked[0].score:.0f} 分",
                             detail={"drafts": len(ranked), "top_score": ranked[0].score})
        except Exception as exc:  # noqa: BLE001 顶层兜底：永远给用户一个可用的东西
            LOG.exception("run %s 失败", run_id)
            result.error = str(exc)[:300]
            if result.drafts is None:
                draft = Draft(id=new_id("d_"), contact_id=contact.id, run_id=run_id,
                              variants=[self._emergency_variant(ctx)])
                self.store.save_draft(draft)
                result.drafts = draft
            await tracer.fail("Queen", 0, t_start, str(exc))

        result.trace = tracer.events
        result.usage = budget.snapshot()
        result.duration_ms = int((time.time() - t_start) * 1000)
        self.store.save_run({
            "id": run_id,
            "contact_id": contact.id,
            "trigger": trigger,
            "formation": formation,
            "situation": result.situation,
            "strategy": result.strategy,
            "usage": result.usage,
            "duration_ms": result.duration_ms,
            "error": result.error,
        })
        return result

    # ------------------------------------------------------------------ 分诊
    def decide(self, ctx: ChatContext) -> str:
        """Queen 用轻量规则决定派多少蜂，省 token 也省时间。"""
        text = (ctx.incoming or "").strip()
        heavy = any(k in text for k in ("喜欢", "关系", "见面", "分手", "生日", "想你", "表白", "见家长", "复合"))
        warm = any(k in text for k in ("累", "烦", "加班", "难受", "哭", "压力", "生气"))
        if ctx.trigger in ("deep", "manual_deep"):
            return "deep"
        if len(text) > 60 or (heavy and len(text) > 12):
            return "deep"
        if (
            len(text) <= 4
            and text.strip("。，？！?！ ") in COLD
            and ctx.stage in ("陌生", "破冰")
            and not warm
        ):
            return "quick"
        return "standard"

    # ------------------------------------------------------------------ 各蜂
    async def _think(self, tracer, role: str, rules: str, sys_prompt: str, brief: dict,
                     level: int, budget, *, temperature: float | None = None,
                     timeout: float | None = None) -> dict:
        t0 = await tracer.begin(role, level, tier=self.router.tier_for(role))
        payload = dict(brief)
        payload["_role"] = role
        payload["_rules"] = rules
        try:
            data, reply = await self.router.call(
                role=role,
                system_prompt=sys_prompt + "\n\n" + rules,
                brief=payload,
                budget=budget,
                temperature=temperature,
                timeout=timeout,
            )
            if data is None:
                raise ValueError("模型没有返回合法 JSON")
            await tracer.end(role, level, t0, self._summarize(role, data),
                             tier=reply.tier, model=f"{reply.provider}:{reply.model}",
                             detail={"fallback": reply.fallback})
            return data
        except Exception as exc:  # noqa: BLE001
            await tracer.fail(role, level, t0, str(exc))
            return {}

    async def _perceive(self, tracer, sys_prompt, ctx: ChatContext, budget) -> dict:
        data = await self._think(tracer, "perceive", PERCEIVE_RULES, sys_prompt, ctx.brief(), 1, budget)
        if not data:
            from ..llm.mock import MockProvider

            data = MockProvider().perceive(ctx.brief())
        return data

    async def _scout(self, tracer, sys_prompt, ctx: ChatContext, budget) -> dict:
        data = await self._think(tracer, "scout", SCOUT_RULES, sys_prompt, ctx.brief(), 1, budget)
        if not data:
            from ..llm.mock import MockProvider

            data = MockProvider().scout(ctx.brief())
        return data

    async def _strategize(self, tracer, sys_prompt, ctx, situation, scout, budget) -> dict:
        prior = self.store.tactic_scores(str(situation.get("intent", "")))
        brief = ctx.brief() | {"situation": situation, "scout": scout, "tactic_prior": prior}
        data = await self._think(tracer, "strategize", STRATEGIZE_RULES, sys_prompt, brief, 2, budget)
        if not data:
            from ..llm.mock import MockProvider

            data = MockProvider().strategize(brief)
        return data

    def _angles(self, situation: dict, n: int, stage: str = "") -> list[str]:
        intent = str(situation.get("intent", ""))
        pool = list(ANGLES_BY_INTENT.get(intent, DEFAULT_ANGLES))
        if stage in ("陌生", "破冰"):
            # 关系还浅，别一上来就「推进」，那是把人推走
            pool = [a for a in pool if a != "推进"] or pool
        return [pool[i % len(pool)] for i in range(n)]

    async def _draft_many(self, tracer, sys_prompt, ctx, situation, scout, strategy,
                          n: int, budget, feedback: str = "") -> list[DraftVariant]:
        angles = self._angles(situation, n, ctx.stage)
        base_brief = ctx.brief() | {"situation": situation, "scout": scout, "strategy": strategy,
                                    "feedback": feedback}
        if feedback:
            base_brief["constraints"] = f"上一版的问题：{feedback}。这次必须避开。"

        async def one(i: int) -> DraftVariant | None:
            angle = angles[i]
            brief = dict(base_brief)
            brief["angle"] = angle
            brief["variant"] = i
            brief["style_hint"] = STYLE_HINTS[i % len(STYLE_HINTS)]
            temp = float(self.cfg.get("llm.temperature", 0.8)) + 0.05 * (i % 3)
            data = await self._think(tracer, "draft", DRAFT_RULES, sys_prompt, brief, 3, budget,
                                     temperature=min(1.2, temp), timeout=90)
            text = str(data.get("text", "")).strip().strip('"“”')
            if not text:
                return None
            text = tidy(text)
            return DraftVariant(
                text=text,
                angle=str(data.get("angle") or angle),
                tactic=str(data.get("tactic") or ""),
                why=str(data.get("why") or ""),
                risk=str(data.get("risk") or "low"),
            )

        # 并发限流：最多 4 只起稿蜂同时说话
        sem = asyncio.Semaphore(4)

        async def guarded(i: int):
            async with sem:
                return await one(i)

        got = await asyncio.gather(*[guarded(i) for i in range(n)], return_exceptions=True)
        return [g for g in got if isinstance(g, DraftVariant)]

    async def _polish_many(self, tracer, sys_prompt, variants: list[DraftVariant],
                           ctx: ChatContext, budget) -> list[DraftVariant]:
        async def one(v: DraftVariant) -> DraftVariant:
            original = v.text
            report = lint(original, int(self.cfg.get("safety.max_chars", 120)))
            if report["score"] >= 88:
                return v
            if not budget.can_afford(1):
                return v
            brief = {"text": original, "incoming": ctx.incoming,
                     "issues": report["issues"], "style_samples": ctx.style_samples[:4],
                     "persona": ctx.persona, "_role": "polish"}
            t0 = await tracer.begin("polish", 3, tier=self.router.tier_for("polish"))
            try:
                data, reply = await self.router.call(
                    role="polish", system_prompt=sys_prompt + "\n\n" + POLISH_RULES,
                    brief=brief, budget=budget, temperature=0.5, timeout=45,
                )
                cand = tidy(str((data or {}).get("text") or original).strip().strip('"“”'))
                await tracer.end("polish", 3, t0, f"改：{short(cand, 40)}",
                                 tier=reply.tier, model=f"{reply.provider}:{reply.model}")
            except Exception as exc:  # noqa: BLE001
                await tracer.fail("polish", 3, t0, str(exc))
                cand = original
            # 只有更好才替换，绝不把稿子改差
            if lint(cand)["score"] >= report["score"] and cand.strip():
                v.text = cand
            return v

        return list(await asyncio.gather(*[one(v) for v in variants]))

    async def _critic(self, tracer, sys_prompt, ctx, situation, variants, budget) -> list[dict]:
        brief = ctx.brief() | {
            "situation": situation,
            "variants": [{"i": i, "text": v.text, "angle": v.angle} for i, v in enumerate(variants)],
        }
        data = await self._think(tracer, "critic", CRITIC_RULES, sys_prompt, brief, 2, budget)
        rows = (data or {}).get("variants") or []
        if not isinstance(rows, list):
            rows = []
        while len(rows) < len(variants):
            rows.append({})
        return rows

    # ------------------------------------------------------------------ 汇总
    def _rank(self, variants: list[DraftVariant], critique: list[dict]) -> list[DraftVariant]:
        for i, v in enumerate(variants):
            row = critique[i] if i < len(critique) else {}
            self._finalize(v, row, self.cfg)
        # 去重（同一句话只留一条）
        seen, uniq = set(), []
        for v in sorted(variants, key=lambda x: x.score, reverse=True):
            key = v.text.strip()
            if key in seen:
                continue
            seen.add(key)
            uniq.append(v)
        return uniq

    @staticmethod
    def _finalize(v: DraftVariant, row: dict, cfg: Config) -> None:
        report = lint(v.text, int(cfg.get("safety.max_chars", 120)))
        hits = anti_scan(v.text)
        scores = row.get("scores") or {}

        def num(key: str, default: float) -> float:
            try:
                return float(scores.get(key, default))
            except (TypeError, ValueError):
                return default

        nat = 0.5 * num("自然度", report["score"]) + 0.5 * report["score"]
        fit = num("贴合度", 75)
        push = num("推进力", 70)
        like = num("像本人", 72)
        risk = num("风险", 20)
        if hits:
            extra = sum(h["weight"] for h in hits)
            risk = max(risk, min(100, 40 + extra * 1.6))

        issues = [str(x) for x in (row.get("issues") or []) if x]
        for h in hits:
            issues.insert(0, f"⛔ {h['label']}：{h['hint']}")
        if not issues and report["issues"]:
            issues = report["issues"]
        if row.get("suggestion"):
            issues.append(str(row["suggestion"]))

        overall = 0.30 * nat + 0.20 * fit + 0.15 * push + 0.20 * (100 - risk) + 0.15 * like
        if any(h["blocking"] for h in hits):
            overall = min(overall, 34)
        if not v.text.strip():
            overall = 0

        v.scores = {"自然度": round(nat), "贴合度": round(fit), "推进力": round(push),
                    "风险": round(risk), "像本人": round(like)}
        v.score = round(overall, 1)
        v.issues = issues[:5]
        v.risk = "high" if risk >= 60 else "mid" if risk >= 35 else "low"
        v.why = v.why or (row.get("suggestion") or "")
        v.next_step = v.next_step or ""
        v.blocked = any(h["blocking"] for h in hits)  # type: ignore[attr-defined]

    def _emergency_variant(self, ctx: ChatContext) -> DraftVariant:
        try:
            from ..llm.mock import MockProvider

            data = MockProvider().draft({"incoming": ctx.incoming, "angle": "接梗", "situation": {}})
            text = data["text"]
        except Exception:  # noqa: BLE001
            text = "嗯，我在"
        v = DraftVariant(text=text, angle="接梗", tactic="兜底", why="模型忙不过来，先给你一句能接住的")
        v.score = 50.0
        v.blocked = False  # type: ignore[attr-defined]
        return v

    @staticmethod
    def _summarize(role: str, data: dict) -> str:
        if role == "perceive":
            return f"{data.get('intent', '?')} / {data.get('emotion', '?')}：{data.get('signal', '')}"
        if role == "scout":
            return "；".join([f"{f.get('key')}={f.get('value')}" for f in (data.get("facts") or [])][:3]) \
                or str(data.get("subtext", ""))
        if role == "strategize":
            names = [t.get("name", "") for t in (data.get("tactics") or [])]
            return f"目标：{data.get('goal', '')}｜打法：{'、'.join(names)}"
        if role == "draft":
            return f"{data.get('angle', '')}：{data.get('text', '')}"
        if role == "polish":
            return str(data.get("text", ""))
        if role == "critic":
            rows = data.get("variants") or []
            return f"{len(rows)} 条已评分"
        return ""


async def _done(value):
    return value


def _budget(cfg: Config):
    from ..llm.router import Budget

    return Budget(
        max_calls=int(cfg.get("llm.budget.max_llm_calls", 18)),
        max_seconds=float(cfg.get("llm.budget.max_seconds", 75)),
    )
