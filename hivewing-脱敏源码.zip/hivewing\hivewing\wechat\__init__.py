"""本机微信 4.x 直连（只在装了 PC 微信的机器上用）。

部署到线上服务器时，整个 hivewing/wechat/ 目录和 adapters/wechat_local.py 都可以删掉，
删掉之后适配器注册表会自动跳过它，其余功能不受影响。
"""
from __future__ import annotations

from .crypto import decrypt_file, verify_key  # noqa: F401
from .keys import collect_salts, scan_keys, weixin_pids  # noqa: F401

__all__ = ["collect_salts", "decrypt_file", "scan_keys", "verify_key", "weixin_pids"]
