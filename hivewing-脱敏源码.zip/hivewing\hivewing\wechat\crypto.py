"""SQLCipher 4 页面解密（微信 4.x 的 db_storage 用这个）。

参数来自 WCDB / SQLCipher 4 默认值：
- page 4096，每页尾部预留 80 字节 = IV(16) + HMAC(64)
- 加密 AES-256-CBC，完整性 HMAC-SHA512
- mac_key = PBKDF2-HMAC-SHA512(enc_key, salt ^ 0x3a, 2 轮, 32 字节)
- page 1 的前 16 字节是 salt，正文从第 17 字节开始

只读本地文件，不解密内存，不碰网络。
"""
from __future__ import annotations

import hashlib
import hmac
import struct
from pathlib import Path

PAGE_SZ = 4096
KEY_SZ = 32
SALT_SZ = 16
IV_SZ = 16
HMAC_SZ = 64
RESERVE_SZ = 80
SQLITE_HDR = b"SQLite format 3\x00"


def derive_mac_key(enc_key: bytes, salt: bytes) -> bytes:
    mac_salt = bytes(b ^ 0x3A for b in salt)
    return hashlib.pbkdf2_hmac("sha512", enc_key, mac_salt, 2, dklen=KEY_SZ)


def verify_key(enc_key: bytes, page1: bytes) -> bool:
    """用 page 1 的 HMAC 验证 key 是否正确。比解密后找 magic 更可靠。"""
    if len(enc_key) != KEY_SZ or len(page1) < PAGE_SZ:
        return False
    salt = page1[:SALT_SZ]
    mac_key = derive_mac_key(enc_key, salt)
    data = page1[SALT_SZ : PAGE_SZ - RESERVE_SZ + IV_SZ]
    stored = page1[PAGE_SZ - HMAC_SZ : PAGE_SZ]
    mac = hmac.new(mac_key, data, hashlib.sha512)
    mac.update(struct.pack("<I", 1))
    return hmac.compare_digest(mac.digest(), stored)


def _aes_cbc_decrypt(key: bytes, iv: bytes, data: bytes) -> bytes:
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

    decryptor = Cipher(algorithms.AES(key), modes.CBC(iv)).decryptor()
    return decryptor.update(data) + decryptor.finalize()


def decrypt_page(enc_key: bytes, page: bytes, pgno: int) -> bytes:
    iv = page[PAGE_SZ - RESERVE_SZ : PAGE_SZ - RESERVE_SZ + IV_SZ]
    if pgno == 1:
        body = _aes_cbc_decrypt(enc_key, iv, page[SALT_SZ : PAGE_SZ - RESERVE_SZ])
        return bytes(SQLITE_HDR + body + b"\x00" * RESERVE_SZ)
    body = _aes_cbc_decrypt(enc_key, iv, page[: PAGE_SZ - RESERVE_SZ])
    return body + b"\x00" * RESERVE_SZ


def decrypt_file(src: Path, dst: Path, enc_key: bytes) -> int:
    """整库解密，返回解出来的页数。"""
    src, dst = Path(src), Path(dst)
    size = src.stat().st_size
    pages = (size + PAGE_SZ - 1) // PAGE_SZ
    dst.parent.mkdir(parents=True, exist_ok=True)
    with src.open("rb") as fin, dst.open("wb") as fout:
        for pgno in range(1, pages + 1):
            page = fin.read(PAGE_SZ)
            if not page:
                break
            if len(page) < PAGE_SZ:
                page = page + b"\x00" * (PAGE_SZ - len(page))
            fout.write(decrypt_page(enc_key, page, pgno))
    return pages


def read_page1(path: Path) -> bytes:
    with Path(path).open("rb") as fh:
        return fh.read(PAGE_SZ)
