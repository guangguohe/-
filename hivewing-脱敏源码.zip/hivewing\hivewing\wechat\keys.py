"""从微信 4.x 进程内存里取出每个数据库的 raw key。

原理：WCDB 把每个库的 raw key 缓存成字符串 `x'<64位hex enc_key><32位hex salt>'`，
salt 一定等于该库 page 1 的前 16 字节。所以：
1. 先扫 db_storage 拿到所有 salt；
2. 再读 Weixin.exe 的可读内存，找形如 x'...' 的十六进制串；
3. 拿 salt 对上号，用 HMAC 校验 key。

只读自己机器上已登录进程的内存，不修改、不注入。
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import re
import struct
from pathlib import Path

from .crypto import KEY_SZ, PAGE_SZ, SALT_SZ, read_page1, verify_key

MEM_COMMIT = 0x1000
READABLE = {0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80}
MAX_REGION = 500 * 1024 * 1024
HEX_RE = re.compile(rb"x'([0-9a-fA-F]{64,192})'")


class MEMORY_BASIC_INFORMATION64(ctypes.Structure):
    _fields_ = [
        ("BaseAddress", ctypes.c_uint64),
        ("AllocationBase", ctypes.c_uint64),
        ("AllocationProtect", wt.DWORD),
        ("_pad1", wt.DWORD),
        ("RegionSize", ctypes.c_uint64),
        ("State", wt.DWORD),
        ("Protect", wt.DWORD),
        ("Type", wt.DWORD),
        ("_pad2", wt.DWORD),
    ]


def is_windows() -> bool:
    return ctypes.sizeof(ctypes.c_void_p) == 8 and hasattr(ctypes, "windll")


def weixin_pids() -> list[int]:
    if not is_windows():
        return []
    import subprocess

    try:
        out = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq Weixin.exe", "/FO", "CSV", "/NH"],
            capture_output=True, text=True, timeout=15,
        ).stdout
    except Exception:  # noqa: BLE001
        return []
    pids = []
    for line in out.splitlines():
        parts = line.strip().strip('"').split('","')
        if len(parts) >= 2 and parts[0].lower().endswith(".exe"):
            try:
                pids.append(int(parts[1]))
            except ValueError:
                continue
    return pids


def collect_salts(db_dir: Path) -> dict[str, list[Path]]:
    """{salt_hex: [db 路径, ...]}，跳过 wal/shm。"""
    out: dict[str, list[Path]] = {}
    for path in sorted(Path(db_dir).rglob("*.db")):
        if path.name.endswith(("-wal", "-shm")):
            continue
        try:
            if path.stat().st_size < PAGE_SZ:
                continue
            salt = read_page1(path)[:SALT_SZ].hex()
        except OSError:
            continue
        out.setdefault(salt, []).append(path)
    return out


def _open_process(pid: int) -> int:
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.OpenProcess(0x0010 | 0x0400, False, pid)  # VM_READ | QUERY_INFO
    return handle or 0


def _read_mem(handle: int, addr: int, size: int) -> bytes | None:
    kernel32 = ctypes.windll.kernel32
    buf = ctypes.create_string_buffer(size)
    read = ctypes.c_size_t(0)
    ok = kernel32.ReadProcessMemory(handle, ctypes.c_uint64(addr), buf, size, ctypes.byref(read))
    return buf.raw[: read.value] if ok else None


def _regions(handle: int):
    kernel32 = ctypes.windll.kernel32
    mbi = MEMORY_BASIC_INFORMATION64()
    addr = 0
    limit = 0x7FFFFFFFFFFF
    while addr < limit:
        if kernel32.VirtualQueryEx(handle, ctypes.c_uint64(addr), ctypes.byref(mbi), ctypes.sizeof(mbi)) == 0:
            break
        if mbi.State == MEM_COMMIT and mbi.Protect in READABLE and 0 < mbi.RegionSize < MAX_REGION:
            yield int(mbi.BaseAddress), int(mbi.RegionSize)
        nxt = int(mbi.BaseAddress) + int(mbi.RegionSize)
        if nxt <= addr:
            break
        addr = nxt


def scan_keys(db_dir: Path, pid: int | None = None, progress=None) -> dict[str, str]:
    """返回 {salt_hex: enc_key_hex}。"""
    if not is_windows():
        return {}
    salts = collect_salts(db_dir)
    if not salts:
        return {}
    page1s = {salt: read_page1(paths[0]) for salt, paths in salts.items()}

    pids = [pid] if pid else weixin_pids()
    if not pids:
        return {}

    found: dict[str, str] = {}
    for cur in pids:
        handle = _open_process(cur)
        if not handle:
            continue
        try:
            for base, size in _regions(handle):
                data = _read_mem(handle, base, size)
                if not data:
                    continue
                for match in HEX_RE.finditer(data):
                    hex_str = match.group(1).decode()
                    if len(hex_str) == 96:
                        key_hex, salt_hex = hex_str[:64], hex_str[64:]
                    elif len(hex_str) == 64:
                        key_hex, salt_hex = hex_str, ""
                    else:
                        key_hex, salt_hex = hex_str[:64], hex_str[-32:]
                    candidates = [salt_hex] if salt_hex in salts else []
                    if not candidates and len(hex_str) == 64:
                        candidates = [s for s in salts if s not in found]
                    for salt in candidates:
                        if salt in found:
                            continue
                        try:
                            key = bytes.fromhex(key_hex)
                        except ValueError:
                            continue
                        if len(key) != KEY_SZ:
                            continue
                        if verify_key(key, page1s[salt]):
                            found[salt] = key_hex
                            if progress:
                                progress(salt, key_hex)
                    if len(found) == len(salts):
                        break
                if len(found) == len(salts):
                    break
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
        if len(found) == len(salts):
            break
    return found


def describe_salt_map(salts: dict[str, list[Path]]) -> str:
    lines = []
    for salt, paths in sorted(salts.items(), key=lambda kv: len(kv[1]), reverse=True):
        lines.append(f"  {salt}: {', '.join(p.name for p in paths)}")
    return "\n".join(lines)
