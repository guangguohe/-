"""Weixin 4.x 的数据库密钥「掩码」提取。

新版微信不直接把 32 字节 raw key 放在内存里，而是用 Weixin.dll 里的一段
32 字节常量做 XOR 掩码。掩码由四条相邻的 `mov rdx, imm64`（48 BA + 8 字节）
在代码里拼出来，正好 40 字节。

这里只读 DLL 文件，不执行它。
"""
from __future__ import annotations

import struct
from pathlib import Path

MOV_RDX_IMM64 = b"\x48\xba"
MASK_SIZE = 32
INSN = 10  # 48 BA + imm64


def find_weixin_dll(program_dir: str | Path = r"C:\Program Files\Tencent\Weixin") -> Path | None:
    root = Path(program_dir)
    if not root.exists():
        return None
    candidates = sorted(root.glob("*/Weixin.dll"), key=lambda p: p.stat().st_size, reverse=True)
    if candidates:
        return candidates[0]
    hits = list(root.rglob("Weixin.dll"))
    return hits[0] if hits else None


def extract_masks(dll_path: str | Path, limit: int = 64) -> list[bytes]:
    """从 DLL 里找出所有「4 条连续 mov rdx, imm64」拼出的 32 字节常量。"""
    data = Path(dll_path).read_bytes()
    masks: list[bytes] = []
    seen: set[bytes] = set()
    start = 0
    while len(masks) < limit:
        idx = data.find(MOV_RDX_IMM64, start)
        if idx < 0:
            break
        start = idx + 1
        ok = True
        parts = []
        for k in range(4):
            pos = idx + k * INSN
            if data[pos : pos + 2] != MOV_RDX_IMM64:
                ok = False
                break
            parts.append(data[pos + 2 : pos + 10])
        if not ok:
            continue
        mask = b"".join(parts)
        if len(mask) != MASK_SIZE or mask in seen:
            continue
        # 全 0 / 全同字节的掩码没有意义
        if len(set(mask)) < 4:
            continue
        seen.add(mask)
        masks.append(mask)
    return masks


def read_pointer(buf: bytes, offset: int) -> int:
    return struct.unpack_from("<Q", buf, offset)[0]
