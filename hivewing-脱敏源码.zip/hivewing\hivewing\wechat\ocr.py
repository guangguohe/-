"""读微信窗口「当前聊天」的画面，OCR 成结构化消息（本机实验通道）。

为什么不是数据库：微信 4.1.15 的库是 SQLCipher，密钥带掩码，取不到就没法读。
为什么不是 UI 自动化：4.x 是 Qt 自绘，UIA 树里只有一个空 Pane。
所以退一步，读屏幕。质量大约 9 成，识别结果一律先给你改，不直接喂给蜂群。
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

CJK = r"\u4e00-\u9fff\u3000-\u303f\uff00-\uffef"
SPACE_AROUND_CJK = re.compile(rf"(?<=[{CJK}])\s+|\s+(?=[{CJK}])")
SPACE_AROUND_COLON = re.compile(r"(?<=[\d:：])\s+(?=[\d:：])")
MULTI_SPACE = re.compile(r"\s{2,}")
TIME_ONLY = re.compile(r"^\s*\d{1,2}[:：]\d{2}\s*$")
SCRIPT = Path(__file__).resolve().parents[2] / "tools" / "wechat_ocr.ps1"


def clean_text(text: str) -> str:
    text = (text or "").replace("\r", " ").replace("\n", " ")
    text = SPACE_AROUND_CJK.sub("", text)
    text = SPACE_AROUND_COLON.sub("", text)
    text = MULTI_SPACE.sub(" ", text)
    return text.strip()


@dataclass
class OcrLine:
    text: str
    x1: int
    y1: int
    x2: int
    y2: int

    @property
    def center_x(self) -> float:
        return (self.x1 + self.x2) / 2


@dataclass
class PaneMessage:
    text: str
    mine: bool | None  # None = 拿不准
    y: int


@dataclass
class PaneRead:
    ok: bool
    width: int = 0
    height: int = 0
    title: str = ""
    messages: list[PaneMessage] = field(default_factory=list)
    error: str = ""

    def last_her_message(self) -> str:
        for msg in reversed(self.messages):
            if msg.mine is False:
                return msg.text
        return ""


def parse_lines(payload: dict) -> PaneRead:
    if not payload.get("ok"):
        return PaneRead(ok=False, error=str(payload.get("error") or "读取失败"))
    width = int(payload.get("width") or 0)
    height = int(payload.get("height") or 0)
    lines = [
        OcrLine(
            text=clean_text(item.get("text", "")),
            x1=int(item.get("x1") or 0),
            y1=int(item.get("y1") or 0),
            x2=int(item.get("x2") or 0),
            y2=int(item.get("y2") or 0),
        )
        for item in payload.get("lines") or []
    ]
    lines = [ln for ln in lines if ln.text]

    title = ""
    body: list[OcrLine] = []
    for ln in lines:
        if height and ln.y1 < height * 0.06 and not title:
            title = ln.text
            continue
        body.append(ln)

    messages: list[PaneMessage] = []
    for ln in body:
        if TIME_ONLY.match(ln.text):
            continue
        if len(ln.text) <= 1:  # 单个字符基本是头像/图标误识别
            continue
        side = classify(ln, width)
        if messages and messages[-1].text == ln.text:
            continue
        messages.append(PaneMessage(text=ln.text, mine=side, y=ln.y1))
    return PaneRead(ok=True, width=width, height=height, title=title, messages=messages)


def classify(line: OcrLine, width: int) -> bool | None:
    if not width:
        return None
    left = line.x1 / width
    if left < 0.30:
        return False  # 靠左：她
    if left > 0.38:
        return True  # 靠右：我
    return None


def read_pane(timeout: int = 60) -> PaneRead:
    if not SCRIPT.exists():
        return PaneRead(ok=False, error="缺少 tools/wechat_ocr.ps1")
    if sys.platform != "win32":
        return PaneRead(ok=False, error="这个通道只在 Windows 上可用")
    try:
        proc = subprocess.run(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(SCRIPT)],
            capture_output=True, timeout=timeout,
        )
    except subprocess.TimeoutExpired:
        return PaneRead(ok=False, error="截图识别超时（微信窗口可能卡住）")
    except OSError as exc:
        return PaneRead(ok=False, error=f"调用 PowerShell 失败：{exc}")
    raw = proc.stdout.decode("utf-8", "replace").strip()
    if not raw:
        err = proc.stderr.decode("utf-8", "replace").strip()
        return PaneRead(ok=False, error=err or "没有输出")
    line = raw.splitlines()[-1]
    try:
        payload = json.loads(line)
    except json.JSONDecodeError:
        return PaneRead(ok=False, error=f"输出不是 JSON：{line[:200]}")
    return parse_lines(payload)
