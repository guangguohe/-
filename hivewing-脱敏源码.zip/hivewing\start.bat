@echo off
chcp 65001 >nul
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8
cd /d "%~dp0"
title HiveWing
python -m hivewing serve %*
if errorlevel 1 pause