"""HiveWing 测试：不依赖网络、不依赖 API key。

运行：
    python -m unittest discover -s tests -v
"""
from __future__ import annotations

import asyncio
import shutil
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import httpx  # noqa: E402

from hivewing import privacy  # noqa: E402
from hivewing.adapters.registry import AdapterManager  # noqa: E402
from hivewing.config import Config  # noqa: E402
from hivewing.critic import has_blocking, scan  # noqa: E402
from hivewing.db import Store  # noqa: E402
from hivewing.llm.router import LLMRouter  # noqa: E402
from hivewing.models import Draft, DraftVariant, Message  # noqa: E402
from hivewing.polish import lint, tidy  # noqa: E402
import hivewing.server.app as appmod  # noqa: E402
from hivewing.server.hub import Hub  # noqa: E402
from hivewing.skills.loader import SkillLibrary  # noqa: E402
from hivewing.swarm.queen import Queen  # noqa: E402
from hivewing.util import new_id  # noqa: E402

TMP = ROOT / "data" / "_test"
PACKS = ROOT / "skills" / "packs"


def reset_tmp() -> Path:
    shutil.rmtree(TMP, ignore_errors=True)
    TMP.mkdir(parents=True, exist_ok=True)
    return TMP


def build_runtime():
    tmp = reset_tmp()
    cfg = Config(
        path=tmp / "config.yaml",
        data={
            "db": str(tmp / "t.db"),
            "llm": {"default_provider": "mock"},
            "skills": {"dirs": [str(PACKS)], "active": ["tong-jincheng", "hivewing-core"]},
        },
    )
    store = Store(cfg.db_path)
    skills = SkillLibrary(cfg.get("skills.dirs"), cfg.get("skills.active")).load()
    router = LLMRouter(cfg)
    queen = Queen(cfg, store, skills, router)
    adapters = AdapterManager(None, cfg)  # type: ignore[arg-type]
    hub = Hub(cfg, store, queen, adapters)
    adapters.hub = hub
    for a in adapters.adapters.values():
        a.hub = hub
    queen.emit = hub.broadcast
    appmod.RT.cfg, appmod.RT.store, appmod.RT.skills = cfg, store, skills
    appmod.RT.router, appmod.RT.queen, appmod.RT.adapters, appmod.RT.hub = router, queen, adapters, hub
    return cfg, store, skills, queen, hub


class PolishTest(unittest.TestCase):
    def test_ai_text_scores_lower(self):
        ai = "首先，我认为你应该好好休息，此外，希望对你有所帮助。感谢您的理解！"
        human = "听着就累。先躺会儿，别管别的。"
        self.assertLess(lint(ai)["score"], lint(human)["score"])
        self.assertGreaterEqual(lint(human)["score"], 80)

    def test_tidy_removes_bookish(self):
        out = tidy("首先，我非常开心！但是你是否方便？")
        self.assertNotIn("首先", out)
        self.assertNotIn("非常", out)
        self.assertNotIn("是否", out)
        self.assertNotIn("！", out)

    def test_long_message_flagged(self):
        report = lint("啊" * 200)
        self.assertLess(report["score"], 100)

    def test_question_spam_flagged(self):
        report = lint("你吃了吗？你几点下班？你住哪？")
        self.assertTrue(any("问" in i for i in report["issues"]))


class CriticTest(unittest.TestCase):
    def test_blocks_simp_talk(self):
        hits = scan("你开心就好，我都听你的，求你了")
        self.assertTrue(hits)
        self.assertTrue(has_blocking("你开心就好，我都听你的，求你了"))

    def test_blocks_guilt_trip(self):
        self.assertTrue(has_blocking("我都为你做了这么多，你连这个都不愿意"))

    def test_allows_normal_chat(self):
        self.assertFalse(scan("周六我打算去逛下市集，你要是也没事，一起？"))


class SkillTest(unittest.TestCase):
    def test_loads_both_packs(self):
        skills = SkillLibrary([str(PACKS)], ["tong-jincheng", "hivewing-core"]).load()
        self.assertIn("tong-jincheng", skills.packs)
        self.assertIn("hivewing-core", skills.packs)
        self.assertGreater(skills.stats()["sections"], 20)
        self.assertIn("童锦程", skills.briefs())

    def test_digest_is_relevant(self):
        skills = SkillLibrary([str(PACKS)], ["hivewing-core"]).load()
        digest = skills.digest("她今天加班好累，我该怎么回", 2000)
        self.assertTrue(digest)
        self.assertTrue(any(k in digest for k in ("情绪", "接话", "累")))


class SwarmTest(unittest.TestCase):
    def test_offline_compose_produces_drafts(self):
        cfg, store, skills, queen, hub = build_runtime()
        c = store.ensure_contact("小雅", "wechat", "小雅")
        store.add_message(Message(id=new_id("m_"), contact_id=c.id, direction="in",
                                  text="今天加班到现在，累死了", sender="her"))

        async def go():
            return await queen.compose(c, trigger="manual")

        result = asyncio.run(go())
        self.assertEqual(result.error, "")
        self.assertIsNotNone(result.drafts)
        self.assertGreaterEqual(len(result.drafts.variants), 3)
        self.assertTrue(result.drafts.variants[0].text)
        self.assertGreater(result.drafts.variants[0].score, 50)
        self.assertIn("perceive", [e["node"] for e in result.trace])
        self.assertIn("draft", [e["node"] for e in result.trace])
        self.assertGreaterEqual(result.usage["calls"], 3)
        store.close()

    def test_context_uses_last_incoming_not_own_reply(self):
        from hivewing.context import build_context

        cfg, store, skills, queen, hub = build_runtime()
        c = store.ensure_contact("阿念", "qq", "1")
        store.add_message(Message(id=new_id("m_"), contact_id=c.id, direction="in", text="在干嘛", sender="her"))
        store.add_message(Message(id=new_id("m_"), contact_id=c.id, direction="out", text="刚下班", sender="me"))
        ctx = build_context(cfg, store, c)
        self.assertEqual(ctx.incoming, "在干嘛")
        store.close()

    def test_blocked_variant_is_flagged(self):
        cfg, store, skills, queen, hub = build_runtime()
        v = DraftVariant(text="你开心就好，我都听你的")
        queen._finalize(v, {}, cfg)
        self.assertTrue(v.blocked)
        self.assertLessEqual(v.score, 40)
        store.close()


class PrivacyTest(unittest.TestCase):
    def test_redact_masks_sensitive(self):
        text = "她电话 13812345678，身份证 110101199003071234，邮箱 a.b@x.com"
        out = privacy.redact(text)
        self.assertNotIn("13812345678", out)
        self.assertNotIn("110101199003071234", out)
        self.assertIn("[手机号]", out)
        self.assertIn("[身份证]", out)
        self.assertIn("[邮箱]", out)

    def test_cloud_blocked_without_consent(self):
        cfg, *_ = build_runtime()
        cfg.set("llm.providers.deepseek.api_key", "sk-test")
        cfg.set("llm.default_provider", "deepseek")
        router = LLMRouter(cfg)
        self.assertEqual(router.provider_name("draft"), "mock")
        privacy.grant(cfg, ["read_chat", "send_confirm"])
        self.assertEqual(router.provider_name("draft"), "mock")  # local_only 还是真
        privacy.grant(cfg, ["read_chat", "send_confirm", "cloud_llm"])
        self.assertEqual(router.provider_name("draft"), "deepseek")

    def test_consent_cannot_be_loosened_via_settings(self):
        cfg, *_ = build_runtime()
        privacy.grant(cfg, ["read_chat", "send_confirm"])
        self.assertTrue(bool(cfg.get("privacy.strict_confirm", True)))


class ApiTest(unittest.TestCase):
    def setUp(self):
        self.cfg, self.store, self.skills, self.queen, self.hub = build_runtime()
        self.headers = {"X-Hive-Token": self.cfg.token}
        self.client = httpx.AsyncClient(
            transport=httpx.ASGITransport(app=appmod.app), base_url="http://test"
        )

    def tearDown(self):
        asyncio.run(self.client.aclose())
        self.store.close()

    def call(self, method, path, **kw):
        async def go():
            return await self.client.request(method, path, headers=self.headers, **kw)

        return asyncio.run(go())

    def test_auth_required(self):
        r = asyncio.run(self.client.get("/api/bootstrap"))
        self.assertEqual(r.status_code, 401)

    def test_end_to_end(self):
        r = self.call("POST", "/api/contacts", json={"name": "小雅", "platform": "wechat", "uid": "小雅"})
        self.assertEqual(r.status_code, 200)
        cid = r.json()["contact"]["id"]

        r = self.call("POST", "/api/messages", json={"contact_id": cid, "text": "这周终于要忙完了", "direction": "in"})
        self.assertEqual(r.status_code, 200)

        r = self.call("POST", f"/api/contacts/{cid}/compose", json={"sync": True})
        body = r.json()
        self.assertEqual(body["error"], "")
        variants = body["draft"]["variants"]
        self.assertGreaterEqual(len(variants), 3)
        self.assertTrue(all(v["text"] for v in variants))

        r = self.call("POST", f"/api/drafts/{body['draft']['id']}/send", json={"index": 0})
        self.assertEqual(r.status_code, 428)  # 没确认，不发

        r = self.call("POST", f"/api/drafts/{body['draft']['id']}/send", json={"index": 0, "confirm": True})
        sent = r.json()
        self.assertTrue(sent["ok"])
        self.assertEqual(sent["mode"], "copy")  # 手动/无窗口时只复制，不假装发送

        r = self.call("GET", f"/api/contacts/{cid}")
        detail = r.json()
        self.assertTrue(detail["messages"])
        self.assertEqual(detail["messages"][-1]["direction"], "in")  # 没真的发出去，不写 out

    def test_bootstrap_shape(self):
        r = self.call("GET", "/api/bootstrap")
        data = r.json()
        for key in ("contacts", "adapters", "config", "pairing", "skills", "stages"):
            self.assertIn(key, data)
        self.assertIn("token", data["pairing"])

    def test_settings_roundtrip_and_masking(self):
        r = self.call("PUT", "/api/settings", json={"persona": {"nickname": "阿哲", "tone": {"humor": 0.9}}})
        self.assertEqual(r.status_code, 200)
        cfg = r.json()["config"]
        self.assertEqual(cfg["persona"]["nickname"], "阿哲")
        self.assertNotIn("sk-", str(cfg))

    def test_blocked_draft_refused(self):
        c = self.store.ensure_contact("测试", "manual")
        d = Draft(id=new_id("d_"), contact_id=c.id, run_id="r_x", variants=[
            DraftVariant(text="你开心就好，我都听你的", blocked=True)
        ])
        self.store.save_draft(d)
        r = self.call("POST", f"/api/drafts/{d.id}/send", json={"index": 0, "confirm": True})
        self.assertFalse(r.json()["ok"])

    def test_privacy_gate(self):
        # 没授权时任何读聊天的通道都起不来
        r = self.call("POST", "/api/adapters/wxauto/start")
        self.assertTrue(r.json()["need_consent"])
        # 没授权时发送接口一律 428
        c = self.store.ensure_contact("权限测试", "manual")
        d = Draft(id=new_id("d_"), contact_id=c.id, run_id="r_x", variants=[DraftVariant(text="在吗")])
        self.store.save_draft(d)
        r = self.call("POST", f"/api/drafts/{d.id}/send", json={"index": 0})
        self.assertEqual(r.status_code, 428)

    def test_consent_requires_core_scope(self):
        r = self.call("POST", "/api/privacy/consent", json={"scope": ["read_chat"]})
        self.assertEqual(r.status_code, 400)
        r = self.call("POST", "/api/privacy/consent", json={"scope": ["read_chat", "send_confirm"]})
        self.assertEqual(r.status_code, 200)
        state = r.json()["privacy"]
        self.assertTrue(state["granted"])
        self.assertTrue(state["local_only"])  # 没勾 cloud_llm 就锁死在本机

    def test_purge_clears_messages(self):
        c = self.store.ensure_contact("待清理", "manual")
        self.store.add_message(Message(id=new_id("m_"), contact_id=c.id, direction="in", text="hi"))
        r = self.call("POST", "/api/privacy/purge", json={"what": "messages"})
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["stats"]["messages"], 0)

    def test_settings_cannot_weaken_privacy(self):
        self.call("POST", "/api/privacy/consent", json={"scope": ["read_chat", "send_confirm"]})
        r = self.call("PUT", "/api/settings", json={"privacy": {"strict_confirm": False, "consent_scope": []}})
        self.assertEqual(r.status_code, 200)
        p = r.json()["config"]["privacy"]
        self.assertTrue(p["strict_confirm"])
        self.assertEqual(p["consent_scope"], ["read_chat", "send_confirm"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
