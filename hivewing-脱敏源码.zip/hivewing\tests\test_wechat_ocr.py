import unittest

from hivewing.wechat.ocr import PaneRead, clean_text, parse_lines, classify, OcrLine


class TestOcrParsing(unittest.TestCase):
    def test_clean_removes_spaces_between_cjk(self):
        self.assertEqual(clean_text("王 影 芳"), "王影芳")
        self.assertEqual(clean_text("他 用 那 个 ChatGPT 怎 么 样 ？"), "他用那个ChatGPT怎么样？")
        self.assertEqual(clean_text("  ok   fine "), "ok fine")

    def test_parse_classifies_sides_and_title(self):
        payload = {
            "ok": True,
            "width": 1000,
            "height": 2000,
            "lines": [
                {"text": "王 影 芳", "x1": 50, "y1": 20, "x2": 200, "y2": 50},
                {"text": "我 记 得 那 个 事", "x1": 600, "y1": 300, "x2": 900, "y2": 340},
                {"text": "1 8 : 4 2", "x1": 450, "y1": 400, "x2": 520, "y2": 430},
                {"text": "他 用 那 个 怎 么 样 ？", "x1": 100, "y1": 500, "x2": 700, "y2": 540},
            ],
        }
        pane = parse_lines(payload)
        self.assertTrue(pane.ok)
        self.assertEqual(pane.title, "王影芳")
        self.assertEqual(len(pane.messages), 2)
        self.assertTrue(pane.messages[0].mine)
        self.assertFalse(pane.messages[1].mine)
        self.assertEqual(pane.last_her_message(), "他用那个怎么样？")

    def test_read_failure(self):
        pane = parse_lines({"ok": False, "error": "微信没开"})
        self.assertFalse(pane.ok)
        self.assertEqual(pane.error, "微信没开")
        self.assertEqual(pane.last_her_message(), "")

    def test_classify_ambiguous_middle(self):
        self.assertIsNone(classify(OcrLine("x", 340, 0, 600, 10), 1000))
        self.assertFalse(classify(OcrLine("x", 100, 0, 600, 10), 1000))
        self.assertTrue(classify(OcrLine("x", 500, 0, 900, 10), 1000))


if __name__ == "__main__":
    unittest.main()
