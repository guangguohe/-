$ErrorActionPreference = "Stop"
try {
    [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime] | Out-Null
    $langs = [Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages
    Write-Output ("ocr languages: " + $langs.Count)
    foreach ($l in $langs) { Write-Output ("  " + $l.LanguageTag + " / " + $l.DisplayName) }
} catch {
    Write-Output ("OCR_FAIL: " + $_.Exception.Message)
}
