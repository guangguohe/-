Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

$root = [System.Windows.Automation.AutomationElement]::RootElement
$pc = New-Object -TypeName System.Windows.Automation.PropertyCondition -ArgumentList ([System.Windows.Automation.AutomationElement]::ClassNameProperty), "Qt51514QWindowIcon"
$win = $root.FindFirst([System.Windows.Automation.TreeScope]::Children, $pc)
if (-not $win) { Write-Output "NO_WINDOW"; exit 1 }

Write-Output ("window: " + $win.Current.ClassName + " / " + $win.Current.Name + " / pid=" + $win.Current.ProcessId)

function Walk($el, $depth) {
    if ($depth -gt 5) { return }
    $child = [System.Windows.Automation.TreeWalker]::RawViewWalker.GetFirstChild($el)
    $n = 0
    while ($child -and $n -lt 60) {
        try {
            $c = $child.Current
            $name = ($c.Name -replace "\r?\n", " ")
            if ($name.Length -gt 50) { $name = $name.Substring(0, 50) }
            Write-Output (("  " * $depth) + $c.ControlType.ProgrammaticName + " | " + $c.ClassName + " | " + $name)
            Walk $child ($depth + 1)
        } catch { }
        $child = [System.Windows.Automation.TreeWalker]::RawViewWalker.GetNextSibling($child)
        $n += 1
    }
}

Walk $win 1
