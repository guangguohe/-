Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

$root = [System.Windows.Automation.AutomationElement]::RootElement
$cond = [System.Windows.Automation.Condition]::TrueCondition
$wins = $root.FindAll([System.Windows.Automation.TreeScope]::Children, $cond)
Write-Output ("top-level windows: " + $wins.Count)
foreach ($w in $wins) {
    $c = $w.Current
    if ($c.Name -or $c.ClassName) {
        Write-Output ($c.ProcessId.ToString() + " | " + $c.ClassName + " | " + $c.Name)
    }
}
