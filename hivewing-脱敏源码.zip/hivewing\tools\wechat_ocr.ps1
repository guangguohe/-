# 读取当前微信窗口的聊天区，OCR 后输出 JSON。
# 输出: {"ok":true,"title":"王影芳","width":1234,"height":2345,"lines":[{"text":"...","x1":..,"y1":..,"x2":..,"y2":..}]}
$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Runtime.WindowsRuntime

if (-not ("WeChatCap2" -as [type])) {
Add-Type -TypeDefinition @"
using System;
using System.Drawing;
using System.Runtime.InteropServices;
public class WeChatCap2 {
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
    [DllImport("shcore.dll")] public static extern int SetProcessDpiAwareness(int v);
    public static void DpiAware() { try { SetProcessDpiAwareness(2); } catch { SetProcessDPIAware(); } }
    public static Bitmap Capture(IntPtr h) {
        RECT r; GetWindowRect(h, out r);
        int w = Math.Max(1, r.Right - r.Left), hh = Math.Max(1, r.Bottom - r.Top);
        var bmp = new Bitmap(w, hh, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
        using (var g = Graphics.FromImage(bmp)) { IntPtr hdc = g.GetHdc(); PrintWindow(h, hdc, 2u); g.ReleaseHdc(hdc); }
        return bmp;
    }
    public static Bitmap CropScale(Bitmap src, double x0, double y0, double x1, double y1, double k) {
        int sx = (int)(src.Width * x0), sy = (int)(src.Height * y0);
        int sw = (int)(src.Width * (x1 - x0)), sh = (int)(src.Height * (y1 - y0));
        var dst = new Bitmap((int)(sw * k), (int)(sh * k));
        using (var g = Graphics.FromImage(dst)) {
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            g.DrawImage(src, new Rectangle(0, 0, dst.Width, dst.Height), new Rectangle(sx, sy, sw, sh), GraphicsUnit.Pixel);
        }
        return dst;
    }
}
"@ -ReferencedAssemblies System.Drawing
}

function Fail($msg) {
    $o = @{ ok = $false; error = $msg } | ConvertTo-Json -Compress
    Write-Output $o
    exit 0
}

[WeChatCap2]::DpiAware() | Out-Null
$proc = Get-Process Weixin -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if (-not $proc) { Fail "微信没开" }
$hwnd = $proc.MainWindowHandle
if ([WeChatCap2]::IsIconic($hwnd)) { [WeChatCap2]::ShowWindow($hwnd, 9) | Out-Null; Start-Sleep -Milliseconds 400 }
[WeChatCap2]::SetForegroundWindow($hwnd) | Out-Null
Start-Sleep -Milliseconds 450

try { $bmp = [WeChatCap2]::Capture($hwnd) } catch { Fail ("截图失败: " + $_.Exception.Message) }
$pane = [WeChatCap2]::CropScale($bmp, 0.34, 0.02, 1.0, 0.96, 2.6)
$tmp = Join-Path $env:TEMP ("wechat_pane_" + [guid]::NewGuid().ToString("N") + ".png")
$pane.Save($tmp, [System.Drawing.Imaging.ImageFormat]::Png)
$pw = $pane.Width; $ph = $pane.Height
$bmp.Dispose(); $pane.Dispose()

$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
})[0]
function Await($op, $type) {
    $asTask = $asTaskGeneric.MakeGenericMethod($type)
    $task = $asTask.Invoke($null, @($op))
    $task.Wait(-1) | Out-Null
    $task.Result
}

[Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime] | Out-Null
[Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
[Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime] | Out-Null
[Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime] | Out-Null

$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($tmp)) ([Windows.Storage.StorageFile])
$stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])

$lang = New-Object Windows.Globalization.Language "zh-Hans-CN"
$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang)
if (-not $engine) { Fail "没有中文 OCR 引擎" }
$result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])

$items = New-Object System.Collections.ArrayList
foreach ($line in @($result.Lines)) {
    $words = @($line.Words)
    if ($words.Count -eq 0) { continue }
    $f = $words[0].BoundingRect
    $l = $words[$words.Count - 1].BoundingRect
    $null = $items.Add(@{
        text = $line.Text
        x1 = [int]$f.X; y1 = [int]$f.Y
        x2 = [int]($l.X + $l.Width); y2 = [int]($f.Y + $f.Height)
    })
}
Remove-Item $tmp -Force -ErrorAction SilentlyContinue
$out = @{ ok = $true; width = $pw; height = $ph; lines = $items } | ConvertTo-Json -Depth 5 -Compress
Write-Output $out
