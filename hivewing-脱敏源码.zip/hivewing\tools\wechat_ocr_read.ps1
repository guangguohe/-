Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Runtime.WindowsRuntime

if (-not ("WeChatCap" -as [type])) {
Add-Type -TypeDefinition @"
using System;
using System.Drawing;
using System.Runtime.InteropServices;
public class WeChatCap {
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
    [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
    [DllImport("shcore.dll")] public static extern int SetProcessDpiAwareness(int v);
    public static void DpiAware() {
        try { SetProcessDpiAwareness(2); } catch { SetProcessDPIAware(); }
    }
    public static Bitmap Capture(IntPtr h) {
        RECT r; GetWindowRect(h, out r);
        int w = Math.Max(1, r.Right - r.Left), hh = Math.Max(1, r.Bottom - r.Top);
        var bmp = new Bitmap(w, hh, System.Drawing.Imaging.PixelFormat.Format24bppRgb);
        using (var g = Graphics.FromImage(bmp)) {
            IntPtr hdc = g.GetHdc();
            PrintWindow(h, hdc, 2u);
            g.ReleaseHdc(hdc);
        }
        return bmp;
    }
    public static Bitmap Scale(Bitmap src, double k) {
        int w = (int)(src.Width * k), h = (int)(src.Height * k);
        var dst = new Bitmap(w, h);
        using (var g = Graphics.FromImage(dst)) {
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            g.DrawImage(src, 0, 0, w, h);
        }
        return dst;
    }
}
"@ -ReferencedAssemblies System.Drawing
}

[WeChatCap]::DpiAware() | Out-Null
$proc = Get-Process Weixin -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 } | Select-Object -First 1
if (-not $proc) { Write-Output "NO_WECHAT"; exit 1 }
$hwnd = $proc.MainWindowHandle
[WeChatCap]::ShowWindow($hwnd, 9) | Out-Null
[WeChatCap]::SetForegroundWindow($hwnd) | Out-Null
Start-Sleep -Milliseconds 500

$bmp = [WeChatCap]::Capture($hwnd)
$big = [WeChatCap]::Scale($bmp, 1.8)
$out = Join-Path $env:TEMP "wechat_cap.png"
$big.Save($out, [System.Drawing.Imaging.ImageFormat]::Png)
Write-Output ("captured " + $bmp.Width + "x" + $bmp.Height + " -> " + $big.Width + "x" + $big.Height)
$bmp.Dispose()

$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
})[0]
function Await($op, $type) {
    $asTask = $asTaskGeneric.MakeGenericMethod($type)
    $task = $asTask.Invoke($null, @($op))
    $task.Wait(-1) | Out-Null
    $task.Result
}

[Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime] | Out-Null
[Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime] | Out-Null
[Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime] | Out-Null
[Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime] | Out-Null

$file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($out)) ([Windows.Storage.StorageFile])
$stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
$decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bitmap = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])

$lang = New-Object Windows.Globalization.Language "zh-Hans-CN"
$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($lang)
if (-not $engine) { $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages() }
$result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])

$lines = @($result.Lines)
Write-Output ("lines=" + $lines.Count)
foreach ($line in $lines) {
    $words = @($line.Words)
    if ($words.Count -eq 0) { continue }
    $f = $words[0].BoundingRect
    $l = $words[$words.Count - 1].BoundingRect
    $x1 = [int]$f.X
    $y1 = [int]$f.Y
    $x2 = [int]($l.X + $l.Width)
    $y2 = [int]($f.Y + $f.Height)
    Write-Output ("$x1`t$y1`t$x2`t$y2`t" + $line.Text)
}
