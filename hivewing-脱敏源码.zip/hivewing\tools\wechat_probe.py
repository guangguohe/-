"""一次性探针：验证微信 4.x 的库能不能解开、里面长什么样。

用法：
    python tools/wechat_probe.py [db_storage 路径]
"""
from __future__ import annotations

import sqlite3
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from hivewing.wechat.crypto import decrypt_file  # noqa: E402
from hivewing.wechat.keys import collect_salts, describe_salt_map, scan_keys  # noqa: E402

DB_DIR = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(
    r"D:\wechat\xwechat_files\<你的wxid>\db_storage"
)
CACHE = Path(__file__).resolve().parents[1] / "data" / "wechat_cache"


def main() -> int:
    print("db_storage:", DB_DIR)
    if not DB_DIR.exists():
        print("目录不存在")
        return 2

    t0 = time.time()
    salts = collect_salts(DB_DIR)
    print(f"\n找到 {sum(len(v) for v in salts.values())} 个库，{len(salts)} 个 salt：")
    print(describe_salt_map(salts))

    print("\n扫描 Weixin.exe 内存取 key …")
    keys = scan_keys(DB_DIR, progress=lambda s, k: print(f"  [KEY] salt={s[:8]}… key={k[:8]}…"))
    print(f"\n取到 {len(keys)}/{len(salts)} 个 key，用时 {time.time()-t0:.1f}s")
    if not keys:
        print("没取到 key：可能不是管理员权限，或微信版本换了缓存格式。")
        return 1

    # 挑几个关键库解密并看 schema
    targets = []
    for salt, paths in salts.items():
        for p in paths:
            if p.name in ("message_0.db", "contact.db", "session.db", "message_2.db"):
                targets.append((p, salt))

    for path, salt in targets:
        if salt not in keys:
            continue
        out = CACHE / path.parent.name / path.name
        n = decrypt_file(path, out, bytes.fromhex(keys[salt]))
        print(f"\n{path.parent.name}/{path.name}: {n} 页 → {out}")
        try:
            con = sqlite3.connect(f"file:{out}?mode=ro&immutable=1", uri=True)
            tables = [r[0] for r in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
            print("  表:", ", ".join(tables[:15]), "…" if len(tables) > 15 else "")
            for t in tables:
                if t.lower().startswith(("msg", "message", "chat", "session", "contact")):
                    cols = [c[1] for c in con.execute(f'PRAGMA table_info("{t}")')]
                    n_rows = con.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
                    print(f"  - {t} ({n_rows} 行): {', '.join(cols[:12])}")
            con.close()
        except Exception as exc:  # noqa: BLE001
            print("  打开失败:", exc)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
